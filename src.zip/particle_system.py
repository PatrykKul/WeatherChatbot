import math
import random
from PyQt5.QtGui import QColor, QPainter, QPen, QBrush, QLinearGradient, QRadialGradient
from PyQt5.QtCore import QRectF, QPoint, QRect, QPointF
from PyQt5.Qt import *
class ParticleSystemManager:
    """
    Zarządca systemów cząstek do renderowania różnych efektów pogodowych.
    """
    
    def __init__(self, width, height):
        self.width = width
        self.height = height
        
        # Parametry animacji
        self.animation_params = {
            'gradient_angle': 0.0,
            'nebula_phase': 0.0,
            'star_phase': 0.0,
            'particle_phase': 0.0,
            'gradient_offset': 0.0
        }
        
        # Poziom efektów
        self.effect_level = "normal"
        
        # Inicjalizacja systemów cząstek dla różnych warunków
        self.particle_systems = {
            'stars': StarParticleSystem(width, height),
            'rain': RainParticleSystem(width, height),
            'snow': SnowParticleSystem(width, height),
            'clouds': CloudParticleSystem(width, height),
            'thunder': ThunderParticleSystem(width, height),
            'sunlight': SunlightParticleSystem(width, height, 30)
        }
    
    def update_animation(self):
        """Aktualizacja parametrów animacji tła i cząstek"""
        self.animation_params['gradient_angle'] = (self.animation_params['gradient_angle'] + 0.5) % 360
        self.animation_params['nebula_phase'] = (self.animation_params['nebula_phase'] + 0.01) % (2 * math.pi)
        self.animation_params['star_phase'] = (self.animation_params['star_phase'] + 0.015) % (2 * math.pi)
        self.animation_params['particle_phase'] = (self.animation_params['particle_phase'] + 0.03) % (2 * math.pi)
        self.animation_params['gradient_offset'] = (self.animation_params['gradient_offset'] + 0.5) % self.width
        
        # Aktualizacja wszystkich systemów cząstek
        for system in self.particle_systems.values():
            system.update(self.animation_params['particle_phase'])
    
    def resize(self, width, height):
        """Zmiana rozmiaru systemów cząstek"""
        self.width = width
        self.height = height
        
        # Aktualizacja rozmiaru wszystkich systemów
        for type_name, system in self.particle_systems.items():
            self.particle_systems[type_name] = system.__class__(width, height)
    
    def set_effect_level(self, level):
        """Ustawienie poziomu efektów wizualnych"""
        if level in ["basic", "normal", "high", "ultra"]:
            self.effect_level = level
            
            # Dostosowanie liczby cząstek w zależności od wybranego poziomu
            particles_counts = {
                "basic": {
                    'stars': 100, 'rain': 30, 'snow': 20, 'clouds': 3, 'thunder': 2
                },
                "normal": {
                    'stars': 200, 'rain': 70, 'snow': 50, 'clouds': 5, 'thunder': 3
                },
                "high": {
                    'stars': 300, 'rain': 100, 'snow': 80, 'clouds': 8, 'thunder': 5
                },
                "ultra": {
                    'stars': 500, 'rain': 200, 'snow': 150, 'clouds': 12, 'thunder': 8
                }
            }
            
            # Aktualizacja liczby cząstek w systemach
            for system_type, count in particles_counts.get(level, particles_counts["normal"]).items():
                self.particle_systems[system_type].set_particle_count(count)
    
    def render(self, widget, event, weather_condition="clear"):
        """
        Renderowanie tła i efektów pogodowych.
        
        Args:
            widget: Widget, na którym rysujemy
            event: Zdarzenie paintEvent
            weather_condition: Typ pogody (clear, clouds, rain, snow, thunderstorm)
        """
        painter = QPainter(widget)
        painter.setRenderHint(QPainter.Antialiasing)
        
        try:
            # Renderowanie tła
            self._render_background(painter, widget.rect(), weather_condition)
            
            # Renderowanie efektów pogodowych
            self._render_weather_effects(painter, weather_condition)
            
        finally:
            painter.end()
    
    def _render_background(self, painter, rect, weather_condition):
        """
        Renderowanie gradientowego tła z efektem mgławicy.
        
        Args:
            painter: Obiekt QPainter
            rect: Obszar do narysowania
            weather_condition: Typ pogody
        """
        # Dynamiczne tło gradientowe
        gradient = QLinearGradient(
            self.animation_params['gradient_offset'], 0,
            self.animation_params['gradient_offset'] + rect.width(), rect.height()
        )
        
        # Ustawianie koloru tła w zależności od pory dnia i pogody
        if weather_condition in ["clear", "clouds"]:
            # Jasne tło dla słonecznej/pochmurnej pogody
            gradient.setColorAt(0, QColor(15, 32, 64))
            gradient.setColorAt(0.5, QColor(30, 64, 128))
            gradient.setColorAt(1, QColor(15, 32, 64))
        elif weather_condition == "rain":
            # Ciemniejsze tło dla deszczu
            gradient.setColorAt(0, QColor(10, 20, 40))
            gradient.setColorAt(0.5, QColor(20, 40, 80))
            gradient.setColorAt(1, QColor(10, 20, 40))
        elif weather_condition == "snow":
            # Jaśniejsze tło dla śniegu
            gradient.setColorAt(0, QColor(20, 40, 80))
            gradient.setColorAt(0.5, QColor(40, 80, 160))
            gradient.setColorAt(1, QColor(20, 40, 80))
        elif weather_condition == "thunderstorm":
            # Bardzo ciemne tło dla burzy
            gradient.setColorAt(0, QColor(5, 10, 30))
            gradient.setColorAt(0.5, QColor(15, 30, 60))
            gradient.setColorAt(1, QColor(5, 10, 30))
        
        painter.fillRect(rect, gradient)
        
        # Efekt mgławicy
        phase = self.animation_params['nebula_phase']
        for i in range(3):
            radius = 500 * (0.8 + 0.2 * math.sin(phase + i))
            grad = QRadialGradient(
                rect.width() / 2 + 150 * math.cos(phase + i),
                rect.height() / 2 + 100 * math.sin(phase + i),
                radius
            )
            
            if weather_condition == "clear":
                # Niebieska mgławica dla czystego nieba
                color = QColor(
                    30 + int(20 * math.sin(phase)),
                    60 + int(30 * math.cos(phase)),
                    90 + int(40 * math.sin(phase * 0.7)),
                    25
                )
            elif weather_condition == "clouds":
                # Szarawa mgławica dla chmur
                color = QColor(
                    40 + int(20 * math.sin(phase)),
                    50 + int(20 * math.cos(phase)),
                    70 + int(30 * math.sin(phase * 0.7)),
                    25
                )
            elif weather_condition == "rain":
                # Ciemno-niebieska mgławica dla deszczu
                color = QColor(
                    20 + int(10 * math.sin(phase)),
                    40 + int(15 * math.cos(phase)),
                    70 + int(20 * math.sin(phase * 0.7)),
                    30
                )
            elif weather_condition == "snow":
                # Jasno-niebieska mgławica dla śniegu
                color = QColor(
                    60 + int(20 * math.sin(phase)),
                    70 + int(20 * math.cos(phase)),
                    100 + int(30 * math.sin(phase * 0.7)),
                    25
                )
            elif weather_condition == "thunderstorm":
                # Purpurowa mgławica dla burzy
                color = QColor(
                    30 + int(20 * math.sin(phase)),
                    20 + int(10 * math.cos(phase)),
                    50 + int(20 * math.sin(phase * 0.7)),
                    35
                )
            
            grad.setColorAt(0, color)
            grad.setColorAt(1, QColor(0, 0, 0, 0))  # Przezroczyste na brzegach
            painter.setBrush(QBrush(grad))
            painter.setPen(QPen(QColor(0, 0, 0, 0)))  # Przezroczyste obramowanie
            painter.drawEllipse(QPoint(int(rect.width()/2), int(rect.height()/2)), int(radius), int(radius))
    
    def _render_weather_effects(self, painter, weather_condition):
        """
        Renderowanie efektów pogodowych.
        
        Args:
            painter: Obiekt QPainter
            weather_condition: Typ pogody
        """

        if weather_condition == "clear":
            # Gwiazdy dla czystego nieba
            self.particle_systems['stars'].render(painter)
            self.particle_systems['sunlight'].render(painter)
            
        elif weather_condition == "clouds":
            # Gwiazdy i chmury dla pochmurnego nieba
            self.particle_systems['stars'].render(painter)
            self.particle_systems['clouds'].render(painter)
            
        elif weather_condition == "rain":
            # Deszcz i chmury
            self.particle_systems['clouds'].render(painter)
            self.particle_systems['rain'].render(painter)
            
        elif weather_condition == "snow":
            # Śnieg i chmury
            self.particle_systems['clouds'].render(painter)
            self.particle_systems['snow'].render(painter)
            
        elif weather_condition == "thunderstorm":
            # Burza, deszcz i chmury
            self.particle_systems['clouds'].render(painter)
            self.particle_systems['rain'].render(painter)
            self.particle_systems['thunder'].render(painter)


class BaseParticleSystem:
    """Bazowa klasa dla systemów cząstek"""
    
    def __init__(self, width, height, particle_count=100):
        self.width = width
        self.height = height
        self.particle_count = particle_count
        self.particles = []
        self.init_particles()

    def init_particles(self):
        """Inicjalizacja cząstek - do przeciążenia w klasach potomnych"""
        pass
    
    def update(self, phase):
        """Aktualizacja cząstek - do przeciążenia w klasach potomnych"""
        pass
    

    
    def set_particle_count(self, count):
        """Zmiana liczby cząstek"""
        if count != self.particle_count:
            self.particle_count = count
            self.init_particles()


class StarParticleSystem(BaseParticleSystem):
    """System cząstek gwiazd"""
    
    def init_particles(self):
        self.particles = [
            {
                'x': random.randint(0, self.width),
                'y': random.randint(0, self.height),
                'size': random.uniform(0.5, 2.5),
                'brightness': random.uniform(0.1, 0.9),
                'twinkle_speed': random.uniform(0.01, 0.05)
            } for _ in range(self.particle_count)
        ]
    
    def update(self, phase):
        for p in self.particles:
            p['current_brightness'] = p['brightness'] * (0.5 + 0.5 * math.sin(phase * p['twinkle_speed'] * 10))
    
    def render(self, painter):
        for p in self.particles:
            brightness = p.get('current_brightness', p['brightness'])
            alpha = min(255, int(220 * brightness))
            painter.setBrush(QBrush(QColor(255, 255, 255, alpha)))
            painter.setPen(QPen(QColor(0, 0, 0, 0)))  # Przezroczyste obramowanie
            painter.drawEllipse(QPoint(int(p['x']), int(p['y'])), int(p['size']), int(p['size']))


class RainParticleSystem(BaseParticleSystem):
    """System cząstek deszczu"""
    
    def init_particles(self):
        self.particles = [
            {
                'x': random.randint(0, self.width),
                'y': random.randint(-100, self.height),
                'speed': random.uniform(8, 20),  # Szybsze krople
                'length': random.uniform(20, 50),  # Dłuższe krople
                'width': random.uniform(1.5, 3)  # Szersze krople
            } for _ in range(self.particle_count)
        ]
    
    def update(self, phase):
        for p in self.particles:
            p['y'] += p['speed']
            if p['y'] > self.height:
                p['y'] = random.randint(-100, -10)
                p['x'] = random.randint(0, self.width)

    def render(self, painter):
        # Jaśniejszy niebieski kolor i zwiększona nieprzezroczystość
        painter.setPen(QPen(QColor(150, 220, 255, 230), 2))  # Grubsze, jaśniejsze i mniej przezroczyste linie
        for p in self.particles:
            painter.drawLine(int(p['x']), int(p['y']), int(p['x']), int(p['y'] + p['length']))

            # Opcjonalnie: dodaj małe "rozpryski" na końcu każdej kropli
            if random.random() < 0.3:  # Tylko dla niektórych kropli
                splash_size = random.uniform(1, 3)
                painter.setBrush(QBrush(QColor(150, 220, 255, 180)))
                painter.drawEllipse(QPointF(p['x'], p['y'] + p['length']), splash_size, splash_size * 0.5)

class SnowParticleSystem(BaseParticleSystem):
    """System cząstek śniegu"""

    def init_particles(self):
        self.particles = [
            {
                'x': random.randint(0, self.width),
                'y': random.randint(-50, self.height),
                'size': random.uniform(4, 8),  # Większe płatki śniegu
                'speed': random.uniform(1, 4),  # Trochę szybciej
                'sway': random.uniform(-1.5, 1.5),  # Większe kołysanie
                'sway_speed': random.uniform(0.01, 0.04),
                'rotation': random.uniform(0, 360),  # Dodaj rotację
                'rotation_speed': random.uniform(-2, 2)  # Prędkość rotacji
            } for _ in range(self.particle_count)
        ]

    def update(self, phase):
        for p in self.particles:
            p['y'] += p['speed']
            p['x'] += math.sin(phase * p['sway_speed']) * p['sway']
            p['rotation'] += p['rotation_speed']  # Aktualizacja rotacji
            if p['y'] > self.height:
                p['y'] = random.randint(-50, -10)
                p['x'] = random.randint(0, self.width)

    def render(self, painter):
        for p in self.particles:
            painter.save()  # Zapisz stan paintera

            # Przesuń do pozycji płatka
            painter.translate(int(p['x']), int(p['y']))
            painter.rotate(p['rotation'])  # Zastosuj rotację

            # Rysuj bardziej złożony płatek śniegu
            painter.setBrush(QBrush(QColor(255, 255, 255, 220)))  # Biały kolor, mniej przezroczysty
            painter.setPen(QPen(QColor(255, 255, 255, 180), 0.7))

            # Rysuj główny okrąg
            size = p['size']
            painter.drawEllipse(QRectF(-size / 2, -size / 2, size, size))

            # Rysuj ramiona płatka (prostsze niż prawdziwe, ale dobrze wyglądające)
            length = size * 1.2
            for angle in [0, 60, 120]:
                painter.drawLine(0, 0, int(length * math.cos(math.radians(angle))),
                                 int(length * math.sin(math.radians(angle))))
                painter.drawLine(0, 0, int(length * math.cos(math.radians(angle + 180))),
                                 int(length * math.sin(math.radians(angle + 180))))

            painter.restore()  # Przywróć stan paintera

class CloudParticleSystem(BaseParticleSystem):
    """System cząstek chmur"""
    
    def init_particles(self):
        self.particles = [
            {
                'x': random.randint(-200, self.width),
                'y': random.randint(0, int(self.height * 0.5)),
                'width': random.uniform(100, 300),
                'height': random.uniform(50, 100),
                'speed': random.uniform(0.2, 0.7),
                'opacity': random.uniform(0.1, 0.4)
            } for _ in range(self.particle_count)
        ]
    
    def update(self, phase):
        for p in self.particles:
            p['x'] += p['speed']
            if p['x'] > self.width + 200:
                p['x'] = -200 - p['width']
                p['y'] = random.randint(0, int(self.height * 0.5))
    
    def render(self, painter):
        for p in self.particles:
            # Tworzenie ścieżki chmury
            painter.save()
            
            centerX = p['x'] + p['width'] / 2
            baseY = p['y'] + p['height'] / 2
            
            # Ustawienie koloru chmury
            cloud_color = QColor(255, 255, 255, int(255 * p['opacity']))
            painter.setBrush(QBrush(cloud_color))
            painter.setPen(QPen(QColor(0, 0, 0, 0)))  # Przezroczyste obramowanie
            
            # Seria elips tworzących chmurę
            cloud_parts = [
                (centerX - p['width'] * 0.3, baseY, p['width'] * 0.4, p['height'] * 0.6),
                (centerX, baseY - p['height'] * 0.1, p['width'] * 0.5, p['height'] * 0.7),
                (centerX + p['width'] * 0.3, baseY, p['width'] * 0.4, p['height'] * 0.6),
                (centerX - p['width'] * 0.15, baseY + p['height'] * 0.1, p['width'] * 0.3, p['height'] * 0.5),
                (centerX + p['width'] * 0.15, baseY + p['height'] * 0.1, p['width'] * 0.3, p['height'] * 0.5)
            ]
            
            for cx, cy, w, h in cloud_parts:
                ellipse_rect = QRectF(int(cx - w / 2), int(cy - h / 2), int(w), int(h))
                painter.drawEllipse(ellipse_rect)
            
            painter.restore()


class ThunderParticleSystem(BaseParticleSystem):
    """System cząstek błyskawic"""

    def init_particles(self):
        self.particles = [
            {
                'x': random.randint(0, self.width),
                'y': random.randint(0, int(self.height * 0.3)),
                'length': random.uniform(150, 350),  # Dłuższe błyskawice
                'width': random.uniform(3, 5),  # Grubsze błyskawice
                'segments': random.randint(4, 8),
                'lifetime': 0,
                'max_lifetime': random.randint(10, 20),
                'active': False,
                'activation_chance': 0.03  # Zwiększona szansa aktywacji (3% zamiast 0.5%)
            } for _ in range(self.particle_count)
        ]
    
    def update(self, phase):
        for p in self.particles:
            if p['active']:
                p['lifetime'] += 1
                if p['lifetime'] > p['max_lifetime']:
                    p['active'] = False
                    p['lifetime'] = 0
            else:
                if random.random() < p['activation_chance']:
                    p['active'] = True
                    p['x'] = random.randint(0, self.width)
    
    def render(self, painter):
        import numpy as np
        for p in self.particles:
            if p['active']:
                # Wartość alpha bazująca na czasie życia błyskawicy
                life_ratio = 1.0 - (p['lifetime'] / p['max_lifetime'])
                alpha = int(255 * life_ratio)
                
                # Kolor błyskawicy z pulsującą jasnością
                thunder_color = QColor(255, 255, 100, alpha)
                glow_color = QColor(255, 255, 200, int(alpha * 0.7))
                
                painter.save()
                
                # Punkt początkowy
                start_x = p['x']
                start_y = p['y']
                
                # Główna ścieżka błyskawicy
                points = [(start_x, start_y)]
                
                # Generowanie losowych segmentów błyskawicy
                current_x = start_x
                current_y = start_y
                
                for i in range(p['segments']):
                    # Każdy segment odchyla się losowo
                    angle = random.uniform(-60, 60)
                    segment_length = p['length'] / p['segments']
                    
                    # Obliczanie końca segmentu
                    end_x = current_x + math.sin(math.radians(angle)) * segment_length
                    end_y = current_y + math.cos(math.radians(angle)) * segment_length
                    
                    points.append((end_x, end_y))
                    
                    # Przesunięcie do następnego segmentu
                    current_x = end_x
                    current_y = end_y
                
                # Rysowanie poświaty
                painter.setPen(QPen(glow_color, p['width'] + 2))
                for i in range(len(points) - 1):
                    painter.drawLine(int(points[i][0]), int(points[i][1]), 
                                     int(points[i+1][0]), int(points[i+1][1]))
                
                # Rysowanie głównej błyskawicy
                painter.setPen(QPen(thunder_color, p['width']))
                for i in range(len(points) - 1):
                    painter.drawLine(int(points[i][0]), int(points[i][1]), 
                                     int(points[i+1][0]), int(points[i+1][1]))
                
                # Losowa szansa na dodatkowe rozgałęzienia
                for i in range(1, len(points)-1):
                    if random.random() < 0.3:  # 30% szans na rozgałęzienie
                        branch_angle = random.uniform(-60, 60)
                        branch_length = p['length'] / p['segments'] * random.uniform(0.3, 0.7)
                        branch_end_x = points[i][0] + math.sin(math.radians(branch_angle)) * branch_length
                        branch_end_y = points[i][1] + math.cos(math.radians(branch_angle)) * branch_length
                        
                        # Rysowanie poświaty odgałęzienia
                        painter.setPen(QPen(glow_color, p['width'] * 0.7 + 2))
                        painter.drawLine(int(points[i][0]), int(points[i][1]), 
                                         int(branch_end_x), int(branch_end_y))
                        
                        # Rysowanie głównego odgałęzienia
                        painter.setPen(QPen(thunder_color, p['width'] * 0.7))
                        painter.drawLine(int(points[i][0]), int(points[i][1]), 
                                         int(branch_end_x), int(branch_end_y))
                
                painter.restore()


class SunlightParticleSystem(BaseParticleSystem):
    """System promieni słonecznych"""

    def init_particles(self):
        self.particles = [
            {
                'angle': random.uniform(0, 360),
                'length': random.uniform(100, 300),
                'width': random.uniform(2, 5),
                'speed': random.uniform(0.1, 0.5),
                'alpha': random.uniform(50, 150)
            } for _ in range(self.particle_count)
        ]

        # Pozycja słońca (stała)
        self.sun_x = self.width * 0.8
        self.sun_y = self.height * 0.2
        self.sun_radius = 40

    def update(self, phase):
        for p in self.particles:
            p['angle'] = (p['angle'] + p['speed']) % 360
            p['alpha'] = 50 + 100 * abs(math.sin(phase * 0.5 + p['angle'] * 0.01))

    def render(self, painter):
        # Narysuj tarczę słoneczną
        sun_grad = QRadialGradient(self.sun_x, self.sun_y, self.sun_radius * 3)
        sun_grad.setColorAt(0, QColor(255, 240, 180, 255))
        sun_grad.setColorAt(0.2, QColor(255, 210, 120, 200))
        sun_grad.setColorAt(0.7, QColor(255, 180, 60, 50))
        sun_grad.setColorAt(1, QColor(255, 180, 60, 0))

        painter.setBrush(QBrush(sun_grad))
        painter.setPen(QPen(QColor(0, 0, 0, 0)))
        painter.drawEllipse(QPointF(self.sun_x, self.sun_y), self.sun_radius * 3, self.sun_radius * 3)

        # Narysuj jaskrawą tarczę słońca
        painter.setBrush(QBrush(QColor(255, 255, 200, 255)))
        painter.drawEllipse(QPointF(self.sun_x, self.sun_y), self.sun_radius, self.sun_radius)

        # Narysuj promienie słońca
        for p in self.particles:
            angle_rad = math.radians(p['angle'])
            end_x = self.sun_x + math.cos(angle_rad) * p['length']
            end_y = self.sun_y + math.sin(angle_rad) * p['length']

            ray_pen = QPen(QColor(255, 240, 180, int(p['alpha'])), p['width'])
            ray_pen.setCapStyle(Qt.RoundCap)
            painter.setPen(ray_pen)
            painter.drawLine(int(self.sun_x), int(self.sun_y), int(end_x), int(end_y))