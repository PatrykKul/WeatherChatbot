from PyQt5.QtCore import QUrl, QObject, pyqtSignal, pyqtSlot
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent, QMediaPlaylist
import os
from utils import get_resource_path

class SoundManager(QObject):
    """
    Moduł odpowiedzialny za obsługę dźwięków w aplikacji pogodowej.
    Zarządza odtwarzaniem dźwięków tła i powiadomień.
    """
    # Sygnały
    sound_state_changed = pyqtSignal(
        bool)  # Sygnał emitowany przy zmianie stanu dźwięku (True: włączony, False: wyciszony)

    def __init__(self):
        super().__init__()

        # Stan wyciszenia
        self.muted = False

        # Utworzenie playlisty dla tła muzycznego
        self.ambient_playlist = QMediaPlaylist()
        self.ambient_playlist.setPlaybackMode(QMediaPlaylist.Loop)  # Zapętlona playlista

        # Odtwarzacz do muzyki w tle
        self.ambient_player = QMediaPlayer()
        self.ambient_player.setPlaylist(self.ambient_playlist)
        self.ambient_player.setVolume(30)  # Domyślna głośność (30%)

        # Odtwarzacz do powiadomień i alertów
        self.alert_player = QMediaPlayer()
        self.alert_player.setVolume(70)  # Głośność powiadomień (70%)

        # Ładowanie domyślnych dźwięków
        self.load_default_sounds()

    def load_default_sounds(self):
        """Ładuje domyślne dźwięki tła związane z pogodą"""
        # Ścieżki do plików dźwiękowych (względem głównego katalogu aplikacji)
        # W rzeczywistości ścieżki powinny być zależne od struktury projektu
        ambient_sounds = [
            "sounds/ambient/rain_gentle.mp3",
            "sounds/ambient/forest_morning.mp3",
            "sounds/ambient/waterfall.mp3",
            "sounds/ambient/wind_light.mp3",
            "sounds/ambient/thunder_distant.mp3"
        ]

        # Checking if files exist and adding them to playlist
        for sound_path in ambient_sounds:
            # Get the absolute path using our utility function
            full_path = get_resource_path(sound_path)
            if os.path.exists(full_path):
                url = QUrl.fromLocalFile(full_path)
                self.ambient_playlist.addMedia(QMediaContent(url))

        # Jeśli nie znaleziono żadnych plików, wyświetl ostrzeżenie
        if self.ambient_playlist.mediaCount() == 0:
            print("Uwaga: Nie znaleziono plików dźwiękowych dla tła.")

    def set_ambient_sound_for_weather(self, weather_condition):
        """
        Dostosowuje muzykę w tle do warunków pogodowych.

        Args:
            weather_condition (str): Warunki pogodowe (np. 'rain', 'clear', 'thunderstorm')
        """
        # Mapowanie warunków pogodowych na indeksy playlisty
        condition_map = {
            'rain': 0,  # Deszcz
            'clear': 3,  # Lekki wiatr
            'clouds': 1,  # Las o poranku
            'snow': 3,  # Lekki wiatr
            'thunderstorm': 4  # Odległy grzmot
        }

        # Jeśli playlista ma elementy, ustaw odpowiedni dźwięk
        if self.ambient_playlist.mediaCount() > 0:
            index = condition_map.get(weather_condition, 0)
            # Upewnij się, że indeks jest w zakresie
            if index >= self.ambient_playlist.mediaCount():
                index = 0

            self.ambient_playlist.setCurrentIndex(index)

            # Jeśli nie jest wyciszone, rozpocznij odtwarzanie
            if not self.muted:
                self.ambient_player.play()

    def toggle_mute(self):
        """Przełącza stan wyciszenia/odciszenia dźwięków"""
        self.muted = not self.muted

        if self.muted:
            # Zatrzymaj odtwarzanie i zapisz głośność
            self.stored_volume = self.ambient_player.volume()
            self.ambient_player.setVolume(0)
            self.alert_player.setVolume(0)
        else:
            # Przywróć głośność i odtwarzanie
            self.ambient_player.setVolume(self.stored_volume if hasattr(self, 'stored_volume') else 30)
            self.alert_player.setVolume(70)
            # Jeśli była muzyka w tle, wznów ją
            if self.ambient_player.state() != QMediaPlayer.PlayingState:
                self.ambient_player.play()

        # Emitowanie sygnału o zmianie stanu
        self.sound_state_changed.emit(not self.muted)

    def set_volume(self, volume):
        """
        Ustawia głośność muzyki w tle.

        Args:
            volume (int): Poziom głośności (0-100)
        """
        if not self.muted:
            self.ambient_player.setVolume(volume)
            self.stored_volume = volume

    def play_alert_sound(self, alert_type="default"):
        """
        Odtwarza dźwięk alertu/powiadomienia.

        Args:
            alert_type (str): Typ alertu ("default", "warning", "severe")
        """
        if self.muted:
            return

        # Updated alert sound loading code
        alert_sounds = {
            "default": "sounds/alerts/notification.wav",
            "warning": "sounds/alerts/warning.wav",
            "severe": "sounds/alerts/severe_alert.wav"
        }

        sound_path = alert_sounds.get(alert_type, alert_sounds["default"])
        full_path = get_resource_path(sound_path)

        if os.path.exists(full_path):
            url = QUrl.fromLocalFile(full_path)
            self.alert_player.setMedia(QMediaContent(url))
            self.alert_player.play()

    def stop_all_sounds(self):
        """Zatrzymuje wszystkie dźwięki"""
        self.ambient_player.stop()
        self.alert_player.stop()

    def cleanup(self):
        """Metoda do czyszczenia zasobów przed zamknięciem aplikacji"""
        self.stop_all_sounds()
        # Zwalniamy zasoby odtwarzaczy
        self.ambient_player.setMedia(QMediaContent())
        self.alert_player.setMedia(QMediaContent())