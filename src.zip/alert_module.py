from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QListWidget, QListWidgetItem, QPushButton,
                             QFrame, QScrollArea, QWidget, QCheckBox)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon, QColor, QFont

from datetime import datetime


class AlertModule(QDialog):
    """
    Dialog alertów pogodowych wyświetlający ważne powiadomienia.
    """

    def __init__(self, app_context):
        super().__init__()
        self.setWindowTitle("Alerty Pogodowe")
        self.setMinimumSize(600, 400)

        # Kontekst aplikacji
        self.app_context = app_context

        # Lista alertów (domyślnie pusta)
        self.alerts = []

        # Wygenerowanie przykładowych alertów
        self.generate_sample_alerts()

        # Inicjalizacja UI
        self.init_ui()

        # Ustawienie stylu zgodnego z główną aplikacją
        self.apply_style()

        # Odtworzenie dźwięku alertu jeśli dostępny
        if 'sound_manager' in self.app_context:
            sound_manager = self.app_context['sound_manager']
            if hasattr(sound_manager, 'play_alert_sound'):
                sound_manager.play_alert_sound("default")

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(10)

        # Tytuł
        title_label = QLabel("Alerty i Powiadomienia Pogodowe")
        title_label.setObjectName("alert_title")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setFont(QFont("Segoe UI", 16, QFont.Bold))

        # Filtr alertów
        filter_widget = QWidget()
        filter_widget.setObjectName("filter_widget")
        filter_layout = QHBoxLayout(filter_widget)
        filter_layout.setContentsMargins(10, 5, 10, 5)

        filter_label = QLabel("Pokaż alerty:")
        filter_label.setObjectName("filter_label")

        self.show_all_check = QCheckBox("Wszystkie")
        self.show_all_check.setObjectName("filter_checkbox")
        self.show_all_check.setChecked(True)
        self.show_all_check.stateChanged.connect(self.update_alerts_list)

        self.show_rain_check = QCheckBox("Deszcz")
        self.show_rain_check.setObjectName("filter_checkbox")
        self.show_rain_check.setChecked(True)
        self.show_rain_check.stateChanged.connect(self.update_alerts_list)

        self.show_temp_check = QCheckBox("Temperatura")
        self.show_temp_check.setObjectName("filter_checkbox")
        self.show_temp_check.setChecked(True)
        self.show_temp_check.stateChanged.connect(self.update_alerts_list)

        self.show_wind_check = QCheckBox("Wiatr")
        self.show_wind_check.setObjectName("filter_checkbox")
        self.show_wind_check.setChecked(True)
        self.show_wind_check.stateChanged.connect(self.update_alerts_list)

        self.show_storm_check = QCheckBox("Burze")
        self.show_storm_check.setObjectName("filter_checkbox")
        self.show_storm_check.setChecked(True)
        self.show_storm_check.stateChanged.connect(self.update_alerts_list)

        filter_layout.addWidget(filter_label)
        filter_layout.addWidget(self.show_all_check)
        filter_layout.addWidget(self.show_rain_check)
        filter_layout.addWidget(self.show_temp_check)
        filter_layout.addWidget(self.show_wind_check)
        filter_layout.addWidget(self.show_storm_check)
        filter_layout.addStretch()

        # Lista alertów
        self.alerts_list = QListWidget()
        self.alerts_list.setObjectName("alerts_list")
        self.alerts_list.setSpacing(8)
        self.alerts_list.setAlternatingRowColors(True)
        self.alerts_list.itemClicked.connect(self.on_alert_clicked)

        # Szczegóły alertu
        self.alert_details = QFrame()
        self.alert_details.setObjectName("alert_details")
        self.alert_details.setFrameShape(QFrame.StyledPanel)
        self.alert_details.setMinimumHeight(150)

        details_layout = QVBoxLayout(self.alert_details)
        details_layout.setContentsMargins(15, 15, 15, 15)

        self.alert_title = QLabel("Wybierz alert, aby zobaczyć szczegóły")
        self.alert_title.setObjectName("detail_title")
        self.alert_title.setFont(QFont("Segoe UI", 14, QFont.Bold))

        # Tworzenie obszaru przewijania dla treści alertu
        scroll_area = QScrollArea()
        scroll_area.setObjectName("detail_scroll_area")
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)

        # Widget zawierający treść
        content_widget = QWidget()
        content_widget.setObjectName("content_widget")
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(0, 0, 0, 0)

        self.alert_content = QLabel("")
        self.alert_content.setObjectName("detail_content")
        self.alert_content.setWordWrap(True)
        self.alert_content.setFont(QFont("Segoe UI", 12))
        self.alert_content.setTextFormat(Qt.RichText)
        self.alert_content.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.alert_content.setAutoFillBackground(False)

        content_layout.addWidget(self.alert_content)
        content_layout.addStretch()

        scroll_area.setWidget(content_widget)

        details_layout.addWidget(self.alert_title)
        details_layout.addWidget(scroll_area)

        # Przyciski
        buttons_layout = QHBoxLayout()

        self.clear_all_btn = QPushButton("Wyczyść wszystkie")
        self.clear_all_btn.setObjectName("alert_button")
        self.clear_all_btn.clicked.connect(self.clear_all_alerts)

        self.close_btn = QPushButton("Zamknij")
        self.close_btn.setObjectName("alert_button")
        self.close_btn.clicked.connect(self.accept)
        self.close_btn.setDefault(True)

        buttons_layout.addWidget(self.clear_all_btn)
        buttons_layout.addStretch()
        buttons_layout.addWidget(self.close_btn)

        # Dodanie wszystkich elementów do głównego layoutu
        main_layout.addWidget(title_label)
        main_layout.addWidget(filter_widget)
        main_layout.addWidget(self.alerts_list)
        main_layout.addWidget(self.alert_details)
        main_layout.addLayout(buttons_layout)

        # Wypełnienie listy alertów
        self.update_alerts_list()

    def generate_sample_alerts(self):
        """Generuje przykładowe alerty do demonstracji"""
        self.alerts = [
            {
                "id": 1,
                "title": "Ostrzeżenie przed silnym deszczem",
                "message": "Przewidywane są intensywne opady deszczu przekraczające 30mm/h w ciągu najbliższych 6 godzin. Może wystąpić lokalne podtopienie.",
                "type": "rain",
                "severity": "warning",  # info, warning, alert
                "city": "Warszawa",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "read": False
            },
            {
                "id": 2,
                "title": "Alert: fala upałów",
                "message": "Temperatura osiągnie ponad 35°C w ciągu najbliższych 3 dni. Zalecane ograniczenie aktywności na powietrzu w godzinach 11:00-16:00 i zwiększenie nawodnienia.",
                "type": "temp",
                "severity": "alert",
                "city": "Kraków",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "read": False
            },
            {
                "id": 3,
                "title": "Ostrzeżenie przed silnym wiatrem",
                "message": "Przewidywana prędkość wiatru do 90 km/h. Możliwe uszkodzenia dachów i drzew. Zalecane zabezpieczenie luźnych przedmiotów na zewnątrz.",
                "type": "wind",
                "severity": "warning",
                "city": "Gdańsk",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "read": False
            },
            {
                "id": 4,
                "title": "Informacja: znaczny spadek temperatury",
                "message": "W nocy spodziewany jest spadek temperatury o około 15°C. Temperatura minimalna może wynieść -2°C, możliwe przymrozki.",
                "type": "temp",
                "severity": "info",
                "city": "Zakopane",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "read": True
            },
            {
                "id": 5,
                "title": "Alert: burze z gradem",
                "message": "Prognozowane są silne burze z gradem do 2cm średnicy. Możliwe lokalne podtopienia i uszkodzenia pojazdów.",
                "type": "storm",
                "severity": "alert",
                "city": "Wrocław",
                "time": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "read": False
            }
        ]

    def update_alerts_list(self):
        """Aktualizuje listę alertów zgodnie z wybranymi filtrami"""
        # Wyczyszczenie listy
        self.alerts_list.clear()

        # Sprawdzenie, które filtry są aktywne
        show_all = self.show_all_check.isChecked()
        show_rain = show_all or self.show_rain_check.isChecked()
        show_temp = show_all or self.show_temp_check.isChecked()
        show_wind = show_all or self.show_wind_check.isChecked()
        show_storm = show_all or self.show_storm_check.isChecked()

        # Mapowanie typów alertów na flagi filtrów
        type_filters = {
            "rain": show_rain,
            "temp": show_temp,
            "wind": show_wind,
            "storm": show_storm
        }

        # Dodanie pasujących alertów do listy
        for alert in self.alerts:
            if type_filters.get(alert["type"], True):
                self.add_alert_to_list(alert)

    def add_alert_to_list(self, alert):
        """Dodaje pojedynczy alert do listy"""
        # Tworzenie widgetu elementu listy
        item = QListWidgetItem()
        item.setData(Qt.UserRole, alert)  # Przechowywanie danych alertu

        # Wysokość elementu na liście
        item.setSizeHint(QSize(0, 75))

        # Tworzenie widgetu zawartości elementu
        widget = QWidget()
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(10, 5, 10, 5)

        # Ikona alertu
        icon_label = QLabel()
        icon_label.setFixedSize(45, 45)
        icon_label.setObjectName("alert_icon")

        # Ustawienie ikony w zależności od typu alertu
        icon_text = {
            "rain": "🌧",
            "temp": "🌡️",
            "wind": "🌬️",
            "storm": "⛈️"
        }.get(alert["type"], "⚠️")

        icon_label.setText(icon_text)
        icon_label.setAlignment(Qt.AlignCenter)
        icon_label.setFont(QFont("Segoe UI Symbol", 22))

        # Tytuł i miasto
        text_widget = QWidget()
        text_layout = QVBoxLayout(text_widget)
        text_layout.setContentsMargins(5, 0, 0, 0)
        text_layout.setSpacing(3)

        title_label = QLabel(alert["title"])
        title_label.setObjectName("alert_item_title" if not alert["read"] else "alert_item_title_read")
        title_label.setFont(QFont("Segoe UI", 12, QFont.Bold if not alert["read"] else QFont.Normal))

        city_label = QLabel(f"{alert['city']} | {alert['time']}")
        city_label.setObjectName("alert_item_subtitle")
        city_label.setFont(QFont("Segoe UI", 10))

        text_layout.addWidget(title_label)
        text_layout.addWidget(city_label)

        # Wskaźnik ważności
        severity_indicator = QLabel()
        severity_indicator.setFixedSize(18, 45)
        severity_indicator.setObjectName("severity_indicator")

        # Kolor w zależności od ważności
        severity_color = {
            "info": "#4dabf7",  # Niebieski (informacja)
            "warning": "#ffa94d",  # Pomarańczowy (ostrzeżenie)
            "alert": "#ff6b6b"  # Czerwony (alert)
        }.get(alert["severity"], "#4dabf7")

        severity_indicator.setStyleSheet(
            f"background-color: {severity_color}; border-radius: 5px; border: 1px solid rgba(255, 255, 255, 0.3);")

        # Dodanie wszystkich elementów do układu
        layout.addWidget(icon_label)
        layout.addWidget(text_widget, 1)  # Dajemy mu stretch factor
        layout.addWidget(severity_indicator)

        # Dodanie elementu do listy
        self.alerts_list.addItem(item)
        self.alerts_list.setItemWidget(item, widget)

    def on_alert_clicked(self, item):
        """Obsługa kliknięcia na element listy"""
        # Pobranie danych alertu
        alert = item.data(Qt.UserRole)

        # Oznaczenie alertu jako przeczytanego
        alert["read"] = True

        # Aktualizacja szczegółów alertu
        self.alert_title.setText(alert["title"])

        # Przygotowanie treści szczegółów
        details_text = f"""
        <p style='margin-bottom: 12px; color: #a0e7ff;'><b>Miasto:</b> {alert["city"]}</p>
        <p style='margin-bottom: 12px; color: #a0e7ff;'><b>Czas:</b> {alert["time"]}</p>
        <p style='margin-bottom: 12px; color: #a0e7ff;'><b>Typ:</b> {self.get_alert_type_name(alert["type"])}</p>
        <p style='margin-bottom: 12px; color: #a0e7ff;'><b>Waga:</b> <span style='color: {self.get_severity_color(alert["severity"])};'>{self.get_severity_name(alert["severity"])}</span></p>
        <p style='margin-top: 20px; color: #a0e7ff;'><b>Szczegóły:</b><br>{alert["message"]}</p>
        """

        self.alert_content.setText(details_text)

        # Odświeżenie listy, aby zaktualizować wygląd przeczytanego alertu
        self.update_alerts_list()

    def get_alert_type_name(self, alert_type):
        """Zwraca czytelną nazwę typu alertu"""
        return {
            "rain": "Opady",
            "temp": "Temperatura",
            "wind": "Wiatr",
            "storm": "Burza"
        }.get(alert_type, "Inny")

    def get_severity_name(self, severity):
        """Zwraca czytelną nazwę ważności alertu"""
        return {
            "info": "Informacja",
            "warning": "Ostrzeżenie",
            "alert": "Alert"
        }.get(severity, "Nieznany")

    def get_severity_color(self, severity):
        """Zwraca kolor odpowiadający ważności alertu"""
        return {
            "info": "#4dabf7",  # Niebieski (informacja)
            "warning": "#ffa94d",  # Pomarańczowy (ostrzeżenie)
            "alert": "#ff6b6b"  # Czerwony (alert)
        }.get(severity, "#4dabf7")

    def clear_all_alerts(self):
        """Czyści wszystkie alerty"""
        self.alerts = []
        self.update_alerts_list()

        # Wyczyszczenie szczegółów
        self.alert_title.setText("Wszystkie alerty zostały wyczyszczone")
        self.alert_content.setText("")

    def apply_style(self):
        """Stosuje styl spójny z główną aplikacją"""
        self.setStyleSheet("""
            /* Główne tło */
            QDialog {
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(15, 32, 64, 0.95),
                    stop:1 rgba(30, 64, 128, 0.95)
                );
                border: 2px solid #4dabf7;
                border-radius: 10px;
            }

            /* Tytuł */
            QLabel#alert_title {
                color: #4dabf7;
                font-size: 22px;
                font-weight: bold;
                padding: 10px;
                text-shadow: 0 0 10px rgba(77, 171, 247, 0.5);
            }

            /* Filtry */
            QWidget#filter_widget {
                background-color: rgba(15, 32, 64, 0.7);
                border: 1px solid #4dabf7;
                border-radius: 8px;
                padding: 5px;
            }

            QLabel#filter_label {
                color: #a0e7ff;
                font-weight: bold;
            }

            QCheckBox#filter_checkbox {
                color: #a0e7ff;
                spacing: 5px;
            }

            QCheckBox#filter_checkbox::indicator {
                width: 18px;
                height: 18px;
                border: 2px solid #4dabf7;
                border-radius: 3px;
                background-color: transparent;
            }

            QCheckBox#filter_checkbox::indicator:checked {
                background-color: rgba(77, 171, 247, 0.5);
            }

            QCheckBox#filter_checkbox::indicator:hover {
                border-color: #a0e7ff;
            }

            /* Lista alertów */
            QListWidget#alerts_list {
                background-color: transparent;
                border: 2px solid #4dabf7;
                border-radius: 10px;
                padding: 5px;
                alternate-background-color: rgba(77, 171, 247, 0.1);
            }

            QListWidget#alerts_list::item {
                border-radius: 8px;
                margin: 2px;
            }

            QListWidget#alerts_list::item:selected {
                background-color: rgba(77, 171, 247, 0.3);
                border: 1px solid #a0e7ff;
            }

            QListWidget#alerts_list::item:hover {
                background-color: rgba(77, 171, 247, 0.2);
            }

            /* Elementy alertów */
            QLabel#alert_icon {
                background-color: rgba(15, 32, 64, 0.5);
                border: 2px solid #4dabf7;
                border-radius: 22px;
                padding: 5px;
                color: #a0e7ff;
            }

            QLabel#alert_item_title {
                color: #a0e7ff;
                font-weight: bold;
            }

            QLabel#alert_item_title_read {
                color: #8acdff;
                font-weight: normal;
            }

            QLabel#alert_item_subtitle {
                color: #7ba7c7;
            }

            /* Panel szczegółów */
            QFrame#alert_details {
                background-color: rgba(15, 32, 64, 0.7);
                border: 2px solid #4dabf7;
                border-radius: 10px;
            }

            QLabel#detail_title {
                color: #4dabf7;
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
                text-shadow: 0 0 8px rgba(77, 171, 247, 0.4);
            }

            QLabel#detail_content {
                color: #a0e7ff;
                margin-top: 10px;
                line-height: 150%;
            }

            /* Obszar przewijania */
            QScrollArea#detail_scroll_area {
                background-color: transparent;
                border: none;
            }

            QWidget#content_widget {
                background-color: transparent;
            }

            /* Pasek przewijania */
            QScrollBar:vertical {
                background-color: rgba(15, 32, 64, 0.5);
                width: 10px;
                margin: 0px;
                border-radius: 5px;
            }

            QScrollBar::handle:vertical {
                background-color: rgba(77, 171, 247, 0.5);
                min-height: 20px;
                border-radius: 5px;
            }

            QScrollBar::handle:vertical:hover {
                background-color: rgba(77, 171, 247, 0.8);
            }

            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }

            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background-color: transparent;
            }

            /* Przyciski */
            QPushButton#alert_button {
                background-color: rgba(77, 171, 247, 0.2);
                border: 2px solid #4dabf7;
                border-radius: 8px;
                color: #a0e7ff;
                font-weight: bold;
                padding: 8px 16px;
                min-width: 120px;
                min-height: 30px;
            }

            QPushButton#alert_button:hover {
                background-color: rgba(77, 171, 247, 0.4);
                border-color: #a0e7ff;
            }

            QPushButton#alert_button:pressed {
                background-color: rgba(77, 171, 247, 0.6);
            }
        """)