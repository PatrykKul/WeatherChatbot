# src/utils.py
import os


def get_resource_path(relative_path):
    """Zwraca absolutną ścieżkę do zasobu względem katalogu głównego projektu."""
    # Lokalizacja bieżącego pliku
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Katalog główny projektu
    if os.path.basename(current_dir) == 'src':
        base_dir = os.path.dirname(current_dir)
    else:
        base_dir = current_dir

    # Pełna ścieżka do zasobu
    full_path = os.path.join(base_dir, relative_path)

    # Upewnij się, że katalog istnieje
    directory = os.path.dirname(full_path)
    if not os.path.exists(directory):
        os.makedirs(directory)

    return full_path


def get_project_root():
    """
    Zwraca ścieżkę do katalogu głównego projektu, niezależnie od tego,
    gdzie znajduje się wywołujący skrypt.

    Returns:
        str: Absolutna ścieżka do katalogu głównego projektu
    """
    # Lokalizacja bieżącego pliku
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Jeśli bieżący plik jest w katalogu src, zwróć katalog nadrzędny
    if os.path.basename(current_dir) == 'src':
        return os.path.dirname(current_dir)

    # W przeciwnym razie zwróć bieżący katalog (zakładamy, że to główny katalog projektu)
    return current_dir


def ensure_dir_exists(directory_path):
    """
    Upewnia się, że katalog istnieje, tworząc go w razie potrzeby.

    Args:
        directory_path (str): Ścieżka do katalogu
    """
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)