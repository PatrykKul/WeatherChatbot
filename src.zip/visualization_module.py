
import math
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QFrame, QSizePolicy, QGridLayout, QPushButton)
from PyQt5.QtCore import Qt, QRectF, QPoint, QRect
from PyQt5.QtGui import QFont, QColor, QPainter, QPen, QBrush, QLinearGradient

# Importowanie zewnętrznych bibliotek
try:
    import pyqtgraph as pg
    import numpy as np

    PYQTGRAPH_AVAILABLE = True
except ImportError:
    PYQTGRAPH_AVAILABLE = False
    print("PyQtGraph nie jest dostępny. Niektóre wykresy mogą być niedostępne.")


class WeatherInfoWidget(QFrame):
    """
    Widget wyświetlający aktualne informacje o pogodzie.
    """

    def __init__(self):
        super().__init__()
        self.setObjectName("weather_info_widget")
        self.setMinimumHeight(200)

        # Dane pogodowe
        self.weather_data = None

        # Jednostka temperatury
        self.temp_unit = "celsius"

        # Inicjalizacja UI
        self.init_ui()

    def init_ui(self):
        # Słownik tłumaczeń (dodaj jako atrybut klasy)
        self.labels_translations = {
            "pl": {
                "feels_like": "Odczuwalna:",
                "min": "Min:",
                "max": "Max:",
                "humidity": "Wilgotność:",
                "pressure": "Ciśnienie:",
                "wind": "Wiatr:",
                "clouds": "Zachmurzenie:",
                "sunrise": "Wschód:",
                "sunset": "Zachód:"
            },
            "en": {
                "feels_like": "Feels like:",
                "min": "Min:",
                "max": "Max:",
                "humidity": "Humidity:",
                "pressure": "Pressure:",
                "wind": "Wind:",
                "clouds": "Clouds:",
                "sunrise": "Sunrise:",
                "sunset": "Sunset:"
            }
        }

        # Domyślny język
        self.current_language = "pl"

        # Główny układ
        main_layout = QGridLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Lewy panel - ikona pogody
        self.weather_icon = QLabel()
        self.weather_icon.setObjectName("weather_icon")
        self.weather_icon.setAlignment(Qt.AlignCenter)
        self.weather_icon.setFont(QFont("Segoe UI Symbol", 72))  # Duża czcionka dla emoji
        self.weather_icon.setText("🌡️")  # Domyślna ikona

        # Środkowy panel - temperatura i warunki
        center_panel = QWidget()
        center_layout = QVBoxLayout(center_panel)
        center_layout.setAlignment(Qt.AlignCenter)

        self.city_label = QLabel("--")
        self.city_label.setObjectName("city_label")
        self.city_label.setAlignment(Qt.AlignCenter)

        self.temperature_label = QLabel("--°C")
        self.temperature_label.setObjectName("temperature_label")
        self.temperature_label.setAlignment(Qt.AlignCenter)

        self.condition_label = QLabel("--")
        self.condition_label.setObjectName("condition_label")
        self.condition_label.setAlignment(Qt.AlignCenter)

        center_layout.addWidget(self.city_label)
        center_layout.addWidget(self.temperature_label)
        center_layout.addWidget(self.condition_label)

        # Prawy panel - szczegóły
        details_panel = QWidget()
        details_layout = QGridLayout(details_panel)

        # Etykiety szczegółów - najpierw tworzymy etykiety wartości
        self.feels_like_label = QLabel("--")
        self.temp_min_label = QLabel("--")
        self.temp_max_label = QLabel("--")
        self.humidity_label = QLabel("--")
        self.pressure_label = QLabel("--")
        self.wind_label = QLabel("--")
        self.clouds_label = QLabel("--")
        self.sunrise_label = QLabel("--")
        self.sunset_label = QLabel("--")

        # Ustawienie nazw obiektów dla etykiet
        detail_labels = [
            self.feels_like_label, self.temp_min_label, self.temp_max_label,
            self.humidity_label, self.pressure_label, self.wind_label,
            self.clouds_label, self.sunrise_label, self.sunset_label
        ]

        for label in detail_labels:
            label.setObjectName("detail_label")
            label.setAlignment(Qt.AlignLeft)

        # Teraz tworzymy etykiety opisów i zapisujemy je jako atrybuty
        self.feels_like_text = QLabel(f"<b>{self.labels_translations[self.current_language]['feels_like']}</b>")
        self.temp_min_text = QLabel(f"<b>{self.labels_translations[self.current_language]['min']}</b>")
        self.temp_max_text = QLabel(f"<b>{self.labels_translations[self.current_language]['max']}</b>")
        self.humidity_text = QLabel(f"<b>{self.labels_translations[self.current_language]['humidity']}</b>")
        self.pressure_text = QLabel(f"<b>{self.labels_translations[self.current_language]['pressure']}</b>")
        self.wind_text = QLabel(f"<b>{self.labels_translations[self.current_language]['wind']}</b>")
        self.clouds_text = QLabel(f"<b>{self.labels_translations[self.current_language]['clouds']}</b>")
        self.sunrise_text = QLabel(f"<b>{self.labels_translations[self.current_language]['sunrise']}</b>")
        self.sunset_text = QLabel(f"<b>{self.labels_translations[self.current_language]['sunset']}</b>")

        # Dodawanie etykiet do układu szczegółów
        details_layout.addWidget(self.feels_like_text, 0, 0)
        details_layout.addWidget(self.feels_like_label, 0, 1)
        details_layout.addWidget(self.temp_min_text, 1, 0)
        details_layout.addWidget(self.temp_min_label, 1, 1)
        details_layout.addWidget(self.temp_max_text, 2, 0)
        details_layout.addWidget(self.temp_max_label, 2, 1)
        details_layout.addWidget(self.humidity_text, 3, 0)
        details_layout.addWidget(self.humidity_label, 3, 1)
        details_layout.addWidget(self.pressure_text, 4, 0)
        details_layout.addWidget(self.pressure_label, 4, 1)
        details_layout.addWidget(self.wind_text, 5, 0)
        details_layout.addWidget(self.wind_label, 5, 1)
        details_layout.addWidget(self.clouds_text, 6, 0)
        details_layout.addWidget(self.clouds_label, 6, 1)
        details_layout.addWidget(self.sunrise_text, 7, 0)
        details_layout.addWidget(self.sunrise_label, 7, 1)
        details_layout.addWidget(self.sunset_text, 8, 0)
        details_layout.addWidget(self.sunset_label, 8, 1)

        # Dodanie paneli do głównego układu
        main_layout.addWidget(self.weather_icon, 0, 0, 3, 2)
        main_layout.addWidget(center_panel, 0, 2, 3, 3)
        main_layout.addWidget(details_panel, 0, 5, 3, 3)

        # Ustawienie proporcji kolumn
        main_layout.setColumnStretch(0, 2)  # Ikona
        main_layout.setColumnStretch(2, 3)  # Temperatura i warunki
        main_layout.setColumnStretch(5, 3)  # Szczegóły

    def apply_language(self, language):
        """Aktualizuje język interfejsu panelu informacji pogodowych"""
        if language not in ["pl", "en"]:
            return

        self.current_language = language

        # Aktualizacja etykiet opisów
        if hasattr(self, 'feels_like_text'):
            self.feels_like_text.setText(f"<b>{self.labels_translations[language]['feels_like']}</b>")
        if hasattr(self, 'temp_min_text'):
            self.temp_min_text.setText(f"<b>{self.labels_translations[language]['min']}</b>")
        if hasattr(self, 'temp_max_text'):
            self.temp_max_text.setText(f"<b>{self.labels_translations[language]['max']}</b>")
        if hasattr(self, 'humidity_text'):
            self.humidity_text.setText(f"<b>{self.labels_translations[language]['humidity']}</b>")
        if hasattr(self, 'pressure_text'):
            self.pressure_text.setText(f"<b>{self.labels_translations[language]['pressure']}</b>")
        if hasattr(self, 'wind_text'):
            self.wind_text.setText(f"<b>{self.labels_translations[language]['wind']}</b>")
        if hasattr(self, 'clouds_text'):
            self.clouds_text.setText(f"<b>{self.labels_translations[language]['clouds']}</b>")
        if hasattr(self, 'sunrise_text'):
            self.sunrise_text.setText(f"<b>{self.labels_translations[language]['sunrise']}</b>")
        if hasattr(self, 'sunset_text'):
            self.sunset_text.setText(f"<b>{self.labels_translations[language]['sunset']}</b>")

        # Aktualizacja opisu pogody
        if hasattr(self, 'condition_label') and self.condition_label:
            current_text = self.condition_label.text()
            # Tłumaczenia konkretnych opisów pogody
            weather_translations = {
                "pl": {
                    "Zachmurzenie duże": "Zachmurzenie duże",
                    "Pochmurno": "Pochmurno",
                    "Słonecznie": "Słonecznie",
                    "Bezchmurnie": "Bezchmurnie",
                    "Deszcz": "Deszcz",
                    "Śnieg": "Śnieg",
                    "Burza": "Burza",
                    "Mgła": "Mgła"
                },
                "en": {
                    "Zachmurzenie duże": "Overcast",
                    "Pochmurno": "Cloudy",
                    "Słonecznie": "Sunny",
                    "Bezchmurnie": "Clear",
                    "Deszcz": "Rain",
                    "Śnieg": "Snow",
                    "Burza": "Thunderstorm",
                    "Mgła": "Fog"
                }
            }

            # Sprawdź czy tekst znajduje się w słowniku tłumaczeń
            for pl_text, en_text in weather_translations["pl"].items():
                if language == "en" and pl_text in current_text:
                    self.condition_label.setText(weather_translations["en"][pl_text])
                    break
                elif language == "pl" and en_text in current_text:
                    # Znajdź odpowiedni klucz
                    for pl_key, en_val in weather_translations["en"].items():
                        if en_val == en_text:
                            self.condition_label.setText(pl_key)
                            break


    def update_weather(self, data):
        """
        Aktualizacja danych pogodowych.

        Args:
            data (dict): Dane pogodowe z API
        """
        if not data or not data.get('success', False):
            return

        self.weather_data = data

        # Aktualizacja etykiet
        self.city_label.setText(f"{data['city']}, {data['country']}")

        # Temperatura w zależności od wybranej jednostki
        temp = data['temperature']['current']
        temp_feel = data['temperature']['feels_like']
        temp_min = data['temperature']['min']
        temp_max = data['temperature']['max']

        if self.temp_unit == "fahrenheit":
            temp = self.celsius_to_fahrenheit(temp)
            temp_feel = self.celsius_to_fahrenheit(temp_feel)
            temp_min = self.celsius_to_fahrenheit(temp_min)
            temp_max = self.celsius_to_fahrenheit(temp_max)
        elif self.temp_unit == "kelvin":
            temp = self.celsius_to_kelvin(temp)
            temp_feel = self.celsius_to_kelvin(temp_feel)
            temp_min = self.celsius_to_kelvin(temp_min)
            temp_max = self.celsius_to_kelvin(temp_max)

        temp_symbol = self.get_temp_unit_symbol()

        self.temperature_label.setText(f"{temp:.1f}{temp_symbol}")
        self.condition_label.setText(data['weather']['description'].capitalize())

        self.feels_like_label.setText(f"{temp_feel:.1f}{temp_symbol}")
        self.temp_min_label.setText(f"{temp_min:.1f}{temp_symbol}")
        self.temp_max_label.setText(f"{temp_max:.1f}{temp_symbol}")
        self.humidity_label.setText(f"{data['humidity']}%")
        self.pressure_label.setText(f"{data['pressure']} hPa")
        self.wind_label.setText(f"{data['wind']['speed']} m/s")
        self.clouds_label.setText(f"{data['clouds']}%")
        self.sunrise_label.setText(data['sunrise'])
        self.sunset_label.setText(data['sunset'])

        # Ustawienie ikony pogodowej
        self.weather_icon.setText(self.get_weather_icon(data['weather']['icon']))

    def set_temperature_unit(self, unit):
        """
        Ustawienie jednostki temperatury.

        Args:
            unit (str): Jednostka temperatury ('celsius', 'fahrenheit' lub 'kelvin')
        """
        if unit in ["celsius", "fahrenheit", "kelvin"]:
            self.temp_unit = unit

            # Aktualizacja widoku jeśli mamy dane
            if self.weather_data:
                self.update_weather(self.weather_data)

    def celsius_to_fahrenheit(self, celsius):
        """Konwersja Celsjusza na Fahrenheita"""
        return (celsius * 9 / 5) + 32

    def celsius_to_kelvin(self, celsius):
        """Konwersja Celsjusza na Kelvina"""
        return celsius + 273.15

    def get_temp_unit_symbol(self):
        """Zwraca symbol jednostki temperatury"""
        if self.temp_unit == "celsius":
            return "°C"
        elif self.temp_unit == "fahrenheit":
            return "°F"
        elif self.temp_unit == "kelvin":
            return "K"
        return "°C"

    def get_weather_icon(self, icon_code):
        """
        Zwraca emoji odpowiadające kodowi ikony pogodowej.

        Args:
            icon_code (str): Kod ikony z API pogodowego

        Returns:
            str: Emoji pogodowe
        """
        icons = {
            '01d': '☀️', '01n': '🌙',  # Bezchmurnie
            '02d': '⛅', '02n': '🌙☁️',  # Niewielkie zachmurzenie
            '03d': '☁️', '03n': '☁️',  # Zachmurzenie
            '04d': '☁️☁️', '04n': '☁️☁️',  # Duże zachmurzenie
            '09d': '🌧️', '09n': '🌧️',  # Przelotny deszcz
            '10d': '🌦️', '10n': '🌧️',  # Deszcz
            '11d': '⛈️', '11n': '⛈️',  # Burza
            '13d': '❄️', '13n': '❄️',  # Śnieg
            '50d': '🌫️', '50n': '🌫️'  # Mgła
        }
        return icons.get(icon_code, '🌡️')  # Domyślna ikona termometru


class WeatherForecastWidget(QWidget):
    """
    Widget wyświetlający prognozę pogody w formie kart.
    """

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(280)

        # Dane prognozy
        self.forecast_data = []

        # Jednostka temperatury
        self.temp_unit = "celsius"

        # Inicjalizacja UI
        self.init_ui()

    def init_ui(self):
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(10, 10, 10, 10)
        self.setLayout(self.layout)

    def update_forecast(self, forecast_data):
        """
        Aktualizacja prognozy pogody.

        Args:
            forecast_data (list): Lista danych prognozy
        """
        # Zapisanie danych
        self.forecast_data = forecast_data

        # Wyczyszczenie poprzednich danych
        self._clear_layout()

        # Dodanie nowych kart prognozy
        for day_data in forecast_data:
            card = self._create_forecast_card(day_data)
            self.layout.addWidget(card)

        # Dodanie rozciągacza, aby karty były wyrównane do lewej
        self.layout.addStretch()

        # W pliku visualization_module.py, w klasie WeatherInfoWidget:

        def apply_language(self, language):
            """Aktualizuje język interfejsu panelu informacji pogodowych"""
            translations = {
                "pl": {
                    "feels_like": "Odczuwalna:",
                    "min": "Min:",
                    "max": "Max:",
                    "humidity": "Wilgotność:",
                    "pressure": "Ciśnienie:",
                    "wind": "Wiatr:",
                    "clouds": "Zachmurzenie:",
                    "sunrise": "Wschód:",
                    "sunset": "Zachód:",
                    "overcast": "Zachmurzenie duże"  # Dodajemy tłumaczenia dla opisów pogody
                },
                "en": {
                    "feels_like": "Feels like:",
                    "min": "Min:",
                    "max": "Max:",
                    "humidity": "Humidity:",
                    "pressure": "Pressure:",
                    "wind": "Wind:",
                    "clouds": "Clouds:",
                    "sunrise": "Sunrise:",
                    "sunset": "Sunset:",
                    "overcast": "Overcast"  # Angielskie odpowiedniki
                }
            }

            # Bezpośrednie odwołanie do etykiet, które są przechowywane jako atrybuty klasy
            if hasattr(self, "feels_like_label"):
                self.feels_like_label.setText(f"<b>{translations[language]['feels_like']}</b>")

            if hasattr(self, "temp_min_label"):
                self.temp_min_label.setText(f"<b>{translations[language]['min']}</b>")

            if hasattr(self, "temp_max_label"):
                self.temp_max_label.setText(f"<b>{translations[language]['max']}</b>")

            if hasattr(self, "humidity_label"):
                # Pobieramy obecną wartość
                current_value = self.humidity_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.humidity_label.setText(f"{translations[language]['humidity']} {value}")

            if hasattr(self, "pressure_label"):
                current_value = self.pressure_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.pressure_label.setText(f"{translations[language]['pressure']} {value}")

            if hasattr(self, "wind_label"):
                current_value = self.wind_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.wind_label.setText(f"{translations[language]['wind']} {value}")

            if hasattr(self, "clouds_label"):
                current_value = self.clouds_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.clouds_label.setText(f"{translations[language]['clouds']} {value}")

            if hasattr(self, "sunrise_label"):
                current_value = self.sunrise_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.sunrise_label.setText(f"{translations[language]['sunrise']} {value}")

            if hasattr(self, "sunset_label"):
                current_value = self.sunset_label.text()
                value = current_value.split(":")[1].strip() if ":" in current_value else ""
                self.sunset_label.setText(f"{translations[language]['sunset']} {value}")

            # Tłumaczenie opisu pogody
            if hasattr(self, "condition_label") and self.condition_label:
                current_text = self.condition_label.text()
                # Sprawdzamy czy tekst obecny jest w słowniku tłumaczeń
                for pl_text, en_text in zip(translations["pl"].values(), translations["en"].values()):
                    if language == "en" and pl_text in current_text:
                        # Zamieniamy polski tekst na angielski
                        self.condition_label.setText(en_text)
                        break
                    elif language == "pl" and en_text in current_text:
                        # Zamieniamy angielski tekst na polski
                        self.condition_label.setText(pl_text)
                        break


    def set_temperature_unit(self, unit):
        """
        Ustawienie jednostki temperatury.

        Args:
            unit (str): Jednostka temperatury ('celsius', 'fahrenheit' lub 'kelvin')
        """
        if unit in ["celsius", "fahrenheit", "kelvin"]:
            self.temp_unit = unit

            # Aktualizacja widoku jeśli mamy dane
            if self.forecast_data:
                self.update_forecast(self.forecast_data)

    def _clear_layout(self):
        """Czyści układ z kart prognozy"""
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _create_forecast_card(self, day_data):
        """
        Tworzy kartę prognozy dla danego dnia.

        Args:
            day_data (dict): Dane pogodowe na dany dzień

        Returns:
            QFrame: Karta prognozy
        """
        card = QFrame()
        card.setObjectName("forecast_card")
        card.setFixedWidth(180)
        card.setMinimumHeight(260)

        card_layout = QVBoxLayout()

        # Data
        date_label = QLabel(day_data.get('date', '--'))
        date_label.setAlignment(Qt.AlignCenter)
        date_label.setObjectName("forecast_date")

        # Dzień tygodnia (jeśli dostępny)
        if 'day_name' in day_data:
            day_name_label = QLabel(day_data['day_name'])
            day_name_label.setAlignment(Qt.AlignCenter)
            day_name_label.setObjectName("forecast_day_name")
            card_layout.addWidget(day_name_label)

        # Czas (jeśli dostępny)
        if 'time' in day_data:
            time_label = QLabel(day_data['time'])
            time_label.setAlignment(Qt.AlignCenter)
            time_label.setObjectName("forecast_time")
            card_layout.addWidget(time_label)
        else:
            card_layout.addWidget(date_label)

        # Ikona
        icon_label = QLabel()
        icon_code = day_data.get('icon', '')
        icon_label.setText(self.get_weather_icon(icon_code))
        icon_label.setAlignment(Qt.AlignCenter)
        icon_label.setObjectName("forecast_icon")
        icon_label.setFont(QFont("Segoe UI Symbol", 48))  # Duża czcionka dla emoji

        # Temperatura
        temp_min = day_data.get('temp_min', 0)
        temp_max = day_data.get('temp_max', 0)

        # Konwersja jednostek
        if self.temp_unit == "fahrenheit":
            temp_min = self.celsius_to_fahrenheit(temp_min)
            temp_max = self.celsius_to_fahrenheit(temp_max)
        elif self.temp_unit == "kelvin":
            temp_min = self.celsius_to_kelvin(temp_min)
            temp_max = self.celsius_to_kelvin(temp_max)

        temp_symbol = self.get_temp_unit_symbol()

        # Obsługa pojedynczej temperatury (dane godzinowe)
        if 'temp' in day_data:
            temp = day_data['temp']
            if self.temp_unit == "fahrenheit":
                temp = self.celsius_to_fahrenheit(temp)
            elif self.temp_unit == "kelvin":
                temp = self.celsius_to_kelvin(temp)

            temp_label = QLabel(f"{temp:.1f}{temp_symbol}")
        else:
            temp_label = QLabel(f"{temp_max:.1f}{temp_symbol} / {temp_min:.1f}{temp_symbol}")

        temp_label.setAlignment(Qt.AlignCenter)
        temp_label.setObjectName("forecast_temp")

        # Opis
        desc_label = QLabel(day_data.get('description', '--'))
        desc_label.setAlignment(Qt.AlignCenter)
        desc_label.setObjectName("forecast_desc")
        desc_label.setWordWrap(True)

        # Wilgotność
        humidity_value = day_data.get('humidity', '--')
        if isinstance(humidity_value, (int, float)):
            humidity_label = QLabel(f"Wilgotność: {humidity_value:.2f}%")
        else:
            humidity_label = QLabel(f"Wilgotność: {humidity_value}%")
        humidity_label.setAlignment(Qt.AlignCenter)

        # Wiatr
        wind_label = QLabel(f"Wiatr: {day_data.get('wind_speed', '--'):.2f} m/s")
        wind_label.setAlignment(Qt.AlignCenter)

        # Prawdopodobieństwo opadów (jeśli dostępne)
        if 'pop' in day_data:
            pop = day_data['pop'] * 100 if isinstance(day_data['pop'], float) else day_data['pop']
            pop_label = QLabel(f"Opady: {pop:.0f}%")
            pop_label.setAlignment(Qt.AlignCenter)
            card_layout.addWidget(pop_label)

        # Dodanie elementów do karty
        card_layout.addWidget(icon_label)
        card_layout.addWidget(temp_label)
        card_layout.addWidget(desc_label)
        card_layout.addWidget(humidity_label)
        card_layout.addWidget(wind_label)

        card.setLayout(card_layout)
        return card

    def celsius_to_fahrenheit(self, celsius):
        """Konwersja Celsjusza na Fahrenheita"""
        return (celsius * 9 / 5) + 32

    def celsius_to_kelvin(self, celsius):
        """Konwersja Celsjusza na Kelvina"""
        return celsius + 273.15

    def get_temp_unit_symbol(self):
        """Zwraca symbol jednostki temperatury"""
        if self.temp_unit == "celsius":
            return "°C"
        elif self.temp_unit == "fahrenheit":
            return "°F"
        elif self.temp_unit == "kelvin":
            return "K"
        return "°C"

    def get_weather_icon(self, icon_code):
        """
        Zwraca emoji odpowiadające kodowi ikony pogodowej.

        Args:
            icon_code (str): Kod ikony z API pogodowego

        Returns:
            str: Emoji pogodowe
        """
        icons = {
            '01d': '☀️', '01n': '🌙',  # Bezchmurnie
            '02d': '⛅', '02n': '🌙☁️',  # Niewielkie zachmurzenie
            '03d': '☁️', '03n': '☁️',  # Zachmurzenie
            '04d': '☁️☁️', '04n': '☁️☁️',  # Duże zachmurzenie
            '09d': '🌧️', '09n': '🌧️',  # Przelotny deszcz
            '10d': '🌦️', '10n': '🌧️',  # Deszcz
            '11d': '⛈️', '11n': '⛈️',  # Burza
            '13d': '❄️', '13n': '❄️',  # Śnieg
            '50d': '🌫️', '50n': '🌫️'  # Mgła
        }
        return icons.get(icon_code, '🌡️')  # Domyślna ikona termometru


class WeatherChart(QWidget):
    """
    Widget wykresu pogodowego z wykorzystaniem biblioteki PyQtGraph.
    """

    def __init__(self, title="Temperatura"):
        super().__init__()
        self.title = title
        self.data = []

        # Inicjalizacja UI
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        if PYQTGRAPH_AVAILABLE:
            # Wykres z PyQtGraph
            self.plot_widget = pg.PlotWidget()
            self.plot_widget.setBackground((0, 4, 40, 150))
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            self.plot_widget.setTitle(self.title, color='#4dabf7', size='18pt')

            # Ustawienia osi
            styles = {'color': '#4dabf7', 'font-size': '14pt'}
            self.plot_widget.setLabel('left', 'Wartość', **styles)
            self.plot_widget.setLabel('bottom', 'Czas', **styles)

            # Ustawienia pióra
            self.pen = pg.mkPen(color=(77, 171, 247), width=3)

            layout.addWidget(self.plot_widget)
        else:
            # Alternatywa, gdy PyQtGraph nie jest dostępny
            alternative_widget = QFrame()
            alternative_widget.setObjectName("chart_placeholder")
            alternative_widget.setMinimumHeight(250)

            alt_layout = QVBoxLayout(alternative_widget)

            title_label = QLabel(self.title)
            title_label.setObjectName("chart_title")
            title_label.setAlignment(Qt.AlignCenter)

            message_label = QLabel("Wykresy wymagają biblioteki PyQtGraph")
            message_label.setAlignment(Qt.AlignCenter)

            alt_layout.addWidget(title_label)
            alt_layout.addWidget(message_label)

            layout.addWidget(alternative_widget)

        self.setLayout(layout)

    def update_data(self, x_data, y_data, units="°C"):
        """
        Aktualizacja danych wykresu.

        Args:
            x_data (list): Dane osi X
            y_data (list): Dane osi Y
            units (str): Jednostki danych
        """
        if not PYQTGRAPH_AVAILABLE:
            return

        self.plot_widget.clear()

        # Dodanie linii z danymi
        self.line = self.plot_widget.plot(x_data, y_data, pen=self.pen, symbol='o', symbolSize=10,
                                          symbolBrush=(77, 171, 247))

        # Dodanie etykiet
        for i, (x, y) in enumerate(zip(x_data, y_data)):
            text = pg.TextItem(f"{y}{units}", color=(255, 255, 255), anchor=(0.5, 0))
            text.setPos(x, y)
            self.plot_widget.addItem(text)




class WeatherMapWidget(QWidget):
    """
    Widget mapy pogodowej z zaznaczoną lokalizacją i warstwami pogodowymi.
    """

    def __init__(self):
        super().__init__()
        self.lat = 0
        self.lon = 0
        self.zoom = 10
        self.active_layer = None
        self.weather_data = None
        self.data_available = False  # Flaga wskazująca dostępność danych

        # Inicjalizacja UI
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Mapa jako własny widget rysowany
        self.map_frame = QFrame()
        self.map_frame.setObjectName("map_placeholder")
        self.map_frame.setMinimumHeight(400)
        self.map_frame.paintEvent = self.paint_map

        # Informacje o lokalizacji
        self.info_layout = QVBoxLayout(self.map_frame)

        self.map_title = QLabel("Mapa Pogodowa")
        self.map_title.setObjectName("map_title")
        self.map_title.setAlignment(Qt.AlignCenter)

        self.location_label = QLabel("Lokalizacja: 0.00, 0.00")
        self.location_label.setAlignment(Qt.AlignCenter)
        self.location_label.setObjectName("location_label")

        # Etykieta dla informacji o warstwie
        self.layer_info = QLabel("Wybierz warstwę poniżej")
        self.layer_info.setAlignment(Qt.AlignCenter)
        self.layer_info.setObjectName("layer_info")

        # Status dostępności danych
        self.data_status = QLabel("Brak danych pogodowych")
        self.data_status.setAlignment(Qt.AlignCenter)
        self.data_status.setObjectName("data_status")

        self.info_layout.addWidget(self.map_title)
        self.info_layout.addWidget(self.location_label)
        self.info_layout.addWidget(self.layer_info)
        self.info_layout.addWidget(self.data_status)
        self.info_layout.addStretch()

        # Kontrolki warstw mapy
        layers_frame = QFrame()
        layers_frame.setObjectName("map_controls")
        layers_layout = QHBoxLayout(layers_frame)

        layers_layout.addWidget(QLabel("Warstwy:"))

        # Przyciski warstw
        self.layer_buttons = {}
        for layer in ["Temperatura", "Chmury", "Wiatr", "Ciśnienie", "Opady"]:
            layer_btn = QPushButton(layer)
            layer_btn.setObjectName("map_layer_btn")
            layer_btn.setCheckable(True)
            layer_btn.clicked.connect(lambda checked, l=layer: self.toggle_layer(l, checked))
            layers_layout.addWidget(layer_btn)
            self.layer_buttons[layer] = layer_btn

        layout.addWidget(self.map_frame)
        layout.addWidget(layers_frame)

        self.setLayout(layout)

    def set_location(self, lat, lon):
        """
        Ustawienie lokalizacji na mapie.

        Args:
            lat (float): Szerokość geograficzna
            lon (float): Długość geograficzna
        """
        self.lat = lat
        self.lon = lon

        # Aktualizacja informacji o lokalizacji
        self.location_label.setText(f"Lokalizacja: {lat:.4f}, {lon:.4f}")

        # Oznaczenie, że mamy dane lokalizacji
        self.data_available = True
        self.data_status.setText("Dane lokalizacyjne dostępne")

        # Odświeżenie mapy
        self.update()

    def set_weather_data(self, data):
        """
        Ustawienie danych pogodowych dla mapy.

        Args:
            data (dict): Dane pogodowe
        """
        self.weather_data = data

        if data and data.get('success', False):
            self.data_available = True
            self.data_status.setText("Dane pogodowe dostępne")
        else:
            self.data_status.setText("Brak pełnych danych pogodowych")

        # Odświeżenie mapy
        self.update()

    def toggle_layer(self, layer_name, is_checked):
        """
        Przełączanie warstw na mapie.

        Args:
            layer_name (str): Nazwa warstwy
            is_checked (bool): Czy warstwa jest włączona
        """
        # Odznaczamy wszystkie inne przyciski
        for name, btn in self.layer_buttons.items():
            if name != layer_name:
                btn.setChecked(False)

        # Ustawiamy aktywną warstwę lub wyłączamy jeśli ten sam przycisk kliknięto ponownie
        if is_checked:
            self.active_layer = layer_name
            self.layer_info.setText(f"Warstwa: {layer_name}")

            # Sprawdzamy dostępność danych dla warstwy
            if not self.data_available:
                self.data_status.setText(f"Brak danych dla warstwy '{layer_name}'")
        else:
            self.active_layer = None
            self.layer_info.setText("Wybierz warstwę poniżej")

        # Odświeżenie mapy
        self.update()

    def paint_map(self, event):
        """
        Metoda rysująca mapę i warstwy pogodowe.
        """
        painter = QPainter(self.map_frame)
        painter.setRenderHint(QPainter.Antialiasing)

        # Tło mapy - ciemny niebieski gradient
        self._draw_map_background(painter)

        # Rysowanie siatki geograficznej
        self._draw_grid(painter)

        # Jeśli mamy dane, rysujemy wybraną warstwę
        if self.data_available and self.active_layer:
            self._draw_layer_placeholder(painter)

        # Rysowanie markera lokalizacji, jeśli mamy współrzędne
        if self.lat != 0 or self.lon != 0:
            self._draw_location_marker(painter)

        painter.end()

    def _draw_map_background(self, painter):
        """Rysuje tło mapy"""
        # Gradient tła
        gradient = QLinearGradient(0, 0, 0, self.map_frame.height())
        gradient.setColorAt(0, QColor(10, 25, 41))
        gradient.setColorAt(1, QColor(15, 32, 64))
        painter.fillRect(self.map_frame.rect(), gradient)

        # Dodaj delikatne obramowanie
        pen = QPen(QColor(77, 171, 247))
        pen.setWidth(2)
        painter.setPen(pen)
        painter.drawRect(self.map_frame.rect().adjusted(1, 1, -1, -1))

        # Narysuj kompas w prawym górnym rogu
        self._draw_compass(painter)

    def _draw_grid(self, painter):
        """Rysuje siatkę geograficzną"""
        pen = QPen(QColor(77, 171, 247, 50))
        pen.setWidth(1)
        painter.setPen(pen)

        width = self.map_frame.width()
        height = self.map_frame.height()

        # Linie poziome (równoleżniki)
        step_y = height / 10
        for i in range(1, 10):
            y = int(step_y * i)
            painter.drawLine(0, y, width, y)

            # Dodaj oznaczenia szerokości geograficznej
            lat_label = f"{90 - i * 18}°"
            painter.drawText(QPoint(5, y - 5), lat_label)

        # Linie pionowe (południki)
        step_x = width / 10
        for i in range(1, 10):
            x = int(step_x * i)
            painter.drawLine(x, 0, x, height)

            # Dodaj oznaczenia długości geograficznej
            lon_label = f"{-180 + i * 36}°"
            painter.drawText(QPoint(x + 5, 15), lon_label)

    def _draw_compass(self, painter):
        """Rysuje kompas w rogu mapy"""
        # Ustawienia kompasu
        compass_size = 60
        margin = 15
        x = self.map_frame.width() - compass_size - margin
        y = margin

        # Tło kompasu
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(15, 32, 64, 200)))
        painter.drawEllipse(x, y, compass_size, compass_size)

        # Okrąg kompasu
        pen = QPen(QColor(77, 171, 247))
        pen.setWidth(2)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawEllipse(x, y, compass_size, compass_size)

        # Środek kompasu
        center_x = x + compass_size/2
        center_y = y + compass_size/2

        # Kierunki główne
        directions = [("N", 0), ("E", 90), ("S", 180), ("W", 270)]

        for dir_name, angle in directions:
            rad = math.radians(angle)
            dir_x = int(center_x + 0.7 * (compass_size/2) * math.sin(rad))
            dir_y = int(center_y - 0.7 * (compass_size/2) * math.cos(rad))

            # Tekst kierunku - używamy QPoint aby uniknąć problemu z float
            painter.drawText(QPoint(dir_x - 5, dir_y + 5), dir_name)

            # Linia wskazująca kierunek
            line_end_x = int(center_x + 0.9 * (compass_size/2) * math.sin(rad))
            line_end_y = int(center_y - 0.9 * (compass_size/2) * math.cos(rad))

            painter.drawLine(int(center_x), int(center_y), line_end_x, line_end_y)

        # Wskazówka północy (czerwona)
        painter.setPen(QPen(QColor(255, 0, 0), 2))
        north_x = int(center_x)
        north_y = int(center_y - 0.8 * (compass_size/2))
        painter.drawLine(int(center_x), int(center_y), north_x, north_y)

        # Kropka w środku
        painter.setBrush(QBrush(QColor(77, 171, 247)))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(int(center_x - 3), int(center_y - 3), 6, 6)

    def _draw_location_marker(self, painter):
        """
        Rysowanie markera lokalizacji na mapie.
        """
        # W rzeczywistej aplikacji przeliczalibyśmy lat/lon na współrzędne ekranu
        # Na potrzeby demonstracji umieścimy marker pośrodku
        center_x = int(self.map_frame.width() / 2)
        center_y = int(self.map_frame.height() / 2)

        # Rysujemy marker
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(QColor(77, 171, 247, 180)))

        # Efekt "cienia" dla markera
        shadow_size = 40
        painter.drawEllipse(center_x - shadow_size//2, center_y - shadow_size//2, shadow_size, shadow_size)

        # Główny marker
        painter.setBrush(QBrush(QColor(77, 171, 247, 180)))
        marker_size = 30
        painter.drawEllipse(center_x - marker_size//2, center_y - marker_size//2, marker_size, marker_size)

        # Wewnętrzny punkt
        painter.setBrush(QBrush(QColor(255, 255, 255)))
        inner_size = 10
        painter.drawEllipse(center_x - inner_size//2, center_y - inner_size//2, inner_size, inner_size)

        # Dodaj etykietę miasta
        if self.weather_data and 'city' in self.weather_data:
            city_name = self.weather_data.get('city', 'Nieznane miejsce')

            # Tło etykiety
            text_width = len(city_name) * 8 + 20  # Przybliżona szerokość tekstu + padding
            text_height = 25
            text_rect = QRectF(center_x - text_width/2, center_y + marker_size/2 + 5,
                              text_width, text_height)

            painter.setBrush(QBrush(QColor(15, 32, 64, 220)))
            painter.setPen(QPen(QColor(77, 171, 247), 1))
            painter.drawRoundedRect(text_rect, 5, 5)

            # Tekst etykiety
            painter.setPen(QPen(QColor(255, 255, 255)))
            painter.setFont(QFont("Segoe UI", 10, QFont.Bold))
            painter.drawText(text_rect, Qt.AlignCenter, city_name)

    def _draw_layer_placeholder(self, painter):
        """
        Rysuje informację o wybranej warstwie gdy brakuje rzeczywistych danych.
        """
        # Pobieramy wymiary okna
        width = self.map_frame.width()
        height = self.map_frame.height()

        # Tekst informacyjny
        info_text = f"Warstwa {self.active_layer}"
        details_text = "Ta funkcjonalność wymaga integracji z API dostarczającym dane mapowe."
        suggestion_text = "W pełnej wersji zobaczysz tutaj mapę z danymi pogodowymi."

        # Styl tekstu
        painter.setPen(QPen(QColor(255, 255, 255)))
        painter.setFont(QFont("Segoe UI", 14, QFont.Bold))

        # Obliczamy położenie tekstów
        center_y = int(height / 3)

        # Rysujemy teksty - używamy QRectF dla drawText z tekstem
        painter.drawText(QRectF(0, center_y, width, 30), Qt.AlignCenter, info_text)

        painter.setFont(QFont("Segoe UI", 10))
        painter.drawText(QRectF(0, center_y + 40, width, 30), Qt.AlignCenter, details_text)
        painter.drawText(QRectF(0, center_y + 70, width, 30), Qt.AlignCenter, suggestion_text)

        # Dodajemy symbol warstwy
        self._draw_layer_symbol(painter, int(width/2), center_y - 60)

    def _draw_layer_symbol(self, painter, x, y):
        """
        Rysuje symbol reprezentujący wybraną warstwę.

        Args:
            painter: Obiekt QPainter
            x, y: Współrzędne środka symbolu
        """
        symbol_size = 60
        half_size = int(symbol_size / 2)

        if self.active_layer == "Temperatura":
            # Symbol termometru
            painter.setPen(QPen(QColor(255, 100, 100), 2))
            painter.setBrush(QBrush(QColor(255, 100, 100, 150)))

            # Rurka termometru - używamy QRect dla drawRoundedRect
            rect = QRect(x - 5, y - half_size, 10, symbol_size)
            painter.drawRoundedRect(rect, 5.0, 5.0)

            # Zbiornik
            painter.drawEllipse(x - 15, y + half_size - 15, 30, 30)

            # Skala
            painter.setPen(QPen(QColor(255, 255, 255), 1))
            for i in range(1, 5):
                y_pos = y - half_size + i * (symbol_size // 5)
                painter.drawLine(x - 15, y_pos, x - 5, y_pos)

        elif self.active_layer == "Chmury":
            # Symbol chmury
            painter.setPen(QPen(QColor(200, 200, 255), 2))
            painter.setBrush(QBrush(QColor(200, 200, 255, 150)))

            # Główna część chmury
            painter.drawEllipse(x - 25, y - 15, 50, 30)
            painter.drawEllipse(x - 15, y - 25, 30, 25)
            painter.drawEllipse(x + 5, y - 20, 35, 25)

        elif self.active_layer == "Wiatr":
            # Symbol wiatru (flaga na maszcie)
            painter.setPen(QPen(QColor(100, 200, 255), 2))

            # Maszt
            painter.drawLine(x, y - half_size, x, y + half_size)

            # Flaga
            painter.setBrush(QBrush(QColor(100, 200, 255, 150)))
            points = [
                QPoint(x, y - half_size + 10),
                QPoint(x + 30, y - half_size + 20),
                QPoint(x, y - half_size + 30)
            ]
            painter.drawPolygon(points)

            # Strzałki wiatru
            painter.drawLine(x - 20, y, x - 5, y)
            painter.drawLine(x - 5, y, x - 10, y - 5)
            painter.drawLine(x - 5, y, x - 10, y + 5)

            painter.drawLine(x - 25, y + 15, x - 10, y + 15)
            painter.drawLine(x - 10, y + 15, x - 15, y + 10)
            painter.drawLine(x - 10, y + 15, x - 15, y + 20)

        elif self.active_layer == "Ciśnienie":
            # Symbol barometru
            painter.setPen(QPen(QColor(150, 150, 255), 2))
            painter.setBrush(Qt.NoBrush)

            # Okrągły barometr
            painter.drawEllipse(x - half_size, y - half_size, symbol_size, symbol_size)

            # Wskazówka
            painter.drawLine(x, y, x + int(half_size * 0.7), y - int(half_size * 0.7))

            # Skala
            painter.drawArc(QRectF(x - half_size + 10, y - half_size + 10,
                                  symbol_size - 20, symbol_size - 20),
                            135 * 16, 270 * 16)

            # Oznaczenia na skali
            painter.setPen(QPen(QColor(255, 255, 255), 1))
            for i in range(0, 6):
                angle = math.radians(45 + i * 45)
                start_x = int(x + (half_size - 10) * math.cos(angle))
                start_y = int(y + (half_size - 10) * math.sin(angle))
                end_x = int(x + (half_size - 5) * math.cos(angle))
                end_y = int(y + (half_size - 5) * math.sin(angle))
                painter.drawLine(start_x, start_y, end_x, end_y)

        elif self.active_layer == "Opady":
            # Symbol deszczu
            painter.setPen(QPen(QColor(100, 100, 255), 2))

            # Chmura
            painter.setBrush(QBrush(QColor(150, 150, 255, 150)))
            painter.drawEllipse(x - 30, y - half_size, 60, 30)

            # Krople deszczu
            painter.setPen(QPen(QColor(100, 100, 255), 2))
            painter.setBrush(QBrush(QColor(100, 100, 255, 200)))

            for i in range(-20, 30, 20):
                drop_x = x + i
                drop_y = y

                # Rysujemy kroplę
                painter.drawEllipse(drop_x - 5, drop_y - 3, 10, 15)

                # Ślad kropli
                painter.setPen(QPen(QColor(100, 100, 255, 100), 1))
                painter.drawLine(drop_x, drop_y - 20, drop_x, drop_y - 10)
                painter.setPen(QPen(QColor(100, 100, 255), 2))


