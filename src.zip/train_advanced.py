import os
import sys
import argparse
from advanced_model import train_advanced_model, download_fasttext_model


def main():
    """
    Main function for training the enhanced chatbot model.
    """
    parser = argparse.ArgumentParser(description='Train enhanced ML model for multilingual weather chatbot')

    parser.add_argument('--download', choices=['pl', 'en', 'both'],
                        help='Download fastText models for specified languages')

    parser.add_argument('--force', action='store_true',
                        help='Force retraining even if model already exists')

    parser.add_argument('--tfidf-only', action='store_true',
                        help='Use only TF-IDF (skip word embeddings)')

    parser.add_argument('--light', action='store_true',
                        help='Train a lighter model with fewer parameters (for limited resources)')

    parser.add_argument('--language', choices=['pl', 'en', 'both'],
                        default='both', help='Train for specific languages only')

    args = parser.parse_args()

    # Handle fastText model downloads if requested
    if args.download:
        if args.download == 'both' or args.download == 'pl':
            print("Downloading Polish fastText model...")
            download_fasttext_model('pl')

        if args.download == 'both' or args.download == 'en':
            print("Downloading English fastText model...")
            download_fasttext_model('en')

        if not args.force:
            print("Model downloads complete. Use --force to train the model.")
            return

    # Check if model already exists
    model_path = os.path.join('models', 'classifier_advanced.pkl')
    if os.path.exists(model_path) and not args.force:
        print(f"Enhanced model already exists at {model_path}")
        print("Use --force to retrain the model.")
        return

    # Setup environment variables based on args
    if args.tfidf_only:
        os.environ['USE_EMBEDDINGS'] = '0'
    else:
        os.environ['USE_EMBEDDINGS'] = '1'

    if args.light:
        os.environ['LIGHT_MODEL'] = '1'
    else:
        os.environ['LIGHT_MODEL'] = '0'

    if args.language != 'both':
        os.environ['LANGUAGE'] = args.language
    else:
        os.environ['LANGUAGE'] = 'both'

    # Train the model
    print("Starting enhanced model training...")
    model, accuracy = train_advanced_model()
    print(f"Training completed with accuracy: {accuracy:.4f}")


if __name__ == "__main__":
    main()