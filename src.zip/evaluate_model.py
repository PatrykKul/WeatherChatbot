import os
import sys
import pickle
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.model_selection import train_test_split
import seaborn as sns
import pandas as pd
import argparse

# Add current directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

try:
    from data_preparation import prepare_training_data, clean_text
except ImportError:
    print("Error importing data_preparation module")
    sys.exit(1)


def load_model(model_path=None):
    """
    Load a trained classifier model.

    Args:
        model_path (str): Path to the model file

    Returns:
        object: The loaded model
    """
    if model_path is None:
        model_path = os.path.join('models', 'classifier_advanced.pkl')

    try:
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        print(f"Model loaded from {model_path}")
        return model
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        sys.exit(1)


def evaluate_model_on_test_data(model, test_size=0.2, random_state=42):
    """
    Evaluate the model on held-out test data.

    Args:
        model: The trained model to evaluate
        test_size (float): Proportion of data to use for testing
        random_state (int): Random seed for reproducibility

    Returns:
        dict: Evaluation results
    """
    # Prepare data
    documents, classes, words = prepare_training_data()

    # Prepare X (tokens or texts) and y (tags)
    X = []
    y = []

    for doc, tag in documents:
        # For TF-IDF based models, we need the text
        if hasattr(model, 'predict') and not hasattr(model, 'language_embeddings'):
            X.append(' '.join(doc))
        # For embedding models, we need the raw text to process
        else:
            X.append(' '.join(doc))
        y.append(tag)

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # Make predictions
    try:
        y_pred = model.predict(X_test)

        # Calculate accuracy
        accuracy = accuracy_score(y_test, y_pred)

        # Generate classification report
        report = classification_report(y_test, y_pred, output_dict=True)

        # Generate confusion matrix
        cm = confusion_matrix(y_test, y_pred, labels=np.unique(y))

        return {
            'accuracy': accuracy,
            'classification_report': report,
            'confusion_matrix': cm,
            'classes': np.unique(y),
            'y_test': y_test,
            'y_pred': y_pred
        }
    except Exception as e:
        print(f"Error during evaluation: {str(e)}")
        return None


def plot_evaluation_results(results, output_dir=None):
    """
    Plot evaluation results.

    Args:
        results (dict): Results from evaluate_model_on_test_data
        output_dir (str): Directory to save plots

    Returns:
        None
    """
    if results is None:
        print("No results to plot")
        return

    if output_dir is None:
        output_dir = 'evaluation_results'

    os.makedirs(output_dir, exist_ok=True)

    # Plot confusion matrix
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        results['confusion_matrix'],
        annot=True,
        fmt='d',
        cmap='Blues',
        xticklabels=results['classes'],
        yticklabels=results['classes']
    )
    plt.title(f'Confusion Matrix (Accuracy: {results["accuracy"]:.4f})')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'confusion_matrix.png'))
    plt.close()

    # Plot classification metrics by class
    report_df = pd.DataFrame(results['classification_report']).T
    report_df = report_df.drop('accuracy', errors='ignore')

    metrics = ['precision', 'recall', 'f1-score']
    for metric in metrics:
        plt.figure(figsize=(12, 6))

        # Filter out summary rows
        class_df = report_df[~report_df.index.isin(['macro avg', 'weighted avg'])]

        ax = sns.barplot(x=class_df.index, y=class_df[metric])
        plt.title(f'{metric.capitalize()} by Class')
        plt.ylabel(metric)
        plt.xlabel('Class')
        plt.xticks(rotation=45, ha='right')

        # Add value labels
        for i, v in enumerate(class_df[metric]):
            ax.text(i, v + 0.02, f'{v:.2f}', ha='center')

        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'{metric}_by_class.png'))
        plt.close()

    # Create a summary report
    with open(os.path.join(output_dir, 'summary_report.txt'), 'w') as f:
        f.write(f"Model Evaluation Summary\n")
        f.write(f"=======================\n\n")
        f.write(f"Overall Accuracy: {results['accuracy']:.4f}\n\n")

        f.write("Classification Report:\n")
        f.write("---------------------\n")
        for cls in results['classes']:
            cls_metrics = results['classification_report'][cls]
            f.write(f"{cls}:\n")
            f.write(f"  Precision: {cls_metrics['precision']:.4f}\n")
            f.write(f"  Recall: {cls_metrics['recall']:.4f}\n")
            f.write(f"  F1-Score: {cls_metrics['f1-score']:.4f}\n")
            f.write(f"  Support: {cls_metrics['support']}\n\n")

        f.write("Average Metrics:\n")
        f.write("---------------\n")
        for avg in ['macro avg', 'weighted avg']:
            if avg in results['classification_report']:
                avg_metrics = results['classification_report'][avg]
                f.write(f"{avg}:\n")
                f.write(f"  Precision: {avg_metrics['precision']:.4f}\n")
                f.write(f"  Recall: {avg_metrics['recall']:.4f}\n")
                f.write(f"  F1-Score: {avg_metrics['f1-score']:.4f}\n")
                f.write(f"  Support: {avg_metrics['support']}\n\n")

    print(f"Evaluation results saved to {output_dir}")


def evaluate_examples(model, examples):
    """
    Evaluate model on specific examples.

    Args:
        model: The trained model
        examples (list): List of example texts to classify

    Returns:
        list: List of (example, intent, confidence) tuples
    """
    results = []

    for example in examples:
        try:
            # Get prediction probabilities
            proba = model.predict_proba([example])[0]

            # Get the predicted class and confidence
            best_idx = np.argmax(proba)
            intent = model.classes_[best_idx]
            confidence = proba[best_idx]

            results.append((example, intent, confidence))
        except Exception as e:
            print(f"Error evaluating example '{example}': {str(e)}")
            results.append((example, "ERROR", 0.0))

    return results


def main():
    """
    Main function for evaluating the chatbot model.
    """
    parser = argparse.ArgumentParser(description='Evaluate chatbot classification model')

    parser.add_argument('--model',
                        help='Path to model file (default: models/classifier_advanced.pkl)')

    parser.add_argument('--output-dir',
                        default='evaluation_results',
                        help='Directory to save evaluation results')

    parser.add_argument('--examples', action='store_true',
                        help='Evaluate on specific examples')

    args = parser.parse_args()

    # Load model
    model = load_model(args.model)

    # Evaluate on test data
    print("Evaluating model on test data...")
    results = evaluate_model_on_test_data(model)

    # Plot results
    print("Generating evaluation plots...")
    plot_evaluation_results(results, args.output_dir)

    # Evaluate on specific examples if requested
    if args.examples:
        print("\nEvaluating specific examples:")
        examples = [
            "Hej, jak się masz?",
            "Jaka jest pogoda w Warszawie?",
            "Czy jutro będzie padać w Krakowie?",
            "Dziękuję za informację",
            "Do widzenia",
            "Jaka jest temperatura w Gdańsku?",
            "Pomóż mi sprawdzić pogodę",
            "Czy pada deszcz w Poznaniu?",
            "Opowiedz mi o swojej pracy",
            "Hi there, how are you?",
            "What's the weather like in London?",
            "Will it rain tomorrow in Paris?",
            "Thank you for your help",
            "Goodbye",
            "What's the temperature in Berlin?",
            "Help me check the weather",
            "Is it raining in Madrid?",
            "Tell me about your work"
        ]

        results = evaluate_examples(model, examples)

        print("\nExample Evaluation Results:")
        print("=========================")
        print(f"{'Example':<40} | {'Intent':<15} | {'Confidence':<10}")
        print("-" * 70)

        for example, intent, confidence in results:
            # Truncate long examples
            if len(example) > 37:
                display_example = example[:34] + "..."
            else:
                display_example = example

            print(f"{display_example:<40} | {intent:<15} | {confidence:.4f}")

        # Save example results to file
        with open(os.path.join(args.output_dir, 'example_results.txt'), 'w') as f:
            f.write("Example Evaluation Results\n")
            f.write("=========================\n\n")

            for example, intent, confidence in results:
                f.write(f"Example: {example}\n")
                f.write(f"Intent: {intent}\n")
                f.write(f"Confidence: {confidence:.4f}\n\n")


if __name__ == "__main__":
    main()