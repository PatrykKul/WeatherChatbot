import os
import sys
import pickle
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
import joblib
import warnings

# Ignoruj ostrzeżenia deprecated
warnings.filterwarnings("ignore")

# Dodaj ścieżkę do katalogu z modułami
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# Importuj potrzebne moduły
try:
    from data_preparation import prepare_training_data, clean_text

    try:
        from utils import get_resource_path, ensure_dir_exists
    except ImportError:
        # Fallback implementation
        def get_resource_path(path):
            if os.path.isabs(path):
                return path
            return os.path.join(os.path.dirname(current_dir), path)


        def ensure_dir_exists(directory):
            if not os.path.exists(directory):
                os.makedirs(directory)
except ImportError:
    print("Błąd importu wymaganych modułów")
    sys.exit(1)


def download_fasttext_model(language='pl', limit=50000):
    """
    Funkcja pozostawiona dla zachowania zgodności z istniejącymi wywołaniami.
    Obecnie zwraca False, ponieważ embeddingsy są pomijane dla stabilności.
    """
    print(f"Pomijanie pobierania modelu fastText dla oszczędności czasu i pamięci")
    return False


def train_advanced_model():
    """
    Poprawiona funkcja do trenowania zaawansowanego modelu ML.

    Returns:
        tuple: (model, accuracy) - wytrenowany model i jego dokładność
    """
    try:
        print("Trenowanie zaawansowanego modelu klasyfikacyjnego...")

        # Przygotowanie danych treningowych
        documents, classes, words = prepare_training_data()

        # Wykrywanie języków w danych
        from data_preparation import detect_language
        languages = set()
        for doc, _ in documents:
            text = " ".join(doc)
            lang = detect_language(text)
            if lang != 'unknown':
                languages.add(lang)
        print(f"Wykryto języki w danych: {', '.join(languages)}")

        # Przygotowanie danych w jednolitym formacie
        X_texts = []
        y = []

        for doc, tag in documents:
            X_texts.append(' '.join(doc))
            y.append(tag)

        # Podział na zbiór treningowy i testowy
        X_train, X_test, y_train, y_test = train_test_split(
            X_texts, y, test_size=0.2, random_state=42, stratify=y
        )

        # Utwórz pipeline klasyfikacyjny
        pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(
                max_features=10000,  # Zwiększona liczba cech
                min_df=2,
                max_df=0.8,
                sublinear_tf=True,
                use_idf=True,
                ngram_range=(1, 3)  # N-gramy do 3 dla lepszego kontekstu
            )),
            ('classifier', OneVsRestClassifier(LogisticRegression(
                max_iter=2000,
                C=10.0,
                solver='liblinear',
                class_weight='balanced',  # Używamy 'balanced' zamiast słownika
                tol=1e-4  # Zwiększona tolerancja dla lepszej zbieżności
            )))
        ])

        print("Trenowanie modelu TF-IDF z ulepszonymi parametrami...")
        pipeline.fit(X_train, y_train)

        # Ocena modelu
        y_pred = pipeline.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        print(f"Dokładność modelu TF-IDF: {accuracy:.4f}")

        try:
            report = classification_report(y_test, y_pred, zero_division=0)
        except:
            report = classification_report(y_test, y_pred)

        print("\nRaport klasyfikacji:")
        print(report)

        # Zapisanie modelu
        models_dir = get_resource_path('models')
        ensure_dir_exists(models_dir)

        model_path = os.path.join(models_dir, 'classifier_advanced.pkl')
        with open(model_path, 'wb') as f:
            pickle.dump(pipeline, f)

        print(f"Model zapisany jako '{model_path}'")

        # Utwórz backup w katalogu src/models
        src_models_dir = os.path.join(current_dir, 'models')
        ensure_dir_exists(src_models_dir)
        backup_path = os.path.join(src_models_dir, 'classifier_backup.pkl')

        with open(backup_path, 'wb') as f:
            pickle.dump(pipeline, f)

        print(f"Kopia modelu zapisana jako '{backup_path}'")

        # Zapisz również jako główny model classifier.pkl
        main_model_path = os.path.join(models_dir, 'classifier.pkl')
        with open(main_model_path, 'wb') as f:
            pickle.dump(pipeline, f)

        return pipeline, accuracy

    except Exception as e:
        print(f"Wystąpił błąd podczas trenowania zaawansowanego modelu: {str(e)}")
        import traceback
        traceback.print_exc()

        # Fallback do modelu podstawowego
        try:
            from model import create_model
            print("Używanie prostego modelu jako fallback")
            return create_model()
        except ImportError:
            print("Nie można zaimportować podstawowego modelu")
            raise


if __name__ == "__main__":
    model, accuracy = train_advanced_model()
    print(f"Dokładność końcowa modelu: {accuracy:.4f}")