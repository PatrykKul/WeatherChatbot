import os
import pickle
import numpy as np
import sys
from city_extractor import extract_city
from utils import get_resource_path

# Dodajemy aktualny katalog do ścieżki, aby znaleźć moduł data_preparation
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

from data_preparation import clean_text


class IntentClassifier:
    def __init__(self, model_path=None):
        """
        Inicjalizacja klasyfikatora intencji.

        Args:
            model_path (str): Ścieżka do zapisanego modelu
        """

        if model_path is None:
            # Użyj standardowej ścieżki do modelu
            model_path = get_resource_path('models/classifier.pkl')

        self.model = None
        self.model_path = model_path
        self._load_model()

    def _load_model(self):
        """Ładowanie zapisanego modelu z pliku"""
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, 'rb') as f:
                    self.model = pickle.load(f)
                print(f"Model załadowany z {self.model_path}")
                return
            except Exception as e:
                print(f"Błąd podczas ładowania modelu: {str(e)}")

        # Jeśli nie udało się załadować modelu, spróbuj znaleźć go w innych lokalizacjach
        print(f"UWAGA: Nie znaleziono modelu w {self.model_path}. Szukam w alternatywnych lokalizacjach...")
        self._try_alternative_paths()

    def _try_alternative_paths(self):
        """Próba znalezienia modelu w alternatywnych lokalizacjach"""
        # Określ katalog główny projektu
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        model_name = os.path.basename(self.model_path)

        # Lista potencjalnych ścieżek do sprawdzenia
        potential_paths = [
            # W katalogu src/models
            os.path.join(current_dir, 'models', model_name),
            # W katalogu głównym/models
            os.path.join(base_dir, 'models', model_name),
            # W katalogu src
            os.path.join(current_dir, model_name),
            # W katalogu głównym
            os.path.join(base_dir, model_name)
        ]

        # Dodaj dodatkowe potencjalne ścieżki
        if '/' in self.model_path or '\\' in self.model_path:
            # Jeśli ścieżka zawiera separatory, dodaj również bezpośrednią ścieżkę do nazwy pliku
            potential_paths.append(model_name)

        # Sprawdź wszystkie potencjalne ścieżki
        for path in potential_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'rb') as f:
                        self.model = pickle.load(f)
                    print(f"Model załadowany z alternatywnej ścieżki: {path}")
                    self.model_path = path
                    return
                except Exception as e:
                    print(f"Błąd podczas ładowania modelu z {path}: {str(e)}")

        # Jeśli nadal nie znaleziono modelu, sprawdź w całym projekcie
        for root, dirs, files in os.walk(base_dir):
            if model_name in files:
                try:
                    path = os.path.join(root, model_name)
                    with open(path, 'rb') as f:
                        self.model = pickle.load(f)
                    print(f"Model załadowany z lokalizacji: {path}")
                    self.model_path = path
                    return
                except Exception as e:
                    print(f"Błąd podczas ładowania modelu z {path}: {str(e)}")

        print("Nie znaleziono modelu w żadnej z oczekiwanych lokalizacji. Trenuję nowy model...")
        try:
            # Importuj funkcję tworzącą model
            from model import create_model

            # Utwórz i zapisz model
            model, _ = create_model()
            self.model = model
            print("Pomyślnie wytrenowano nowy model.")
            return
        except Exception as e:
            print(f"Błąd podczas trenowania nowego modelu: {str(e)}")
            print("Nie można wytrenować modelu. Używanie fallbackowego mechanizmu klasyfikacji.")
            self.model = None

    # W pliku predict.py, metoda predict_intent
    # Dodaj/zmodyfikuj w pliku predict.py

    # Zmodyfikowana metoda predict_intent w pliku predict.py

    def predict_intent(self, text, conversation_context=None, confidence_threshold=0.30):
        """
        Predykcja intencji na podstawie wprowadzonego tekstu z ulepszoną obsługą
        rozróżniania między intencjami weather i forecast.

        Args:
            text (str): Tekst do klasyfikacji
            conversation_context (dict, optional): Kontekst rozmowy (ostatnie miasto, intencja)
            confidence_threshold (float): Próg pewności dla predykcji

        Returns:
            dict: Słownik zawierający przewidywaną intencję i pewność
        """
        if self.model is None:
            return {
                "intent": "fallback",
                "confidence": 1.0,
                "message": "Model nie został załadowany."
            }

        # Wykryj język jeśli nie jest określony w kontekście
        if conversation_context is None:
            conversation_context = {}

        if "language" not in conversation_context:
            from data_preparation import detect_language
            detected_language = detect_language(text)
            conversation_context["language"] = detected_language
            print(f"Wykryto język: {detected_language} dla tekstu: '{text}'")

        language = conversation_context.get("language", "pl")
        cleaned_text = clean_text(text)
        cleaned_text_lower = cleaned_text.lower()

        try:
            # Najpierw wykonaj standardową predykcję modelu
            probabilities = self.model.predict_proba([cleaned_text])[0]
            best_idx = np.argmax(probabilities)
            best_intent = self.model.classes_[best_idx]
            confidence = probabilities[best_idx]

            # Wyświetl wszystkie prawdopodobieństwa (do debugowania)
            print(f"Debug - prawdopodobieństwa intencji dla '{text}':")
            classes_probs = list(zip(self.model.classes_, probabilities))
            classes_probs.sort(key=lambda x: x[1], reverse=True)
            for intent, prob in classes_probs:
                print(f"  {intent}: {prob:.4f}")

            # ================================================================
            # ROZRÓŻNIANIE POGODA VS PROGNOZA
            # ================================================================

            # Słowa kluczowe silnie wskazujące na aktualną pogodę (weather)
            weather_keywords_pl = ["teraz", "obecnie", "aktualna", "aktualnie", "dzisiaj", "dziś",
                                   "obecna", "w tej chwili", "na dworze", "za oknem", "jak jest"]
            weather_keywords_en = ["now", "current", "currently", "today", "right now", "at the moment",
                                   "present", "outside", "at present", "how is"]

            # Słowa kluczowe silnie wskazujące na prognozę (forecast)
            forecast_keywords_pl = ["jutro", "pojutrze", "później", "za tydzień", "weekend",
                                    "prognoza", "następne dni", "nadchodzące", "będzie", "przyszły",
                                    "w przyszłym", "za kilka dni"]
            forecast_keywords_en = ["tomorrow", "next day", "later", "next week", "weekend",
                                    "forecast", "coming days", "upcoming", "will be", "next",
                                    "in the future", "in a few days"]

            # Wybierz właściwe słowa kluczowe na podstawie języka
            weather_keywords = weather_keywords_pl if language == "pl" else weather_keywords_en
            forecast_keywords = forecast_keywords_pl if language == "pl" else forecast_keywords_en

            # Sprawdź czy zapytanie zawiera wyraźne słowa kluczowe prognozy
            has_forecast_keywords = any(keyword in cleaned_text_lower for keyword in forecast_keywords)

            # Sprawdź czy zapytanie zawiera wyraźne słowa kluczowe aktualnej pogody
            has_weather_keywords = any(keyword in cleaned_text_lower for keyword in weather_keywords)

            # Sprawdź, czy zapytanie wygląda jak zapytanie o pogodę (aktualną)
            is_weather_query = False
            if language == "pl":
                weather_patterns = ["jaka jest pogoda w", "jaka pogoda w", "pogoda w", "jak jest w"]
                if any(pattern in cleaned_text_lower for pattern in weather_patterns) and not has_forecast_keywords:
                    is_weather_query = True
            else:  # angielski
                weather_patterns = ["what's the weather in", "what is the weather in", "weather in",
                                    "how is the weather in", "how's the weather in"]
                if any(pattern in cleaned_text_lower for pattern in weather_patterns) and not has_forecast_keywords:
                    is_weather_query = True

            # Przeprowadź korektę, gdy:
            # 1. Zapytanie wygląda na zapytanie o aktualną pogodę, a model przewiduje "forecast"
            # 2. Mamy wyraźne słowa kluczowe powiązane z pogodą aktualną, a model przewiduje "forecast"
            # 3. Podobnie, jeśli zapytanie ma słowa kluczowe prognozy, a model przewiduje "weather"

            if (is_weather_query or has_weather_keywords) and best_intent == "forecast":
                # Korekta: zapytanie jest prawdopodobnie o aktualną pogodę
                print(f"Korekta: Zmieniam intencję z 'forecast' na 'weather' dla '{text}'")
                return {
                    "intent": "weather",
                    "confidence": max(confidence, 0.7),  # Ustawiamy większą pewność
                    "message": "Wykryto wzorzec pytania o aktualną pogodę"
                }

            elif has_forecast_keywords and best_intent == "weather":
                # Korekta: zapytanie jest prawdopodobnie o prognozę
                print(f"Korekta: Zmieniam intencję z 'weather' na 'forecast' dla '{text}'")
                return {
                    "intent": "forecast",
                    "confidence": max(confidence, 0.7),  # Ustawiamy większą pewność
                    "message": "Wykryto słowa kluczowe prognozy"
                }

            # ========== WYKRYWANIE ZAPYTAŃ O TEMPERATURĘ ==========
            temp_keywords_pl = ["temperatura", "stopni", "ciepło", "zimno", "ile stopni", "jaka temperatura",
                                "temperaturka", "termometr"]
            temp_keywords_en = ["temperature", "degrees", "how cold", "how hot", "how warm", "how many degrees", "temp",
                                "thermometer"]

            temp_keywords = temp_keywords_pl if language == "pl" else temp_keywords_en

            if any(keyword in cleaned_text_lower for keyword in temp_keywords):
                print(f"Wykryto zapytanie o temperaturę: '{text}'")
                return {
                    "intent": "temperature",
                    "confidence": 0.85,
                    "message": "Wykryto słowo kluczowe temperatury" if language == "pl" else "Detected temperature keyword"
                }

            # ========== WYKRYWANIE ZAPYTAŃ O DESZCZ/OPADY ==========
            rain_keywords_pl = ["czy pada", "czy jest deszcz", "czy pada deszcz", "czy leje", "deszcz", "opady", "pada",
                                "burza"]
            rain_keywords_en = ["is it raining", "is there rain", "does it rain", "rain", "raining", "precipitation",
                                "storm", "shower"]

            rain_keywords = rain_keywords_pl if language == "pl" else rain_keywords_en

            if any(keyword in cleaned_text_lower for keyword in rain_keywords):
                print(f"Wykryto zapytanie o deszcz: '{text}'")
                return {
                    "intent": "rain",
                    "confidence": 0.85,
                    "message": "Wykryto słowo kluczowe deszczu" if language == "pl" else "Detected rain keyword"
                }

            # Sprawdź, czy tekst zawiera typowe słowa kluczowe dla podziękowań (w obu językach)
            thanks_keywords_pl = ["dzięki", "dziękuję", "thank", "thx", "dziekuje", "dzieki", "podzięk"]
            thanks_keywords_en = ["thanks", "thank you", "thank", "thx", "grateful", "appreciate"]

            thanks_keywords = thanks_keywords_pl if language == "pl" else thanks_keywords_en

            if any(keyword in cleaned_text_lower for keyword in thanks_keywords):
                print(f"Wykryto słowo kluczowe podziękowania w: '{text}'")
                return {
                    "intent": "thanks",
                    "confidence": 0.95,
                    "message": "Wykryto słowo kluczowe podziękowania" if language == "pl" else "Detected thanks keyword"
                }

            # Zwróć standardową predykcję, która została obliczona na początku
            return {
                "intent": best_intent,
                "confidence": confidence
            }

        except Exception as e:
            print(f"Błąd podczas predykcji: {str(e)}")
            import traceback
            traceback.print_exc()

            err_msg = "Wystąpił błąd podczas analizy tekstu." if language == "pl" else "An error occurred during text analysis."
            return {
                "intent": "fallback",
                "confidence": 1.0,
                "message": err_msg
            }


if __name__ == "__main__":
    # Test modułu
    classifier = IntentClassifier()

    # Przykładowe zapytania
    test_queries = [
        "Cześć, jak się masz?",
        "Siema",
        "Witaj",
        "Pogoda w Warszawie",
        "Jaka jest pogoda w Krakowie?",
        "Ile stopni jest w Warszawie?",
        "Do widzenia",
        "Pa",
        "Nara",
        "Jaka jest temperatura w Gdańsku?",
        "Czy będzie dziś padać we Wrocławiu?",
        "Dziękuję",
        "Dzięki",
        "dzieki"
    ]

    for query in test_queries:
        result = classifier.predict_intent(query)
        print(f"Zapytanie: '{query}'")
        print(f"Intencja: {result['intent']}")
        print(f"Pewność: {result['confidence']:.4f}")
        print("-" * 50)