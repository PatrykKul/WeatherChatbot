from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, 
                             QLineEdit, QPushButton, QLabel, QFrame, QSplitter,
                             QScrollArea)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QPropertyAnimation, QRect
from PyQt5.QtGui import QFont, QColor, QPainter, QPalette

# Importujemy istniejącą implementację chatbota
from chatbot import Chatbot

class ChatbotWidget(QWidget):
    """
    Widget chatbota pogodowego z historią rozmowy i panelem bocznym
    z informacjami o pogodzie.
    """
    # Sygnały
    city_selected = pyqtSignal(str)
    
    def __init__(self, weather_service):
        super().__init__()
        self.weather_service = weather_service
        
        # Inicjalizacja chatbota
        self.chatbot = Chatbot()
        
        # Inicjalizacja UI
        self.init_ui()
        
        # Lista miast wykrytych w czacie
        self.detected_cities = []
        
        # Dodanie powitania
        self.add_bot_message("Witaj! Jestem chatbotem pogodowym. Możesz zapytać mnie o pogodę w dowolnym mieście.")
        self.add_bot_message("Przykład: 'Jaka jest pogoda w Warszawie?' lub 'Pogoda w Krakowie na jutro'")
        
    def init_ui(self):
        # Główny układ
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)
        
        # Splitter do podziału ekranu
        splitter = QSplitter(Qt.Horizontal)
        
        # Panel czatu (lewa strona)
        chat_panel = QWidget()
        chat_layout = QVBoxLayout(chat_panel)
        chat_layout.setContentsMargins(0, 0, 0, 0)
        
        # Historia czatu
        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        self.chat_history.setObjectName("chat_history")
        chat_layout.addWidget(self.chat_history)
        
        # Panel wprowadzania
        input_panel = QWidget()
        input_layout = QHBoxLayout(input_panel)
        input_layout.setContentsMargins(0, 10, 0, 0)
        input_layout.setSpacing(10)
        
        self.input_field = QLineEdit()
        self.input_field.setObjectName("chat_input")
        self.input_field.setPlaceholderText("Napisz wiadomość...")
        self.input_field.returnPressed.connect(self.send_message)
        
        self.send_button = QPushButton("Wyślij")
        self.send_button.setObjectName("send_button")
        self.send_button.clicked.connect(self.send_message)
        
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(self.send_button)
        
        chat_layout.addWidget(input_panel)
        
        # Panel informacji (prawa strona)
        info_panel = QWidget()
        info_layout = QVBoxLayout(info_panel)
        info_layout.setContentsMargins(10, 0, 0, 0)
        
        # Tytuł panelu
        info_title = QLabel("Ostatnie wyszukiwania pogody")
        info_title.setObjectName("panel_title")
        info_layout.addWidget(info_title)
        
        # Widget informacji o pogodzie
        self.weather_info = WeatherInfoPanel()
        info_layout.addWidget(self.weather_info)
        
        # Sugestie miast
        suggestions_title = QLabel("Wykryte miasta")
        suggestions_title.setObjectName("panel_title")
        info_layout.addWidget(suggestions_title)
        
        self.cities_panel = QScrollArea()
        self.cities_panel.setWidgetResizable(True)
        self.cities_panel.setObjectName("cities_panel")
        
        cities_content = QWidget()
        self.cities_layout = QVBoxLayout(cities_content)
        self.cities_layout.setAlignment(Qt.AlignTop)
        
        self.cities_panel.setWidget(cities_content)
        info_layout.addWidget(self.cities_panel)
        
        # Przykładowe zapytania
        examples_title = QLabel("Przykładowe zapytania")
        examples_title.setObjectName("panel_title")
        info_layout.addWidget(examples_title)
        
        examples_frame = QFrame()
        examples_frame.setObjectName("examples_frame")
        examples_layout = QVBoxLayout(examples_frame)
        
        example_queries = [
            "Jaka jest pogoda w Warszawie?",
            "Czy pada deszcz w Krakowie?",
            "Temperatura w Gdańsku",
            "Prognoza na weekend dla Poznania",
            "Jaka będzie pogoda jutro w Łodzi?",
            "Sprawdź wilgotność w Szczecinie"
        ]
        
        for query in example_queries:
            example_btn = QPushButton(query)
            example_btn.setObjectName("example_button")
            example_btn.clicked.connect(lambda _, q=query: self.set_query(q))
            examples_layout.addWidget(example_btn)
            
        info_layout.addWidget(examples_frame)
        info_layout.addStretch()
        
        # Dodanie paneli do splittera
        splitter.addWidget(chat_panel)
        splitter.addWidget(info_panel)
        
        # Proporcje podziału
        splitter.setSizes([700, 300])
        
        # Dodanie splittera do głównego układu
        main_layout.addWidget(splitter)

    # W chat_module.py, funkcja send_message
    def send_message(self):
        """Obsługa wysłania wiadomości przez użytkownika"""
        message = self.input_field.text().strip()
        if not message:
            return

        # Wyświetlenie wiadomości użytkownika
        self.add_user_message(message)

        # Przetworzenie wiadomości przez chatbota
        response = self.chatbot.get_response(message)

        # Sprawdź, czy response nie jest None
        if response is None:
            response = "Przepraszam, wystąpił problem podczas przetwarzania Twojego zapytania."

        # Wyświetlenie odpowiedzi bota
        self.add_bot_message(response)

        # Ekstrakcja informacji o pogodzie z odpowiedzi
        if response is not None:  # Dodajemy sprawdzenie czy response nie jest None
            self.extract_weather_info(response)

        # Wykrywanie miast
        self.detect_cities(message, response)

        # Wyczyszczenie pola wprowadzania
        self.input_field.clear()
    
    def add_user_message(self, message):
        """Dodaje wiadomość użytkownika do historii czatu"""
        html = f'''
            <div style="text-align: right; margin: 10px 0;">
                <span style="background-color: rgba(77, 171, 247, 0.3); 
                       padding: 8px 12px; border-radius: 15px; 
                       display: inline-block; max-width: 80%;">
                    <b>Ty:</b> {message}
                </span>
            </div>
        '''
        self.chat_history.append(html)
        self.chat_history.verticalScrollBar().setValue(
            self.chat_history.verticalScrollBar().maximum()
        )
    
    def add_bot_message(self, message):
        """Dodaje odpowiedź bota do historii czatu"""
        html = f'''
            <div style="text-align: left; margin: 10px 0;">
                <span style="background-color: rgba(0, 4, 40, 0.6); 
                       padding: 8px 12px; border-radius: 15px; 
                       display: inline-block; max-width: 80%;">
                    <b>Bot:</b> {message}
                </span>
            </div>
        '''
        self.chat_history.append(html)
        self.chat_history.verticalScrollBar().setValue(
            self.chat_history.verticalScrollBar().maximum()
        )
    
    def set_query(self, query):
        """Ustawia zapytanie w polu wprowadzania"""
        self.input_field.setText(query)
        self.input_field.setFocus()

    # Dodaj tę metodę do klasy ChatbotWidget w pliku chat_module.py

    def apply_language(self, language, translations):
        """Aktualizuje język interfejsu chatbota"""
        # Dodaj tłumaczenia specyficzne dla chatbota
        chat_translations = {
            "pl": {
                "recent_searches": "Ostatnie wyszukiwania pogody",
                "detected_cities": "Wykryte miasta",
                "example_queries": "Przykładowe zapytania",
                "chat_placeholder": "Napisz wiadomość...",
                "send_button": "Wyślij",
                "welcome_message": "Witaj! Jestem chatbotem pogodowym. Możesz zapytać mnie o pogodę w dowolnym mieście.",
                "example_message": "Przykład: 'Jaka jest pogoda w Warszawie?' lub 'Pogoda w Krakowie na jutro'"
            },
            "en": {
                "recent_searches": "Recent weather searches",
                "detected_cities": "Detected cities",
                "example_queries": "Example queries",
                "chat_placeholder": "Type a message...",
                "send_button": "Send",
                "welcome_message": "Hello! I'm a weather chatbot. You can ask me about weather in any city.",
                "example_message": "Example: 'What's the weather in London?' or 'Weather in New York tomorrow'"
            }
        }

        # Aktualizacja tekstów przycisków i pól
        self.send_button.setText(chat_translations[language]["send_button"])
        self.input_field.setPlaceholderText(chat_translations[language]["chat_placeholder"])

        # Aktualizacja etykiet paneli
        panels = self.findChildren(QLabel, "panel_title")
        for panel in panels:
            if "Ostatnie wyszukiwania pogody" in panel.text() or "Recent weather searches" in panel.text():
                panel.setText(chat_translations[language]["recent_searches"])
            elif "Wykryte miasta" in panel.text() or "Detected cities" in panel.text():
                panel.setText(chat_translations[language]["detected_cities"])
            elif "Przykładowe zapytania" in panel.text() or "Example queries" in panel.text():
                panel.setText(chat_translations[language]["example_queries"])

        # Aktualizacja przykładowych zapytań
        example_queries = {
            "pl": [
                "Jaka jest pogoda w Warszawie?",
                "Czy pada deszcz w Krakowie?",
                "Temperatura w Gdańsku",
                "Prognoza na weekend dla Poznania",
                "Jaka będzie pogoda jutro w Łodzi?",
                "Sprawdź wilgotność w Szczecinie"
            ],
            "en": [
                "What's the weather in London?",
                "Is it raining in New York?",
                "Temperature in Paris",
                "Weekend forecast for Berlin",
                "What will be the weather tomorrow in Rome?",
                "Check humidity in Madrid"
            ]
        }

        # Aktualizacja przykładowych zapytań
        example_buttons = self.findChildren(QPushButton, "example_button")
        for i, btn in enumerate(example_buttons):
            if i < len(example_queries[language]):
                btn.setText(example_queries[language][i])

        # Aktualizacja etykiet w panelu informacji o pogodzie
        if language == "pl":
            self.weather_info.humidity_label.setText("Wilgotność: --%")
            self.weather_info.pressure_label.setText("Ciśnienie: -- hPa")
            self.weather_info.wind_label.setText("Wiatr: -- m/s")
        else:
            self.weather_info.humidity_label.setText("Humidity: --%")
            self.weather_info.pressure_label.setText("Pressure: -- hPa")
            self.weather_info.wind_label.setText("Wind: -- m/s")

        # Jeśli były jakieś wiadomości chatbota, można je również zaktualizować
        # ale to wymagałoby przechowywania historii wiadomości w formie strukturalnej



    def extract_weather_info(self, response):
        """Wyciąga informacje o pogodzie z odpowiedzi bota"""
        # Sprawdzanie, czy odpowiedź zawiera dane pogodowe
        if not response:
            return

        # Najpierw sprawdź język
        language = "pl"  # domyślnie polski
        if ("Weather for:" in response or "weather for:" in response or
                "Forecast for:" in response or "Current temperature in" in response or
                "Yes, it's raining in" in response or "No, it's not raining in" in response or
                "Yes, it's snowing in" in response or "Yes, there's a storm in" in response):
            language = "en"

        # =====================================================================
        # OBSŁUGA ODPOWIEDZI O TEMPERATURZE
        # =====================================================================

        # Sprawdź czy to odpowiedź na pytanie o temperaturę (polski)
        if "Aktualna temperatura w" in response:
            # Parsowanie odpowiedzi o temperaturze
            city = ""
            temp = ""
            feels_like = ""

            # Najprostszy sposób: podział stringa i ekstrakcja informacji
            parts = response.split("Aktualna temperatura w")
            if len(parts) > 1:
                city_temp = parts[1].strip().split(":")
                if len(city_temp) > 1:
                    city = city_temp[0].strip()

                    # Ekstrakcja temperatury
                    temp_part = city_temp[1].strip()
                    if "odczuwalna" in temp_part:
                        temp = temp_part.split("(")[0].strip()
                        feels_like_part = temp_part.split("odczuwalna:")[1] if "odczuwalna:" in temp_part else ""
                        feels_like = feels_like_part.replace(")", "").strip() if feels_like_part else ""
                    else:
                        temp = temp_part.strip()

            # Aktualizacja widgetu informacji
            if city:
                self.weather_info.update_info(city, temp, "Temperatura", feels_like, "", "")
                # Sygnał o wybranym mieście
                self.city_selected.emit(city)
            return

        # Sprawdź czy to odpowiedź na pytanie o temperaturę (angielski)
        elif "Current temperature in" in response:
            # Parsowanie odpowiedzi o temperaturze
            city = ""
            temp = ""
            feels_like = ""

            # Podział stringa i ekstrakcja informacji
            parts = response.split("Current temperature in")
            if len(parts) > 1:
                city_temp = parts[1].strip().split(":")
                if len(city_temp) > 1:
                    city = city_temp[0].strip()

                    # Ekstrakcja temperatury
                    temp_part = city_temp[1].strip()
                    if "feels like" in temp_part:
                        temp = temp_part.split("(")[0].strip()
                        feels_like_part = temp_part.split("feels like")[1] if "feels like" in temp_part else ""
                        feels_like = feels_like_part.replace(")", "").strip() if feels_like_part else ""
                    else:
                        temp = temp_part.strip()

            # Aktualizacja widgetu informacji
            if city:
                self.weather_info.update_info(city, temp, "Temperature", feels_like, "", "")
                # Sygnał o wybranym mieście
                self.city_selected.emit(city)
            return


        elif "W" in response and "jest teraz" in response and "a temperatura odczuwalna to" in response:
            try:
                city = response.split("W ")[1].split(" jest teraz")[0].strip()
                temp = response.split("jest teraz ")[1].split("°C")[0].strip() + "°C"
                feels_like = response.split("a temperatura odczuwalna to ")[1].strip()

                if city:
                    self.weather_info.update_info(city, temp, "Temperatura", feels_like, "", "")
                    self.city_selected.emit(city)
                return
            except:
                print("Błąd parsowania odpowiedzi o temperaturze w języku polskim")

        # Alternatywny format odpowiedzi o temperaturze (polski)
        elif "W" in response and "jest teraz" in response and "°C" in response:
            parts = response.split("W")[1].split("jest teraz")
            if len(parts) >= 2:
                city = parts[0].strip()
                temp_parts = parts[1].strip().split("a temperatura odczuwalna to")
                temp = temp_parts[0].strip()
                feels_like = temp_parts[1].strip() if len(temp_parts) > 1 else ""

                if city:
                    self.weather_info.update_info(city, temp, "Temperatura", feels_like, "", "")
                    self.city_selected.emit(city)
                return

        # Alternatywny format odpowiedzi o temperaturze (angielski)
        elif "It's" in response and "in" in response and "right now" in response and "°C" in response:
            temp = response.split("It's")[1].split("in")[0].strip()
            city = response.split("in")[1].split("right now")[0].strip()
            feels_like = ""

            if "feels like" in response:
                feels_like = response.split("feels like")[1].strip()

            if city:
                self.weather_info.update_info(city, temp, "Temperature", feels_like, "", "")
                self.city_selected.emit(city)
            return

        # =====================================================================
        # OBSŁUGA ODPOWIEDZI O DESZCZU/OPADACH
        # =====================================================================

        # Sprawdź czy to odpowiedź na pytanie o deszcz (polski)
        if "Tak, w" in response and ("pada deszcz" in response or "pada śnieg" in response or "jest burza" in response):
            city = ""
            condition = ""

            # Ekstrakcja miasta
            if "pada deszcz" in response:
                parts = response.split("Tak, w")
                if len(parts) > 1:
                    city = parts[1].split("pada deszcz")[0].strip()
                    condition = "Pada deszcz"
            elif "pada śnieg" in response:
                parts = response.split("Tak, w")
                if len(parts) > 1:
                    city = parts[1].split("pada śnieg")[0].strip()
                    condition = "Pada śnieg"
            elif "jest burza" in response:
                parts = response.split("Tak, w")
                if len(parts) > 1:
                    city = parts[1].split("jest burza")[0].strip()
                    condition = "Burza"

            # Aktualizacja widgetu informacji
            if city:
                self.weather_info.update_info(city, "", condition, "", "", "")
                # Sygnał o wybranym mieście
                self.city_selected.emit(city)
            return

        # Sprawdź czy to odpowiedź na pytanie o brak deszczu (polski)
        elif "Nie, w" in response and "nie pada" in response:
            city = ""
            parts = response.split("Nie, w")
            if len(parts) > 1:
                city_parts = parts[1].split("nie pada")
                if len(city_parts) > 0:
                    city = city_parts[0].strip()

                if city:
                    # Ekstrakcja aktualnych warunków
                    condition = ""
                    if "Aktualne warunki:" in response:
                        condition = response.split("Aktualne warunki:")[1].strip()
                    else:
                        condition = "Brak opadów"

                    # Aktualizacja widgetu informacji
                    self.weather_info.update_info(city, "", condition, "", "", "")
                    # Sygnał o wybranym mieście
                    self.city_selected.emit(city)
            return

        # Sprawdź czy to odpowiedź na pytanie o deszcz (angielski)
        elif ("Yes, it's raining in" in response or "Yes, it's snowing in" in response or
              "Yes, there's a storm in" in response):
            city = ""
            condition = ""

            if "Yes, it's raining in" in response:
                parts = response.split("Yes, it's raining in")
                if len(parts) > 1:
                    city = parts[1].split("right now")[0].strip().rstrip(".")
                    condition = "Raining"
            elif "Yes, it's snowing in" in response:
                parts = response.split("Yes, it's snowing in")
                if len(parts) > 1:
                    city = parts[1].split("right now")[0].strip().rstrip(".")
                    condition = "Snowing"
            elif "Yes, there's a storm in" in response:
                parts = response.split("Yes, there's a storm in")
                if len(parts) > 1:
                    city = parts[1].split("right now")[0].strip().rstrip(".")
                    condition = "Storm"

            # Aktualizacja widgetu informacji
            if city:
                self.weather_info.update_info(city, "", condition, "", "", "")
                # Sygnał o wybranym mieście
                self.city_selected.emit(city)
            return

        # Sprawdź czy to odpowiedź na pytanie o brak deszczu (angielski)
        elif "No, it's not raining in" in response:
            city = ""
            parts = response.split("No, it's not raining in")
            if len(parts) > 1:
                city_parts = parts[1].split("right now")
                if len(city_parts) > 0:
                    city = city_parts[0].strip().rstrip(".")

                if city:
                    # Ekstrakcja aktualnych warunków
                    condition = ""
                    if "Current conditions:" in response:
                        condition = response.split("Current conditions:")[1].strip()
                    else:
                        condition = "No precipitation"

                    # Aktualizacja widgetu informacji
                    self.weather_info.update_info(city, "", condition, "", "", "")
                    # Sygnał o wybranym mieście
                    self.city_selected.emit(city)
            return

        # =====================================================================
        # OBSŁUGA STANDARDOWYCH ODPOWIEDZI POGODOWYCH
        # =====================================================================

        # Sprawdzanie standardowych odpowiedzi pogodowych
        if ("Pogoda dla:" in response or "pogoda dla:" in response or "Prognoza dla:" in response) or \
                ("Weather for:" in response or "weather for:" in response or "Forecast for:" in response):
            # Parsowanie odpowiedzi
            city = ""
            temp = ""
            condition = ""
            humidity = ""
            pressure = ""
            wind = ""

            # Wyciąganie informacji linijka po linijce
            lines = response.split('\n')
            for line in lines:
                # Obsługa obu języków dla wykrywania miasta
                if language == "pl":
                    if "Pogoda dla:" in line or "pogoda dla:" in line or "Prognoza dla:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            city_country = parts[1].strip().split(',')
                            city = city_country[0].strip()
                else:  # angielski
                    if "Weather for:" in line or "weather for:" in line or "Forecast for:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            city_country = parts[1].strip().split(',')
                            city = city_country[0].strip()

                # Obsługa temperatury
                if language == "pl":
                    if "Temperatura:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            temp = parts[1].strip()
                else:  # angielski
                    if "Temperature:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            temp = parts[1].strip()

                # Obsługa wilgotności
                if language == "pl":
                    if "Wilgotność:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            humidity = parts[1].strip()
                else:  # angielski
                    if "Humidity:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            humidity = parts[1].strip()

                # Obsługa ciśnienia
                if language == "pl":
                    if "Ciśnienie:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            pressure = parts[1].strip()
                else:  # angielski
                    if "Pressure:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            pressure = parts[1].strip()

                # Obsługa wiatru
                if language == "pl":
                    if "Wiatr:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            wind = parts[1].strip()
                else:  # angielski
                    if "Wind:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            wind = parts[1].strip()

                # Określanie stanu pogody
                if language == "pl":
                    for weather_cond in ["słonecznie", "pochmurnie", "deszcz", "śnieg", "bezchmurnie", "burza", "mgła"]:
                        if weather_cond in line.lower():
                            condition = weather_cond.capitalize()
                            break
                else:  # angielski
                    for weather_cond in ["sunny", "cloudy", "rain", "snow", "clear", "thunderstorm", "fog", "storm"]:
                        if weather_cond in line.lower():
                            condition = weather_cond.capitalize()
                            break

            # Aktualizacja widgetu informacji
            if city:
                self.weather_info.update_info(city, temp, condition, humidity, pressure, wind)

                # Sygnał o wybranym mieście
                self.city_selected.emit(city)

        # =====================================================================
        # OBSŁUGA WYKRYWANIA MIAST W TEKŚCIE
        # =====================================================================

        # Wykrywanie miast w odpowiedzi (jeśli nie znaleziono w powyższych przypadkach)
        self.detect_cities(response, "")


    def detect_cities(self, message, response):
        """Wykrywa miasta w wiadomościach i odpowiedziach"""
        # Sprawdź język
        language = "pl"  # domyślnie polski
        if "Weather for:" in response or "weather for:" in response or "Forecast for:" in response:
            language = "en"

        # Szukamy miast w odpowiedzi bota
        city = ""

        if language == "pl":
            # Sprawdzanie nagłówka "Pogoda dla: Miasto"
            if "Pogoda dla:" in response or "pogoda dla:" in response or "Prognoza dla:" in response:
                lines = response.split('\n')
                for line in lines:
                    if "Pogoda dla:" in line or "pogoda dla:" in line or "Prognoza dla:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            city_country = parts[1].strip().split(',')
                            city = city_country[0].strip()
                            break
        else:  # angielski
            # Sprawdzanie nagłówka "Weather for: City"
            if "Weather for:" in response or "weather for:" in response or "Forecast for:" in response:
                lines = response.split('\n')
                for line in lines:
                    if "Weather for:" in line or "weather for:" in line or "Forecast for:" in line:
                        parts = line.split(':')
                        if len(parts) > 1:
                            city_country = parts[1].strip().split(',')
                            city = city_country[0].strip()
                            break

        # Dodanie miasta do listy wykrytych miast
        if city and city not in self.detected_cities:
            self.detected_cities.append(city)
            self.update_cities_panel()

            # Automatyczne powiadomienie o nowym mieście
            self.city_selected.emit(city)


    def update_cities_panel(self):
        """Aktualizuje panel wykrytych miast"""
        # Wyczyszczenie panelu
        while self.cities_layout.count():
            item = self.cities_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Dodanie przycisków dla każdego miasta
        for city in self.detected_cities:
            city_btn = QPushButton(city)
            city_btn.setObjectName("city_button")
            city_btn.clicked.connect(lambda _, c=city: self.select_city(c))
            self.cities_layout.addWidget(city_btn)
    
    def select_city(self, city):
        """Obsługa wyboru miasta z panelu"""
        # Ustawienie zapytania
        self.set_query(f"Jaka jest pogoda w {city}?")
        
        # Emitowanie sygnału o wybranym mieście
        self.city_selected.emit(city)

    def update_ui(self, app_context):
        """Aktualizacja UI na podstawie kontekstu aplikacji"""
        # Aktualizacja listy wykrytych miast o ostatnio używane miasta
        recent_cities = app_context.get("recent_cities", [])
        for city in recent_cities:
            if city and city not in self.detected_cities:
                self.detected_cities.append(city)

        # Aktualizacja panelu miast
        self.update_cities_panel()

        # Upewnij się, że przyciski przykładów mają właściwe teksty
        example_buttons = [
            "Jaka jest pogoda w Warszawie?",
            "Czy pada deszcz w Krakowie?",
            "Temperatura w Gdańsku",
            "Prognoza na weekend dla Poznania",
            "Jaka będzie pogoda jutro w Łodzi?",
            "Sprawdź wilgotność w Szczecinie"
        ]

        # Znajdź wszystkie przyciski przykładów i aktualizuj ich tekst
        for i, child in enumerate(self.cities_layout.children()):
            if isinstance(child, QPushButton) and i < len(example_buttons):
                child.setText(example_buttons[i])
    
    def apply_preferences(self, prefs):
        """Zastosowanie preferencji użytkownika"""
        # Na razie nic do zrobienia dla chatbota
        pass


class WeatherInfoPanel(QFrame):
    """Panel wyświetlający podstawowe informacje o pogodzie"""
    
    def __init__(self):
        super().__init__()
        self.setObjectName("weather_info_panel")
        
        # Inicjalizacja UI
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Miasto
        self.city_label = QLabel("-- --")
        self.city_label.setObjectName("info_city")
        layout.addWidget(self.city_label)
        
        # Temperatura i stan
        temp_layout = QHBoxLayout()
        
        self.temp_label = QLabel("--°C")
        self.temp_label.setObjectName("info_temp")
        
        self.condition_label = QLabel("--")
        self.condition_label.setObjectName("info_condition")
        
        temp_layout.addWidget(self.temp_label)
        temp_layout.addStretch()
        temp_layout.addWidget(self.condition_label)
        
        layout.addLayout(temp_layout)
        
        # Detale
        details_layout = QVBoxLayout()
        
        self.humidity_label = QLabel("Wilgotność: --%")
        self.humidity_label.setObjectName("info_detail")
        
        self.pressure_label = QLabel("Ciśnienie: -- hPa")
        self.pressure_label.setObjectName("info_detail")
        
        self.wind_label = QLabel("Wiatr: -- m/s")
        self.wind_label.setObjectName("info_detail")
        
        details_layout.addWidget(self.humidity_label)
        details_layout.addWidget(self.pressure_label)
        details_layout.addWidget(self.wind_label)
        
        layout.addLayout(details_layout)
        layout.addStretch()
    
    def update_info(self, city, temp, condition, humidity, pressure, wind):
        """Aktualizacja informacji o pogodzie"""
        self.city_label.setText(city)
        self.temp_label.setText(temp if temp else "--°C")
        self.condition_label.setText(condition if condition else "--")
        self.humidity_label.setText(f"Wilgotność: {humidity}" if humidity else "Wilgotność: --%")
        self.pressure_label.setText(f"Ciśnienie: {pressure}" if pressure else "Ciśnienie: -- hPa")
        self.wind_label.setText(f"Wiatr: {wind}" if wind else "Wiatr: -- m/s")