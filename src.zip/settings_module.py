from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QComboBox, QCheckBox, QSlider, QFrame,
                             QPushButton, QGroupBox, QFormLayout, QSpinBox)
from PyQt5.QtCore import Qt, QSettings, pyqtSignal
from PyQt5.QtGui import QFont, QColor


class SettingsDialog(QDialog):
    """
    Dialog ustawień aplikacji Weather Chatbot Pro.
    Obsługuje pełną funkcjonalność zapisywania i przywracania preferencji użytkownika.
    """

    # Sygnał informujący o zmianie ustawień
    settings_changed = pyqtSignal(dict)

    def __init__(self, preferences):
        super().__init__()
        self.setWindowTitle("Ustawienia")
        self.setMinimumWidth(600)
        self.setMinimumHeight(800)
        self.setModal(True)

        # Kopia preferencji (głęboka kopia, aby uniknąć modyfikacji oryginału)
        self.preferences = preferences.copy() if preferences else {}

        # Ustawienie wartości domyślnych dla brakujących parametrów
        self.ensure_default_preferences()

        # Inicjalizacja UI
        self.init_ui()

        # Ustawienie wartości kontrolek na podstawie preferencji
        self.apply_preferences()

        # Zastosowanie stylu
        self.apply_style()

        # Debug
        print(f"Inicjalizacja ustawień: {self.preferences}")

    def ensure_default_preferences(self):
        """Zapewnia, że wszystkie wymagane preferencje mają wartości domyślne"""
        defaults = {
            "theme": "dark",
            "animation_level": "normal",
            "transparency": 30,
            "auto_refresh": 30,
            "default_city": "Warszawa",
            "temperature_unit": "celsius",
            "notification_alerts": True,
            "alert_rain": True,
            "alert_temp": True,
            "alert_wind": True,
            "alert_storm": True,
            "sound_volume": 50,
            "muted": False
        }

        # Dodaj brakujące klucze
        for key, value in defaults.items():
            if key not in self.preferences:
                self.preferences[key] = value

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(15)

        # Tytuł
        title_label = QLabel("Ustawienia aplikacji")
        title_label.setObjectName("settings_title")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setFont(QFont("Segoe UI", 16, QFont.Bold))
        main_layout.addWidget(title_label)

        # Grupa - Wygląd
        appearance_group = QGroupBox("Wygląd")
        appearance_group.setObjectName("settings_group")
        appearance_layout = QFormLayout()
        appearance_layout.setSpacing(12)
        appearance_layout.setLabelAlignment(Qt.AlignRight)

        # Motyw
        self.theme_combo = QComboBox()
        self.theme_combo.setObjectName("settings_combo")
        self.theme_combo.addItems(["Ciemny", "Jasny", "Auto (pora dnia)"])
        appearance_layout.addRow(self.create_label("Motyw aplikacji:"), self.theme_combo)

        # Poziom animacji
        self.animation_combo = QComboBox()
        self.animation_combo.setObjectName("settings_combo")
        self.animation_combo.addItems(["Podstawowe", "Normalne", "Wysokie", "Ultra"])
        appearance_layout.addRow(self.create_label("Efekty wizualne:"), self.animation_combo)

        # Przezroczystość
        slider_layout = QHBoxLayout()
        self.transparency_slider = QSlider(Qt.Horizontal)
        self.transparency_slider.setObjectName("settings_slider")
        self.transparency_slider.setRange(0, 100)
        self.transparency_slider.setValue(30)
        self.transparency_value = QLabel("30%")
        self.transparency_value.setObjectName("slider_value")
        self.transparency_slider.valueChanged.connect(
            lambda v: self.transparency_value.setText(f"{v}%"))

        slider_layout.addWidget(self.transparency_slider)
        slider_layout.addWidget(self.transparency_value)

        appearance_layout.addRow(self.create_label("Przezroczystość tła:"), slider_layout)

        # Dźwięk - Głośność
        sound_slider_layout = QHBoxLayout()
        self.sound_volume_slider = QSlider(Qt.Horizontal)
        self.sound_volume_slider.setObjectName("settings_slider")
        self.sound_volume_slider.setRange(0, 100)
        self.sound_volume_slider.setValue(50)
        self.sound_volume_value = QLabel("50%")
        self.sound_volume_value.setObjectName("slider_value")
        self.sound_volume_slider.valueChanged.connect(
            lambda v: self.sound_volume_value.setText(f"{v}%"))

        sound_slider_layout.addWidget(self.sound_volume_slider)
        sound_slider_layout.addWidget(self.sound_volume_value)

        appearance_layout.addRow(self.create_label("Głośność dźwięku:"), sound_slider_layout)

        # Wyciszenie dźwięku
        self.mute_check = QCheckBox("Wycisz dźwięki aplikacji")
        self.mute_check.setObjectName("settings_checkbox")
        appearance_layout.addRow("", self.mute_check)

        appearance_group.setLayout(appearance_layout)

        # Grupa - Zachowanie
        behavior_group = QGroupBox("Zachowanie")
        behavior_group.setObjectName("settings_group")
        behavior_layout = QFormLayout()
        behavior_layout.setSpacing(12)
        behavior_layout.setLabelAlignment(Qt.AlignRight)

        # Auto-odświeżanie
        self.auto_refresh_combo = QComboBox()
        self.auto_refresh_combo.setObjectName("settings_combo")
        self.auto_refresh_combo.addItems([
            "Wyłączone",
            "Co 15 minut",
            "Co 30 minut",
            "Co godzinę"
        ])
        behavior_layout.addRow(self.create_label("Auto-odświeżanie pogody:"), self.auto_refresh_combo)

        # Domyślne miasto
        self.default_city_combo = QComboBox()
        self.default_city_combo.setObjectName("settings_combo")
        self.default_city_combo.setEditable(True)
        self.default_city_combo.addItems(["Warszawa", "Kraków", "Gdańsk", "Wrocław", "Poznań"])
        behavior_layout.addRow(self.create_label("Domyślne miasto:"), self.default_city_combo)

        # Jednostka temperatury
        self.temp_unit_combo = QComboBox()
        self.temp_unit_combo.setObjectName("settings_combo")
        self.temp_unit_combo.addItems(["Celsjusz (°C)", "Fahrenheit (°F)", "Kelvin (K)"])
        behavior_layout.addRow(self.create_label("Jednostka temperatury:"), self.temp_unit_combo)

        behavior_group.setLayout(behavior_layout)

        # Grupa - Powiadomienia
        notifications_group = QGroupBox("Powiadomienia")
        notifications_group.setObjectName("settings_group")
        notifications_layout = QVBoxLayout()
        notifications_layout.setSpacing(10)

        # Włączenie powiadomień
        self.notifications_check = QCheckBox("Włącz powiadomienia o ważnych zmianach pogody")
        self.notifications_check.setObjectName("settings_checkbox")
        self.notifications_check.setChecked(True)
        self.notifications_check.stateChanged.connect(self.toggle_alert_options)
        notifications_layout.addWidget(self.notifications_check)

        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        separator.setObjectName("settings_separator")
        notifications_layout.addWidget(separator)

        # Typy alertów
        alert_label = QLabel("Wybierz typy alertów do wyświetlania:")
        alert_label.setObjectName("section_label")
        notifications_layout.addWidget(alert_label)

        alert_layout = QVBoxLayout()
        alert_layout.setContentsMargins(20, 5, 0, 5)
        alert_layout.setSpacing(8)

        self.alert_rain_check = QCheckBox("Deszcz")
        self.alert_rain_check.setObjectName("settings_checkbox")
        self.alert_rain_check.setChecked(True)

        self.alert_temp_check = QCheckBox("Skrajne temperatury")
        self.alert_temp_check.setObjectName("settings_checkbox")
        self.alert_temp_check.setChecked(True)

        self.alert_wind_check = QCheckBox("Silny wiatr")
        self.alert_wind_check.setObjectName("settings_checkbox")
        self.alert_wind_check.setChecked(True)

        self.alert_storm_check = QCheckBox("Burze")
        self.alert_storm_check.setObjectName("settings_checkbox")
        self.alert_storm_check.setChecked(True)

        alert_layout.addWidget(self.alert_rain_check)
        alert_layout.addWidget(self.alert_temp_check)
        alert_layout.addWidget(self.alert_wind_check)
        alert_layout.addWidget(self.alert_storm_check)

        notifications_layout.addLayout(alert_layout)
        notifications_group.setLayout(notifications_layout)

        # Przyciski
        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(10)

        self.reset_btn = QPushButton("Przywróć domyślne")
        self.reset_btn.setObjectName("settings_button")
        self.reset_btn.clicked.connect(self.reset_to_defaults)

        self.cancel_btn = QPushButton("Anuluj")
        self.cancel_btn.setObjectName("settings_button")
        self.cancel_btn.clicked.connect(self.reject)

        self.save_btn = QPushButton("Zapisz")
        self.save_btn.setObjectName("settings_button_primary")
        self.save_btn.clicked.connect(self.save_and_close)
        self.save_btn.setDefault(True)

        buttons_layout.addWidget(self.reset_btn)
        buttons_layout.addStretch()
        buttons_layout.addWidget(self.cancel_btn)
        buttons_layout.addWidget(self.save_btn)

        # Dodanie wszystkich elementów do głównego layoutu
        main_layout.addWidget(appearance_group)
        main_layout.addWidget(behavior_group)
        main_layout.addWidget(notifications_group)
        main_layout.addLayout(buttons_layout)

    def toggle_alert_options(self, state):
        """Włącza/wyłącza opcje alertów w zależności od stanu głównego checkboxa"""
        enabled = state == Qt.Checked
        self.alert_rain_check.setEnabled(enabled)
        self.alert_temp_check.setEnabled(enabled)
        self.alert_wind_check.setEnabled(enabled)
        self.alert_storm_check.setEnabled(enabled)

    def create_label(self, text):
        """Tworzy label z odpowiednim stylem"""
        label = QLabel(text)
        label.setObjectName("settings_label")
        return label

    def apply_preferences(self):
        """Ustawia kontrolki na podstawie preferencji"""
        # Debug
        print(f"Stosowanie preferencji: {self.preferences}")

        # Motyw
        theme_map = {
            "dark": 0,
            "light": 1,
            "auto": 2
        }
        self.theme_combo.setCurrentIndex(theme_map.get(self.preferences.get("theme", "dark"), 0))

        # Efekty wizualne
        animation_map = {
            "basic": 0,
            "normal": 1,
            "high": 2,
            "ultra": 3
        }
        self.animation_combo.setCurrentIndex(animation_map.get(self.preferences.get("animation_level", "normal"), 1))

        # Przezroczystość
        transparency = self.preferences.get("transparency", 30)
        self.transparency_slider.setValue(transparency)
        self.transparency_value.setText(f"{transparency}%")

        # Głośność
        volume = self.preferences.get("sound_volume", 50)
        self.sound_volume_slider.setValue(volume)
        self.sound_volume_value.setText(f"{volume}%")

        # Wyciszenie
        self.mute_check.setChecked(self.preferences.get("muted", False))

        # Auto-odświeżanie
        refresh_map = {
            0: 0,  # Wyłączone
            15: 1,  # Co 15 minut
            30: 2,  # Co 30 minut
            60: 3  # Co godzinę
        }
        self.auto_refresh_combo.setCurrentIndex(refresh_map.get(self.preferences.get("auto_refresh", 30), 2))

        # Domyślne miasto
        default_city = self.preferences.get("default_city", "Warszawa")
        self.default_city_combo.setCurrentText(default_city)

        # Jednostka temperatury
        unit_map = {
            "celsius": 0,
            "fahrenheit": 1,
            "kelvin": 2
        }
        self.temp_unit_combo.setCurrentIndex(unit_map.get(self.preferences.get("temperature_unit", "celsius"), 0))

        # Powiadomienia
        notifications_enabled = self.preferences.get("notification_alerts", True)
        self.notifications_check.setChecked(notifications_enabled)

        # Typy alertów
        self.alert_rain_check.setChecked(self.preferences.get("alert_rain", True))
        self.alert_temp_check.setChecked(self.preferences.get("alert_temp", True))
        self.alert_wind_check.setChecked(self.preferences.get("alert_wind", True))
        self.alert_storm_check.setChecked(self.preferences.get("alert_storm", True))

        # Aktualizacja stanu kontrolek alertów
        self.toggle_alert_options(Qt.Checked if notifications_enabled else Qt.Unchecked)

    def get_preferences(self):
        """Zwraca preferencje na podstawie wybranych opcji"""
        # Mapowanie indeksów na wartości
        theme_map = ["dark", "light", "auto"]
        animation_map = ["basic", "normal", "high", "ultra"]
        refresh_map = [0, 15, 30, 60]  # minuty
        temp_unit_map = ["celsius", "fahrenheit", "kelvin"]

        # Aktualizacja preferencji
        self.preferences["theme"] = theme_map[self.theme_combo.currentIndex()]
        self.preferences["animation_level"] = animation_map[self.animation_combo.currentIndex()]
        self.preferences["transparency"] = self.transparency_slider.value()
        self.preferences["sound_volume"] = self.sound_volume_slider.value()
        self.preferences["muted"] = self.mute_check.isChecked()

        self.preferences["auto_refresh"] = refresh_map[self.auto_refresh_combo.currentIndex()]
        self.preferences["default_city"] = self.default_city_combo.currentText()
        self.preferences["temperature_unit"] = temp_unit_map[self.temp_unit_combo.currentIndex()]

        self.preferences["notification_alerts"] = self.notifications_check.isChecked()
        self.preferences["alert_rain"] = self.alert_rain_check.isChecked()
        self.preferences["alert_temp"] = self.alert_temp_check.isChecked()
        self.preferences["alert_wind"] = self.alert_wind_check.isChecked()
        self.preferences["alert_storm"] = self.alert_storm_check.isChecked()

        # Debug
        print(f"Pobrane preferencje: {self.preferences}")

        return self.preferences

    def save_and_close(self):
        """Zapisuje ustawienia i zamyka dialog"""
        updated_prefs = self.get_preferences()

        # Emituj sygnał informujący o zmianie ustawień
        self.settings_changed.emit(updated_prefs)

        # Zaakceptuj dialog (zamknij z kodem sukcesu)
        self.accept()

    def reset_to_defaults(self):
        """Przywraca domyślne ustawienia"""
        default_preferences = {
            "theme": "dark",
            "animation_level": "normal",
            "transparency": 30,
            "auto_refresh": 30,
            "default_city": "Warszawa",
            "temperature_unit": "celsius",
            "notification_alerts": True,
            "alert_rain": True,
            "alert_temp": True,
            "alert_wind": True,
            "alert_storm": True,
            "sound_volume": 50,
            "muted": False
        }

        self.preferences = default_preferences
        self.apply_preferences()

    def apply_style(self):
        """Stosuje styl spójny z główną aplikacją"""
        self.setStyleSheet("""
            /* Główne tło */
            QDialog {
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:1,
                    stop:0 rgba(15, 32, 64, 0.95),
                    stop:1 rgba(30, 64, 128, 0.95)
                );
                border: 2px solid #4dabf7;
                border-radius: 10px;
            }

            /* Tytuł */
            QLabel#settings_title {
                color: #4dabf7;
                font-size: 22px;
                font-weight: bold;
                padding: 10px;
                text-shadow: 0 0 10px rgba(77, 171, 247, 0.5);
            }

            /* Grupy ustawień */
            QGroupBox#settings_group {
                background-color: rgba(15, 32, 64, 0.7);
                border: 2px solid #4dabf7;
                border-radius: 10px;
                margin-top: 25px;
                font-weight: bold;
                color: #4dabf7;
            }

            QGroupBox#settings_group::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 15px;
                color: #4dabf7;
                font-size: 16px;
            }

            /* Etykiety */
            QLabel#settings_label {
                color: #a0e7ff;
                font-weight: bold;
                padding-right: 10px;
            }

            QLabel#section_label {
                color: #a0e7ff;
                font-weight: bold;
                margin-top: 5px;
            }

            QLabel#slider_value {
                color: #4dabf7;
                font-weight: bold;
                min-width: 45px;
                margin-left: 10px;
            }

            /* Combobox */
            QComboBox#settings_combo {
                background-color: rgba(15, 32, 64, 0.7);
                border: 2px solid #4dabf7;
                border-radius: 6px;
                color: #a0e7ff;
                padding: 5px 10px;
                min-height: 30px;
                min-width: 180px;
            }

            QComboBox#settings_combo::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: center right;
                width: 20px;
                border-left: 1px solid #4dabf7;
            }

            QComboBox#settings_combo:hover {
                border-color: #a0e7ff;
                background-color: rgba(77, 171, 247, 0.2);
            }

            QComboBox#settings_combo QAbstractItemView {
                background-color: rgba(15, 32, 64, 0.95);
                border: 2px solid #4dabf7;
                selection-background-color: rgba(77, 171, 247, 0.3);
                color: #a0e7ff;
                border-radius: 5px;
                padding: 5px;
            }

            /* Slider */
            QSlider#settings_slider {
                min-height: 30px;
            }

            QSlider#settings_slider::groove:horizontal {
                border: 1px solid #4dabf7;
                height: 8px;
                background: rgba(15, 32, 64, 0.7);
                border-radius: 4px;
            }

            QSlider#settings_slider::handle:horizontal {
                background: #4dabf7;
                border: 2px solid #a0e7ff;
                width: 16px;
                margin: -5px 0;
                border-radius: 8px;
            }

            QSlider#settings_slider::handle:horizontal:hover {
                background: #a0e7ff;
            }

            /* Checkbox */
            QCheckBox#settings_checkbox {
                color: #a0e7ff;
                spacing: 8px;
                min-height: 24px;
            }

            QCheckBox#settings_checkbox::indicator {
                width: 18px;
                height: 18px;
                border: 2px solid #4dabf7;
                border-radius: 3px;
                background-color: rgba(15, 32, 64, 0.7);
            }

            QCheckBox#settings_checkbox::indicator:checked {
                background-color: rgba(77, 171, 247, 0.7);
                image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>');
            }

            QCheckBox#settings_checkbox::indicator:hover {
                border-color: #a0e7ff;
            }

            QCheckBox#settings_checkbox:disabled {
                color: #566d82;
            }

            QCheckBox#settings_checkbox::indicator:disabled {
                border-color: #566d82;
                background-color: rgba(15, 32, 64, 0.5);
            }

            /* Separator */
            QFrame#settings_separator {
                background-color: #4dabf7;
                max-height: 1px;
                margin: 5px 0;
            }

            /* Przyciski */
            QPushButton#settings_button {
                background-color: rgba(77, 171, 247, 0.2);
                border: 2px solid #4dabf7;
                border-radius: 6px;
                color: #a0e7ff;
                font-weight: bold;
                padding: 8px 16px;
                min-width: 120px;
                min-height: 35px;
            }

            QPushButton#settings_button:hover {
                background-color: rgba(77, 171, 247, 0.4);
                border-color: #a0e7ff;
            }

            QPushButton#settings_button:pressed {
                background-color: rgba(77, 171, 247, 0.6);
            }

            QPushButton#settings_button_primary {
                background-color: rgba(77, 171, 247, 0.5);
                border: 2px solid #4dabf7;
                border-radius: 6px;
                color: white;
                font-weight: bold;
                padding: 8px 16px;
                min-width: 120px;
                min-height: 35px;
            }

            QPushButton#settings_button_primary:hover {
                background-color: rgba(77, 171, 247, 0.7);
                border-color: #a0e7ff;
            }

            QPushButton#settings_button_primary:pressed {
                background-color: rgba(77, 171, 247, 0.9);
            }
        """)