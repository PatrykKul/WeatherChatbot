import re
import string
import os
import json
import sys
from typing import Union, List, Dict, Set, Optional, Tuple

# English cities
ENGLISH_CITIES = {
    'london', 'paris', 'rome', 'berlin', 'madrid', 'barcelona', 'amsterdam', 'prague',
    'vienna', 'budapest', 'athens', 'lisbon', 'dublin', 'copenhagen', 'oslo', 'stockholm',
    'helsinki', 'moscow', 'st petersburg', 'kiev', 'minsk', 'riga', 'tallinn', 'vilnius',
    'brussels', 'geneva', 'zurich', 'munich', 'hamburg', 'frankfurt', 'stuttgart',
    'milan', 'venice', 'florence', 'marseille', 'lyon', 'toulouse', 'nice', 'porto',
    'valencia', 'seville', 'palermo', 'naples', 'bucharest', 'belgrade', 'zagreb',
    'ljubljana', 'sarajevo', 'sofia', 'tirana', 'skopje', 'warsaw',

    # World cities
    'new york', 'washington', 'chicago', 'los angeles', 'houston', 'philadelphia',
    'boston', 'miami', 'las vegas', 'san francisco', 'atlanta', 'dallas', 'detroit',
    'seattle', 'denver', 'toronto', 'montreal', 'vancouver', 'quebec', 'ottawa',
    'mexico city', 'havana', 'lima', 'santiago', 'sao paulo', 'buenos aires',
    'rio de janeiro', 'bogota', 'caracas', 'tokyo', 'beijing', 'shanghai', 'hong kong',
    'singapore', 'seoul', 'bangkok', 'mumbai', 'delhi', 'calcutta', 'dhaka', 'jakarta',
    'manila', 'hanoi', 'taipei', 'kuala lumpur', 'sydney', 'melbourne', 'brisbane',
    'auckland', 'wellington', 'cairo', 'casablanca', 'nairobi', 'johannesburg',
    'cape town', 'lagos', 'dakar', 'tunis', 'algiers', 'dubai', 'abu dhabi', 'riyadh',
    'doha', 'tehran', 'baghdad', 'tel aviv', 'jerusalem', 'beirut', 'amman', 'istanbul', 'ankara'
}

# Special forms of English city names
ENGLISH_CITY_FORMS = {
    "ny": "new york",
    "nyc": "new york",
    "la": "los angeles",
    "sf": "san francisco",
    "dc": "washington",
    "philly": "philadelphia",
    "vegas": "las vegas",
    "mexico": "mexico city",
    "rio": "rio de janeiro",
    "spb": "st petersburg",
    "hk": "hong kong",
    "kl": "kuala lumpur",
    "cape": "cape town",
    "jo'burg": "johannesburg",
    "joburg": "johannesburg"
}

# Lista polskich i światowych miast w formie podstawowej (mianownik)
POLISH_CITIES = {
    # Polskie miasta
    'warszawa', 'kraków', 'łódź', 'wrocław', 'poznań', 'gdańsk', 'szczecin', 'bydgoszcz', 'alaska','koyuk',
    'lublin', 'białystok', 'katowice', 'gdynia', 'częstochowa', 'radom', 'sosnowiec',
    'toruń', 'kielce', 'rzeszów', 'gliwice', 'zabrze', 'olsztyn', 'bytom', 'zielona góra',
    'rybnik', 'ruda śląska', 'opole', 'tychy', 'gorzów wielkopolski', 'dąbrowa górnicza',
    'płock', 'elbląg', 'wałbrzych', 'włocławek', 'tarnów', 'chorzów', 'koszalin', 'kalisz',
    'legnica', 'grudziądz', 'jaworzno', 'słupsk', 'jastrzębie-zdrój', 'nowy sącz', 'jelenia góra',
    'siedlce', 'mysłowice', 'piła', 'lubin', 'ostrów wielkopolski', 'łomża', 'zakopane',
    'sopot', 'kołobrzeg', 'mielec', 'tarnobrzeg', 'przemyśl', 'zamość', 'suwałki', 'cieszyn',
    'gniezno', 'leszno', 'piotrków trybunalski', 'inowrocław', 'krosno', 'puławy', 'oświęcim',
    'biała podlaska', 'pruszków', 'mińsk mazowiecki', 'sanok', 'ustka', 'tczew', 'mikołów',
    'kutno', 'głogów', 'żywiec', 'august', 'grodzisk mazowiecki', 'bielsk podlaski', 'chełm',
    'bolesławiec', 'piaseczno', 'ostrołęka', 'skierniewice', 'stargard', 'wadowice', 'nysa',
    'wejherowo', 'rumia', 'starachowice', 'sochaczew', 'świnoujście', 'wodzisław śląski',
    'legionowo', 'świdnica', 'ostrowiec świętokrzyski', 'zawiercie', 'stalowa wola', 'brzeg',
    'ciechanów', 'świętochłowice', 'malborg', 'kędzierzyn-koźle', 'racibórz', 'pabianice',
    'chrzanów', 'żary', 'kłodzko', 'jarosław', 'pszczyna', 'żyrardów', 'kartuzy', 'skarżysko-kamienna',
    'szczecinek', 'tomaszów mazowiecki', 'lębork', 'zakopane', 'kętrzyn', 'mielec', 'ełk',
    'jasło', 'zgierz', 'giżycko', 'krapkowice', 'śrem', 'piekary śląskie', 'krosno', 'kamienna góra', 'zambrów',

    # Zagraniczne miasta
    'londyn', 'paryż', 'rzym', 'berlin', 'madryt', 'barcelona', 'amsterdam', 'praga', 'wiedeń',
    'budapeszt', 'ateny', 'lizbona', 'dublin', 'kopenhaga', 'oslo', 'sztokholm', 'helsinki',
    'moskwa', 'petersburg', 'kijów', 'mińsk', 'ryga', 'tallin', 'wilno', 'bruksela', 'genewa',
    'zurych', 'monachium', 'hamburg', 'frankfurt', 'stuttgart', 'mediolan', 'wenecja', 'florencja',
    'marsylia', 'lyon', 'tuluza', 'nicea', 'porto', 'walencja', 'sewilla', 'palermo', 'neapol',
    'bukareszt', 'belgrad', 'zagrzeb', 'lublana', 'sarajewo', 'sofija', 'tirana', 'skopje',

    # Miasta światowe
    'nowy jork', 'waszyngton', 'chicago', 'los angeles', 'houston', 'filadelfia', 'boston', 'miami',
    'las vegas', 'san francisco', 'atlanta', 'dallas', 'detroit', 'seattle', 'denver', 'toronto',
    'montreal', 'vancouver', 'quebec', 'ottawa', 'meksyk', 'hawana', 'lima', 'santiago', 'sao paulo',
    'buenos aires', 'rio de janeiro', 'bogota', 'caracas', 'tokio', 'pekin', 'szanghaj', 'hong kong',
    'singapur', 'seul', 'bangkok', 'mumbaj', 'delhi', 'kalkuta', 'dhaka', 'jakarta', 'manila', 'hanoi',
    'tajpej', 'kuala lumpur', 'sydney', 'melbourne', 'brisbane', 'auckland', 'wellington', 'kair',
    'casablanca', 'nairobi', 'johannesburg', 'kapsztad', 'lagos', 'dakar', 'tunis', 'algier', 'dubaj',
    'abu zabi', 'rijad', 'doha', 'teheran', 'bagdad', 'tel awiw', 'jerozolima', 'bejrut', 'amman',
    'stambuł', 'ankara', 'san jose', 'lima', 'montevideo', 'quito', 'addis abeba'
}

# Słownik odmian miast (miejscownik - "w Warszawie" i dopełniacz - "dla Warszawy")
CITY_FORMS = {
    # Polskie miasta (miejscownik)
    'zambrowie': 'zambrów',
    'warszawie': 'warszawa',
    'krakowie': 'kraków',
    'łodzi': 'łódź',
    'wrocławiu': 'wrocław',
    'poznaniu': 'poznań',
    'gdańsku': 'gdańsk',
    'szczecinie': 'szczecin',
    'bydgoszczy': 'bydgoszcz',
    'lublinie': 'lublin',
    'białymstoku': 'białystok',
    'katowicach': 'katowice',
    'gdyni': 'gdynia',
    'częstochowie': 'częstochowa',
    'radomiu': 'radom',
    'sosnowcu': 'sosnowiec',
    'toruniu': 'toruń',
    'kielcach': 'kielce',
    'rzeszowie': 'rzeszów',
    'gliwicach': 'gliwice',
    'zabrzu': 'zabrze',
    'olsztynie': 'olsztyn',
    'bytomiu': 'bytom',
    'zielonej górze': 'zielona góra',
    'rybniku': 'rybnik',
    'rudzie śląskiej': 'ruda śląska',
    'opolu': 'opole',
    'tychach': 'tychy',
    'płocku': 'płock',
    'elblągu': 'elbląg',
    'wałbrzychu': 'wałbrzych',
    'włocławku': 'włocławek',
    'tarnowie': 'tarnów',
    'chorzowie': 'chorzów',
    'koszalinie': 'koszalin',
    'kaliszu': 'kalisz',
    'legnicy': 'legnica',
    'grudziądzu': 'grudziądz',
    'jaworznie': 'jaworzno',
    'słupsku': 'słupsk',
    'jastrzębiu-zdroju': 'jastrzębie-zdrój',
    'nowym sączu': 'nowy sącz',
    'jeleniej górze': 'jelenia góra',
    'siedlcach': 'siedlce',
    'mysłowicach': 'mysłowice',
    'pile': 'piła',
    'lubinie': 'lubin',
    'ostrowie wielkopolskim': 'ostrów wielkopolski',
    'łomży': 'łomża',
    'zakopanem': 'zakopane',
    'sopocie': 'sopot',
    'kołobrzegu': 'kołobrzeg',
    'mielcu': 'mielec',
    'tarnobrzegu': 'tarnobrzeg',
    'przemyślu': 'przemyśl',
    'zamościu': 'zamość',
    'suwałkach': 'suwałki',
    'cieszynie': 'cieszyn',
    'gnieźnie': 'gniezno',
    'lesznie': 'leszno',
    'piotrkowie trybunalskim': 'piotrków trybunalski',
    'inowrocławiu': 'inowrocław',
    'krośnie': 'krosno',
    'puławach': 'puławy',
    'oświęcimiu': 'oświęcim',
    'białej podlaskiej': 'biała podlaska',
    'pruszkowie': 'pruszków',
    'mińsku mazowieckim': 'mińsk mazowiecki',
    'sanoku': 'sanok',
    'ustce': 'ustka',
    'tczewie': 'tczew',
    'mikołowie': 'mikołów',
    'kutnie': 'kutno',
    'głogowie': 'głogów',
    'żywcu': 'żywiec',
    'augustowie': 'augustów',
    'grodzisku mazowieckim': 'grodzisk mazowiecki',
    'bielsku podlaskim': 'bielsk podlaski',
    'chełmie': 'chełm',
    'bolesławcu': 'bolesławiec',
    'piasecznie': 'piaseczno',
    'ostrołęce': 'ostrołęka',
    'skierniewicach': 'skierniewice',
    'stargardzie': 'stargard',
    'wadowicach': 'wadowice',
    'nysie': 'nysa',
    'wejherowie': 'wejherowo',
    'rumi': 'rumia',
    'starachowicach': 'starachowice',
    'sochaczewie': 'sochaczew',
    'świnoujściu': 'świnoujście',
    'wodzisławiu śląskim': 'wodzisław śląski',
    'legionowie': 'legionowo',
    'świdnicy': 'świdnica',
    'ostrowcu świętokrzyskim': 'ostrowiec świętokrzyski',
    'zawierciu': 'zawiercie',
    'stalowej woli': 'stalowa wola',
    'brzegu': 'brzeg',

    # Zagraniczne miasta (miejscownik)
    'londynie': 'londyn',
    'paryżu': 'paryż',
    'rzymie': 'rzym',
    'berlinie': 'berlin',
    'madrycie': 'madryt',
    'barcelonie': 'barcelona',
    'amsterdamie': 'amsterdam',
    'pradze': 'praga',
    'wiedniu': 'wiedeń',
    'budapeszcie': 'budapeszt',
    'atenach': 'ateny',
    'lizbonie': 'lizbona',
    'dublinie': 'dublin',
    'kopenhadze': 'kopenhaga',
    'oslo': 'oslo',
    'sztokholmie': 'sztokholm',
    'helsinkach': 'helsinki',
    'moskwie': 'moskwa',
    'petersburgu': 'petersburg',
    'kijowie': 'kijów',
    'mińsku': 'mińsk',
    'rydze': 'ryga',
    'tallinie': 'tallin',
    'wilnie': 'wilno',
    'brukseli': 'bruksela',
    'genewie': 'genewa',
    'zurychu': 'zurych',
    'monachium': 'monachium',
    'hamburgu': 'hamburg',
    'frankfurcie': 'frankfurt',
    'stuttgarcie': 'stuttgart',
    'mediolanie': 'mediolan',
    'wenecji': 'wenecja',
    'florencji': 'florencja',
    'marsylii': 'marsylia',
    'lyonie': 'lyon',
    'tuluzie': 'tuluza',
    'nicei': 'nicea',
    'porto': 'porto',
    'walencji': 'walencja',
    'sewilli': 'sewilla',
    'palermo': 'palermo',
    'neapolu': 'neapol',
    'bukareszcie': 'bukareszt',
    'belgradzie': 'belgrad',
    'zagrzebiu': 'zagrzeb',
    'lublanie': 'lublana',
    'sarajewie': 'sarajewo',
    'sofii': 'sofia',
    'tiranie': 'tirana',
    'skopje': 'skopje',

    # Miasta światowe (miejscownik)
    'nowym jorku': 'nowy jork',
    'waszyngtonie': 'waszyngton',
    'chicago': 'chicago',
    'los angeles': 'los angeles',
    'houston': 'houston',
    'filadelfii': 'filadelfia',
    'bostonie': 'boston',
    'miami': 'miami',
    'las vegas': 'las vegas',
    'san francisco': 'san francisco',
    'atlancie': 'atlanta',
    'dallas': 'dallas',
    'detroit': 'detroit',
    'seattle': 'seattle',
    'denver': 'denver',
    'toronto': 'toronto',
    'montrealu': 'montreal',
    'vancouver': 'vancouver',
    'quebecu': 'quebec',
    'ottawie': 'ottawa',
    'meksyku': 'meksyk',
    'hawanie': 'hawana',
    'limie': 'lima',
    'santiago': 'santiago',
    'sao paulo': 'sao paulo',
    'buenos aires': 'buenos aires',
    'rio de janeiro': 'rio de janeiro',
    'bogocie': 'bogota',
    'caracas': 'caracas',
    'tokio': 'tokio',
    'pekinie': 'pekin',
    'szanghaju': 'szanghaj',
    'hong kongu': 'hong kong',
    'singapurze': 'singapur',
    'seulu': 'seul',
    'bangkoku': 'bangkok',
    'mumbaju': 'mumbaj',
    'delhi': 'delhi',
    'kalkucie': 'kalkuta',
    'dhace': 'dhaka',
    'dżakarcie': 'jakarta',
    'manili': 'manila',
    'hanoi': 'hanoi',
    'tajpej': 'tajpej',
    'kuala lumpur': 'kuala lumpur',
    'sydney': 'sydney',
    'melbourne': 'melbourne',
    'brisbane': 'brisbane',
    'auckland': 'auckland',
    'wellington': 'wellington',
    'kairze': 'kair',
    'casablance': 'casablanca',
    'nairobi': 'nairobi',
    'johannesburgu': 'johannesburg',
    'kapsztadzie': 'kapsztad',
    'lagos': 'lagos',
    'dakarze': 'dakar',
    'tunisie': 'tunis',
    'algierze': 'algier',
    'dubaju': 'dubaj',
    'abu zabi': 'abu zabi',
    'rijadzie': 'rijad',
    'dosze': 'doha',
    'teheranie': 'teheran',
    'bagdadzie': 'bagdad',
    'tel awiwie': 'tel awiw',
    'jerozolimie': 'jerozolima',
    'bejrucie': 'bejrut',
    'ammanie': 'amman',
    'stambule': 'stambuł',
    'ankarze': 'ankara',

    # Polskie miasta (dopełniacz)
    'warszawy': 'warszawa',
    'krakowa': 'kraków',
    'łodzi': 'łódź',
    'wrocławia': 'wrocław',
    'poznania': 'poznań',
    'gdańska': 'gdańsk',
    'szczecina': 'szczecin',
    'bydgoszczy': 'bydgoszcz',
    'lublina': 'lublin',
    'białegostoku': 'białystok',
    'katowic': 'katowice',
    'gdyni': 'gdynia',
    'częstochowy': 'częstochowa',
    'radomia': 'radom',
    'sosnowca': 'sosnowiec',
    'torunia': 'toruń',
    'kielc': 'kielce',
    'rzeszowa': 'rzeszów',
    'gliwic': 'gliwice',
    'zabrza': 'zabrze',
    'olsztyna': 'olsztyn',
    'bytomia': 'bytom',
    'zielonej góry': 'zielona góra',
    'rybnika': 'rybnik',
    'rudy śląskiej': 'ruda śląska',
    'opola': 'opole',
    'tychów': 'tychy',
    'płocka': 'płock',
    'elbląga': 'elbląg',
    'wałbrzycha': 'wałbrzych',
    'włocławka': 'włocławek',
    'tarnowa': 'tarnów',
    'chorzowa': 'chorzów',
    'koszalina': 'koszalin',
    'kalisza': 'kalisz',
    'legnicy': 'legnica',
    'grudziądza': 'grudziądz',
    'jaworzna': 'jaworzno',
    'słupska': 'słupsk',
    'jastrzębia-zdroju': 'jastrzębie-zdrój',
    'nowego sącza': 'nowy sącz',
    'jeleniej góry': 'jelenia góra',
    'siedlec': 'siedlce',
    'mysłowic': 'mysłowice',
    'piły': 'piła',
    'lubina': 'lubin',
    'ostrowa wielkopolskiego': 'ostrów wielkopolski',
    'łomży': 'łomża',
    'zakopanego': 'zakopane',
    'sopotu': 'sopot',
    'kołobrzegu': 'kołobrzeg',
    'mielca': 'mielec',
    'tarnobrzega': 'tarnobrzeg',
    'przemyśla': 'przemyśl',
    'zamościa': 'zamość',
    'suwałk': 'suwałki',

    # Zagraniczne miasta (dopełniacz)
    'londynu': 'londyn',
    'paryża': 'paryż',
    'rzymu': 'rzym',
    'berlina': 'berlin',
    'madrytu': 'madryt',
    'barcelony': 'barcelona',
    'amsterdamu': 'amsterdam',
    'pragi': 'praga',
    'wiednia': 'wiedeń',
    'budapesztu': 'budapeszt',
    'aten': 'ateny',
    'lizbony': 'lizbona',
    'dublina': 'dublin',
    'kopenhagi': 'kopenhaga',
    'oslo': 'oslo',
    'sztokholmu': 'sztokholm',
    'helsinek': 'helsinki',
    'moskwy': 'moskwa',
    'petersburga': 'petersburg',
    'kijowa': 'kijów',
    'mińska': 'mińsk',
    'rygi': 'ryga',
    'tallina': 'tallin',
    'wilna': 'wilno',
    'brukseli': 'bruksela',
    'genewy': 'genewa',
    'zurychu': 'zurych',
    'monachium': 'monachium',
    'hamburga': 'hamburg',
    'frankfurtu': 'frankfurt',
    'stuttgartu': 'stuttgart',
    'mediolanu': 'mediolan',
    'wenecji': 'wenecja',
    'florencji': 'florencja',

    # Miasta światowe (dopełniacz)
    'nowego jorku': 'nowy jork',
    'waszyngtonu': 'waszyngton',
    'chicago': 'chicago',
    'los angeles': 'los angeles',
    'houston': 'houston',
    'filadelfii': 'filadelfia',
    'bostonu': 'boston',
    'miami': 'miami',
    'las vegas': 'las vegas',
    'san francisco': 'san francisco',
    'atlanty': 'atlanta',
    'dallas': 'dallas',
    'detroit': 'detroit',
    'seattle': 'seattle',
    'denver': 'denver',
    'toronto': 'toronto',
    'montrealu': 'montreal',
    'vancouver': 'vancouver',
    'quebecu': 'quebec',
    'ottawy': 'ottawa',
    'meksyku': 'meksyk',
    'hawany': 'hawana',
    'limy': 'lima',
    'santiago': 'santiago',
    'sao paulo': 'sao paulo',
    'buenos aires': 'buenos aires',
    'rio de janeiro': 'rio de janeiro',
    'bogoty': 'bogota',
    'caracas': 'caracas',
    'tokio': 'tokio',
    'pekinu': 'pekin',
    'szanghaju': 'szanghaj',
    'hong kongu': 'hong kong',
    'singapuru': 'singapur',
    'seulu': 'seul',
    'bangkoku': 'bangkok',
    'mumbaju': 'mumbaj',
    'delhi': 'delhi',
    'kalkuty': 'kalkuta',
    'dhaki': 'dhaka',
    'dżakarty': 'jakarta',
    'manili': 'manila',
    'hanoi': 'hanoi',
    'tajpej': 'tajpej',
    'kuala lumpur': 'kuala lumpur',
    'sydney': 'sydney',
    'melbourne': 'melbourne',
    'brisbane': 'brisbane',
    'auckland': 'auckland',
    'wellington': 'wellington',
    'kairu': 'kair',
    'casablanki': 'casablanca',
    'nairobi': 'nairobi',
    'johannesburga': 'johannesburg',
    'kapsztadu': 'kapsztad',
    'lagos': 'lagos',
    'dakaru': 'dakar',
    'tunisu': 'tunis',
    'algieru': 'algier',
    'dubaju': 'dubaj',
    'abu zabi': 'abu zabi',
    'rijadu': 'rijad',
    'dohy': 'doha',
    'teheranu': 'teheran',
    'bagdadu': 'bagdad',
    'tel awiwu': 'tel awiw',
    'jerozolimy': 'jerozolima',
    'bejrutu': 'bejrut',
    'ammanu': 'amman',
    'stambułu': 'stambuł',
    'ankary': 'ankara'
}

# Lista słów zarezerwowanych, których nie należy interpretować jako nazw miast
# Language-specific keywords for weather queries
WEATHER_KEYWORDS = {
    "en": [
        # Weather-related terms
        "weather", "temperature", "forecast", "rain", "snow", "sunny", "cloudy",
        "storm", "precipitation", "humidity", "wind", "pressure", "climate", "fog",
        "mist", "drizzle", "shower", "thunderstorm", "heatwave", "blizzard", "frost",
        "cyclone", "hurricane", "tornado", "typhoon", "conditions", "atmosphere",
        "degree", "celsius", "fahrenheit", "cold", "hot", "warm", "chilly", "freezing",
        "cool", "mild", "hail", "sleet", "lightning", "thunder", "meteorology",

        # Question words and phrases
        "what", "how", "will", "is", "are", "was", "were", "would", "could", "should",
        "can", "may", "might", "shall", "must", "do", "does", "did", "has", "have",
        "had", "tell", "know", "think", "predict", "forecast", "expect", "anticipate",
        "wonder", "curious", "like", "want", "need", "require", "wish", "hope",

        # Time-related terms
        "today", "tomorrow", "yesterday", "now", "soon", "later", "morning", "afternoon",
        "evening", "night", "dawn", "dusk", "noon", "midnight", "weekend", "weekday",
        "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
        "week", "month", "year", "hour", "minute", "second", "day", "night", "daily",
        "weekly", "monthly", "annually", "hourly", "winter", "spring", "summer", "autumn",
        "fall", "season", "january", "february", "march", "april", "may", "june", "july",
        "august", "september", "october", "november", "december"
    ],
    "pl": [
        # Weather-related terms
        "pogoda", "temperatura", "prognoza", "deszcz", "śnieg", "słonecznie", "pochmurnie",
        "burza", "opady", "wilgotność", "wiatr", "ciśnienie", "klimat", "mgła", "mżawka",
        "deszczyk", "ulewa", "burza", "fala upałów", "zamieć", "mróz", "cyklon", "huragan",
        "tornado", "tajfun", "warunki", "atmosfera", "stopień", "celsjusz", "stopni", "zimno",
        "gorąco", "ciepło", "chłodno", "mroźnie", "grad", "błyskawica", "grzmot", "meteorologia",

        # Question words and phrases
        "co", "jak", "czy", "będzie", "jest", "był", "była", "było", "były", "byłby",
        "mógłby", "powinien", "może", "możliwe", "będzie", "musi", "robi", "zrobił", "ma",
        "miał", "powiedz",      "wiesz", "myślisz", "przewiduj", "prognozuj", "spodziewaj",
        "zastanawiam", "ciekawi", "lubię", "chcę", "potrzebuję", "wymagam", "życzę", "mam nadzieję",

        # Time-related terms
        "dzisiaj", "dziś", "jutro", "wczoraj", "teraz", "wkrótce", "później", "rano", "popołudnie",
        "wieczór", "noc", "świt", "zmierzch", "południe", "północ", "weekend", "dzień roboczy",
        "poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela",
        "tydzień", "miesiąc", "rok", "godzina", "minuta", "sekunda", "dzień", "noc", "dziennie",
        "tygodniowo", "miesięcznie", "rocznie", "co godzinę", "zima", "wiosna", "lato", "jesień",
        "pora roku", "styczeń", "luty", "marzec", "kwiecień", "maj", "czerwiec", "lipiec",
        "sierpień", "wrzesień", "październik", "listopad", "grudzień"
    ]
}


def detect_language(text):
    """
    Wykrywa język podanego tekstu.

    Args:
        text (str): Tekst do analizy

    Returns:
        str: Kod języka ('pl' dla polskiego, 'en' dla angielskiego, 'unknown' jeśli nie można określić)
    """
    if not text or len(text.strip()) < 2:
        return 'unknown'

    # Heurystyka oparta na obecności polskich znaków
    polish_chars = set('ąćęłńóśźżĄĆĘŁŃÓŚŹŻ')
    text_chars = set(text.lower())

    # Jeśli tekst zawiera polskie znaki diakrytyczne, uznajemy go za polski
    if polish_chars.intersection(text_chars):
        return 'pl'

    # Jeśli nie zawiera polskich znaków, sprawdzamy częstotliwość występowania charakterystycznych słów
    words = text.lower().split()

    # Charakterystyczne słowa polskie i angielskie
    polish_common_words = {'jest', 'nie', 'czy', 'jak', 'to', 'się', 'co', 'na', 'w', 'z', 'dla', 'przez', 'jaka'}
    english_common_words = {'is', 'the', 'a', 'an', 'in', 'on', 'at', 'and', 'or', 'for', 'with', 'by', 'what'}

    # Sprawdzenie obecności polskich słów
    has_polish_words = any(word in polish_common_words for word in words)

    # Jeśli zawiera polskie słowa, to język polski
    if has_polish_words:
        return 'pl'

    # W przeciwnym razie uznajemy, że język jest angielski
    return 'en'


def normalize_text(text: str) -> str:
    """
    Normalize text by removing Polish diacritical marks for better comparison.

    Args:
        text (str): Text to normalize

    Returns:
        str: Normalized text
    """
    return text.replace('ą', 'a').replace('ć', 'c').replace('ę', 'e').replace('ł', 'l') \
        .replace('ń', 'n').replace('ó', 'o').replace('ś', 's').replace('ź', 'z').replace('ż', 'z')


def clean_text(text):
    """
    Czyszczenie i normalizacja tekstu.

    Args:
        text (str): Tekst do przetworzenia

    Returns:
        str: Przetworzony tekst
    """
    # Konwersja na małe litery
    text = text.lower()

    # Usunięcie znaków interpunkcyjnych
    text = text.translate(str.maketrans('', '', string.punctuation))

    # Usunięcie zbędnych białych znaków
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def extract_city(text):
    """
    Wyodrębnij nazwę miasta z podanego tekstu.

    Args:
        text (str): Tekst wejściowy, np. "Jaka jest pogoda w Krakowie?"

    Returns:
        str: Nazwa miasta lub pusty string, jeśli nie znaleziono
    """
    print(f"Próba ekstrakcji miasta z: '{text}'")

    # Konwersja na małe litery
    text = text.lower()

    # Normalizacja tekstu do porównań
    text_normalized = normalize_text(text)

    # Usunięcie znaków interpunkcyjnych
    text_clean = text.translate(str.maketrans('', '', string.punctuation))
    text_normalized_clean = text_normalized.translate(str.maketrans('', '', string.punctuation))

    # 1. Sprawdź bezpośrednio wszystkie odmiany miast
    for city_form, city_base in CITY_FORMS.items():
        if city_form in text_clean:
            print(f"Znaleziono miasto w formie odmienionej: {city_form} -> {city_base.capitalize()}")
            return city_base.capitalize()

        # Sprawdź również znormalizowaną formę
        city_form_norm = normalize_text(city_form)
        if city_form_norm in text_normalized_clean:
            print(
                f"Znaleziono znormalizowane miasto w formie odmienionej: {city_form_norm} -> {city_base.capitalize()}")
            return city_base.capitalize()

    # 2. Sprawdź wszystkie podstawowe formy miast
    for city in POLISH_CITIES:
        if city in text_clean:
            print(f"Znaleziono miasto w formie podstawowej: {city.capitalize()}")
            return city.capitalize()

        # Sprawdź również znormalizowaną formę
        city_norm = normalize_text(city)
        if city_norm in text_normalized_clean:
            print(f"Znaleziono znormalizowane miasto w formie podstawowej: {city_norm} -> {city.capitalize()}")
            return city.capitalize()

    # 3. Sprawdź wzorce dla typowych zapytań o pogodę
    # Dodaj wzorce dla zapytań o prognozę
    city_patterns = [
        # Wzorce dla zapytań pogodowych
        r'pogoda\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'pogoda\s+(?:dla|w)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'temperatura\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)\s+(?:jest|jak|pada)',
        r'w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)\s+dzisiaj',

        # Wzorce dla zapytań o prognozę
        r'prognoza\s+(?:dla|w)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'prognoza\s+pogody\s+(?:dla|w)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:jutro|weekend|tydzień)\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:następne|przyszłe|kolejne)\s+dni\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'pogoda\s+na\s+(?:jutro|weekend|tydzień)\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'pogoda\s+(?:następne|przyszłe|kolejne)\s+dni\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:długoterminowa|długookresowa)\s+(?:dla|w)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'jak\s+będzie\s+w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)[?.]?$',
        r'w\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)'
    ]

    for pattern in city_patterns:
        match = re.search(pattern, text)
        if match:
            possible_city = match.group(1).lower()
            print(f"Pasujący wzorzec: {pattern}, możliwe miasto: {possible_city}")

            # Usuń znaki interpunkcyjne z możliwego miasta
            possible_city = possible_city.translate(str.maketrans('', '', string.punctuation))

            # Sprawdź czy to jedna z odmian miast
            if possible_city in CITY_FORMS:
                city_base = CITY_FORMS[possible_city]
                print(f"Znaleziono miasto w formie odmiany: {possible_city} -> {city_base.capitalize()}")
                return city_base.capitalize()

            # Sprawdź znormalizowaną formę
            possible_city_norm = normalize_text(possible_city)
            for city_form, city_base in CITY_FORMS.items():
                city_form_norm = normalize_text(city_form)
                if possible_city_norm == city_form_norm:
                    print(
                        f"Znaleziono znormalizowane miasto w formie odmiany: {possible_city_norm} -> {city_base.capitalize()}")
                    return city_base.capitalize()

            # Sprawdź czy to podstawowa forma miasta
            for city in POLISH_CITIES:
                if possible_city == city:
                    print(f"Znaleziono miasto w formie podstawowej: {city.capitalize()}")
                    return city.capitalize()

                # Sprawdź znormalizowaną formę
                city_norm = normalize_text(city)
                if possible_city_norm == city_norm:
                    print(
                        f"Znaleziono znormalizowane miasto w formie podstawowej: {possible_city_norm} -> {city.capitalize()}")
                    return city.capitalize()

    # 4. Sprawdź ostatnie słowo po "w" lub "dla"
    words = text_clean.split()
    for i, word in enumerate(words):
        if (word == 'w' or word == 'dla') and i + 1 < len(words):
            possible_city = words[i + 1]
            print(f"Możliwe miasto po '{word}': {possible_city}")

            # Sprawdź czy to jedna z odmian miast
            if possible_city in CITY_FORMS:
                city_base = CITY_FORMS[possible_city]
                print(f"Znaleziono miasto w formie odmiany: {possible_city} -> {city_base.capitalize()}")
                return city_base.capitalize()

            # Sprawdź znormalizowaną formę
            possible_city_norm = normalize_text(possible_city)
            for city_form, city_base in CITY_FORMS.items():
                city_form_norm = normalize_text(city_form)
                if possible_city_norm == city_form_norm:
                    print(
                        f"Znaleziono znormalizowane miasto w formie odmiany: {possible_city_norm} -> {city_base.capitalize()}")
                    return city_base.capitalize()

            # Sprawdź czy to podstawowa forma miasta
            for city in POLISH_CITIES:
                if possible_city == city:
                    print(f"Znaleziono miasto w formie podstawowej: {city.capitalize()}")
                    return city.capitalize()

                # Sprawdź znormalizowaną formę
                city_norm = normalize_text(city)
                if possible_city_norm == city_norm:
                    print(
                        f"Znaleziono znormalizowane miasto w formie podstawowej: {possible_city_norm} -> {city.capitalize()}")
                    return city.capitalize()

    # 5. Obsługa specyficznych przypadków
    if "warszaw" in text or "warsaw" in text:
        print("Wykryto domyślne miasto: Warszawa")
        return "Warszawa"

    # Jeśli nie znaleziono miasta, zwróć pusty string
    print("Nie wykryto miasta")
    return ""


def extract_city_improved(text):
    """
    Wyodrębnij nazwę miasta z podanego tekstu, ignorując słowa zarezerwowane.

    Args:
        text (str): Tekst wejściowy, np. "Jaka jest pogoda w Krakowie?"

    Returns:
        str: Nazwa miasta lub pusty string, jeśli nie znaleziono
    """
    print(f"Próba ekstrakcji miasta z: '{text}'")

    # Wynik standardowej funkcji ekstrakcji
    city = extract_city(text)

    # Sprawdź, czy znalezione miasto nie jest słowem zarezerwowanym
    language = detect_language(text)
    if city and city.lower() in WEATHER_KEYWORDS.get(language, []):
        print(f"Znalezione słowo '{city}' jest słowem zarezerwowanym, nie jest nazwą miasta")
        return ""

    return city


def extract_city_english(text: str) -> str:
    """
    Extract city name from English text.

    Args:
        text (str): English text

    Returns:
        str: Extracted city name or empty string
    """
    print(f"Attempting to extract city from English text: '{text}'")

    # Convert to lowercase
    text = text.lower()

    # Clean text by removing punctuation
    text_clean = text.translate(str.maketrans('', '', string.punctuation))

    # Normalize text to handle potential misspellings
    text_normalized = normalize_text(text_clean)

    # Special case for NY/New York
    if "ny" in text_clean.split() or "ny?" in text_clean:
        print(f"Found special city abbreviation: ny -> New York")
        return "New York"

    # Check for direct city names
    for city in ENGLISH_CITIES:
        if city in text_clean.split() or f"{city}?" in text_clean:
            print(f"Found city directly: {city.capitalize()}")
            return city.capitalize()

    # Check for special city forms
    for city_form, city_base in ENGLISH_CITY_FORMS.items():
        if city_form in text_clean.split() or f"{city_form}?" in text_clean:
            print(f"Found special city form: {city_form} -> {city_base.capitalize()}")
            return city_base.capitalize()

    # Check common English patterns for weather queries
    patterns = [
        r'(?:in|at|for)\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)(?:\?|\.|\s|$)',
        r'(?:weather|forecast|temperature)(?:\s+(?:in|at|for))?\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)(?:\?|\.|\s|$)',
        r'(?:how is|what\'s|what is)(?:\s+(?:the weather|it))(?:\s+(?:in|at))?\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)(?:\?|\.|\s|$)'
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            city_candidate = match.group(1).strip().lower()
            print(f"Pattern match: '{pattern}', city candidate: '{city_candidate}'")

            # Check if it's a known English city
            if city_candidate in ENGLISH_CITIES:
                print(f"Found city from pattern: {city_candidate.capitalize()}")
                return city_candidate.capitalize()

            # Check for NY abbreviation
            if city_candidate == "ny":
                print("Found NY abbreviation -> New York")
                return "New York"

    print("No city found in English text")
    return ""


def extract_city_multilingual(text: str, language: Optional[str] = None) -> str:
    """
    Extract city name with language detection.

    Args:
        text (str): Input text
        language (str, optional): Language code ('pl' or 'en')

    Returns:
        str: Extracted city name or empty string
    """
    # Detect language if not provided
    if language is None:
        language = detect_language(text)

    # Extract city based on language
    if language == 'en':
        return extract_city_english(text)
    else:
        return extract_city(text)  # Use the existing Polish extraction function


def extract_city_with_context(text: str, conversation_context: Optional[Dict] = None) -> str:
    """
    Extract city with context awareness.

    Args:
        text (str): Input text
        conversation_context (dict, optional): Conversation context with last_city

    Returns:
        str: Extracted city name or empty string
    """
    # First try to extract city directly
    city = extract_city_improved(text)

    if city:
        return city

    # If no city found and we have context, check for contextual references
    if conversation_context and conversation_context.get("last_city"):
        last_city = conversation_context["last_city"]

        # Look for contextual references
        context_phrases = [
            "a tam", "a teraz", "w tym mieście", "tam", "teraz",
            "a co", "a jak", "tam też", "ten sam", "to samo miejsce",
            "a jak tam", "a co tam", "a w", "jeszcze", "i jeszcze"
        ]

        if any(phrase in text.lower() for phrase in context_phrases):
            print(f"Detected contextual reference, using previous city: {last_city}")
            return last_city

        # If question is short, likely refers to the last city
        words = text.split()
        if len(words) <= 4:
            print(f"Short query without city, using context: {last_city}")
            return last_city

    return ""


def extract_city_with_context_improved(text: str, conversation_context: Optional[Dict] = None) -> str:
    """
    Enhanced city extraction with conversation context and language detection.

    Args:
        text (str): Input text
        conversation_context (dict, optional): Conversation context

    Returns:
        str: Extracted city name or empty string
    """
    # Get language from context or detect it
    if conversation_context is None:
        conversation_context = {}

    language = conversation_context.get("language")
    if language is None:
        from data_preparation import detect_language
        language = detect_language(text)
        conversation_context["language"] = language

    print(f"Używam języka: {language} dla ekstrakcji miasta z: '{text}'")

    # First try to extract city directly based on language
    if language == "en":
        city = extract_city_english(text)
    else:
        city = extract_city_improved(text)

    if city:
        return city

    # If no city found and we have context, check for contextual references
    if conversation_context and conversation_context.get("last_city"):
        last_city = conversation_context["last_city"]

        # Contextual phrases based on language
        if language == "en":
            context_phrases = [
                "there", "in that city", "in the same place", "in the same city",
                "how about there", "what about there", "there too", "that city",
                "the same", "same place", "same city", "in that place", "that location"
            ]
        else:
            context_phrases = [
                "a tam", "a teraz", "w tym mieście", "tam", "teraz",
                "a co", "a jak", "tam też", "ten sam", "to samo miejsce",
                "a jak tam", "a co tam", "a w", "jeszcze", "i jeszcze"
            ]

        # Check for contextual references
        if any(phrase in text.lower() for phrase in context_phrases):
            print(f"Detected contextual reference, using previous city: {last_city}")
            return last_city

        # If question is short, likely refers to the last city
        words = text.split()
        if len(words) <= 4:
            print(f"Short query without city, using context: {last_city}")
            return last_city

    return ""


def check_if_asking_about_city_list(text: str, city_list: List[str]) -> Optional[str]:
    """
    Check if text is asking about a specific city from a list.

    Args:
        text (str): Input text
        city_list (list): List of cities

    Returns:
        str or None: Selected city or None
    """
    if not city_list:
        return None

    text = text.lower()

    # Check directly if text contains one of the cities
    for city in city_list:
        if city.lower() in text:
            return city

    # Check patterns for selection
    choice_patterns = [
        r'chodzi\s+(?:mi)?\s+o\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'wybier(?:am|z)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:tak|chce|chcę|pokaż|pokaz|daj)\s+(?:dla|w)?\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:to|tak,?)?\s*(?:pierwsze|drugie|trzecie|czwarte|piąte|ostatnie)',
        r'(?:interesuje mnie|pytam o)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
        r'(?:pogoda|prognoza|temperatura)(?:\s+w)?\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)'
    ]

    for pattern in choice_patterns:
        match = re.search(pattern, text)
        if match and len(match.groups()) > 0:
            potential_city = match.group(1).lower() if len(match.groups()) > 0 else None

            if potential_city:
                for city in city_list:
                    if city.lower() in potential_city or potential_city in city.lower():
                        return city

    # Check ordinal selections
    if re.search(r'pierwsze(\s|$|\.|\?)', text):
        return city_list[0] if city_list else None
    elif re.search(r'drugie(\s|$|\.|\?)', text) and len(city_list) > 1:
        return city_list[1]
    elif re.search(r'trzecie(\s|$|\.|\?)', text) and len(city_list) > 2:
        return city_list[2]
    elif re.search(r'czwarte(\s|$|\.|\?)', text) and len(city_list) > 3:
        return city_list[3]
    elif re.search(r'piąte(\s|$|\.|\?)', text) and len(city_list) > 4:
        return city_list[4]
    elif re.search(r'ostatnie(\s|$|\.|\?)', text) and city_list:
        return city_list[-1]

    # Check affirmative answers (for first city)
    affirmative = [r'^tak$', r'^dobra$', r'^ok$', r'^okej$', r'^jasne$', r'^pewnie$']
    for pattern in affirmative:
        if re.search(pattern, text):
            return city_list[0] if city_list else None

    # Check number selections (1, 2, 3...)
    for i, city in enumerate(city_list, 1):
        if re.search(rf'(\s|^){i}(\s|$|\.|\?)', text):
            return city

    return None


def check_if_asking_about_city_list_multilingual(text: str, city_list: List[str], language: Optional[str] = None) -> Optional[str]:
    """
    Check if text is asking about a specific city from a list with language awareness.

    Args:
        text (str): Input text
        city_list (list): List of cities
        language (str, optional): Language code

    Returns:
        str or None: Selected city or None
    """
    if not city_list:
        return None

    # Detect language if not provided
    if language is None:
        language = detect_language(text)

    text = text.lower()

    # Check directly if text contains one of the cities
    for city in city_list:
        if city.lower() in text:
            return city

    # Check based on language
    if language == 'en':
        # English patterns for selection
        choice_patterns = [
            r'(?:i mean|i\'m asking about|talking about)\s+([a-zA-Z\s]+)',
            r'(?:choose|select|pick|yes for|looking for)\s+([a-zA-Z\s]+)',
            r'(?:yes|please|show|give me)(?:\s+(?:for|in))?\s+([a-zA-Z\s]+)',
            r'(?:the|yes,?)?\s*(?:first|second|third|fourth|fifth|last) one',
            r'(?:i want|interested in|asking about)\s+([a-zA-Z\s]+)',
            r'(?:weather|forecast|temperature)(?:\s+in)?\s+([a-zA-Z\s]+)'
        ]
    else:
        # Polish patterns for selection
        choice_patterns = [
            r'chodzi\s+(?:mi)?\s+o\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
            r'wybier(?:am|z)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
            r'(?:tak|chce|chcę|pokaż|pokaz|daj)\s+(?:dla|w)?\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
            r'(?:to|tak,?)?\s*(?:pierwsze|drugie|trzecie|czwarte|piąte|ostatnie)',
            r'(?:interesuje mnie|pytam o)\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)',
            r'(?:pogoda|prognoza|temperatura)(?:\s+w)?\s+([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]+)'
        ]

    for pattern in choice_patterns:
        match = re.search(pattern, text)
        if match and len(match.groups()) > 0:
            potential_city = match.group(1).lower() if len(match.groups()) > 0 else None

            if potential_city:
                for city in city_list:
                    if city.lower() in potential_city or potential_city in city.lower():
                        return city

    # Check ordinal selections
    if language == 'en':
        # English ordinals
        if re.search(r'first(\s|$|\.|\?)', text):
            return city_list[0] if city_list else None
        elif re.search(r'second(\s|$|\.|\?)', text) and len(city_list) > 1:
            return city_list[1]
        elif re.search(r'third(\s|$|\.|\?)', text) and len(city_list) > 2:
            return city_list[2]
        elif re.search(r'fourth(\s|$|\.|\?)', text) and len(city_list) > 3:
            return city_list[3]
        elif re.search(r'fifth(\s|$|\.|\?)', text) and len(city_list) > 4:
            return city_list[4]
        elif re.search(r'last(\s|$|\.|\?)', text) and city_list:
            return city_list[-1]
        # Number-based selection (1, 2, 3...)
        for i, city in enumerate(city_list, 1):
            if re.search(rf'(\s|^){i}(\s|$|\.|\?)', text):
                return city
    else:
        # Polish ordinals
        if re.search(r'pierwsze(\s|$|\.|\?)', text):
            return city_list[0] if city_list else None
        elif re.search(r'drugie(\s|$|\.|\?)', text) and len(city_list) > 1:
            return city_list[1]
        elif re.search(r'trzecie(\s|$|\.|\?)', text) and len(city_list) > 2:
            return city_list[2]
        elif re.search(r'czwarte(\s|$|\.|\?)', text) and len(city_list) > 3:
            return city_list[3]
        elif re.search(r'piąte(\s|$|\.|\?)', text) and len(city_list) > 4:
            return city_list[4]
        elif re.search(r'ostatnie(\s|$|\.|\?)', text) and city_list:
            return city_list[-1]
        # Number-based selection (1, 2, 3...)
        for i, city in enumerate(city_list, 1):
            if re.search(rf'(\s|^){i}(\s|$|\.|\?)', text):
                return city

    # Check affirmative answers (for first city)
    if language == 'en':
        # English affirmatives
        affirmation_patterns = [
            r'^yes$', r'^yeah$', r'^yep$', r'^ok$', r'^okay$', r'^sure$', r'^correct$',
            r'^yes\W', r'^yeah\W', r'^yep\W', r'^ok\W', r'^okay\W', r'^sure\W', r'^correct\W',
            r'^the first one$', r'^first$', r'^1$', r'^1\W'
        ]
    else:
        # Polish affirmatives
        affirmation_patterns = [
            r'^tak$', r'^dobra$', r'^ok$', r'^okej$', r'^jasne$', r'^pewnie$',
            r'^tak\W', r'^dobra\W', r'^ok\W', r'^okej\W', r'^jasne\W', r'^pewnie\W',
            r'^pierwsze$', r'^to pierwsze$', r'^1$', r'^1\W'
        ]

    for pattern in affirmation_patterns:
        if re.search(pattern, text):
            return city_list[0] if city_list else None

    return None


def add_city_to_database(city: str, lang: str = 'pl', city_form: Optional[str] = None) -> bool:
    """
    Add a new city to the appropriate database.

    Args:
        city (str): City name in base form
        lang (str): Language code ('en' or 'pl')
        city_form (str, optional): Alternative form of city name

    Returns:
        bool: True if city was added, False if it already existed
    """
    global POLISH_CITIES, ENGLISH_CITIES, CITY_FORMS, ENGLISH_CITY_FORMS

    # Convert to lowercase
    city_lower = city.lower()

    # Add to appropriate language set
    if lang == 'en':
        if city_lower in ENGLISH_CITIES:
            return False  # City already exists

        ENGLISH_CITIES.add(city_lower)
        print(f"Added new English city to database: {city}")

        # Add city form if provided
        if city_form:
            city_form_lower = city_form.lower()
            ENGLISH_CITY_FORMS[city_form_lower] = city_lower
            print(f"Added English city form: {city_form} -> {city}")
    else:
        if city_lower in POLISH_CITIES:
            return False  # City already exists

        POLISH_CITIES.add(city_lower)
        print(f"Added new Polish city to database: {city}")

        # Add city form if provided
        if city_form:
            city_form_lower = city_form.lower()
            CITY_FORMS[city_form_lower] = city_lower
            print(f"Added Polish city form: {city_form} -> {city}")

    return True


def find_possible_city_in_text(text: str, language: str = 'pl') -> Optional[str]:
    """
    Try to find a possible city name in text that's not in our database.

    Args:
        text (str): Input text
        language (str): Language code ('en' or 'pl')

    Returns:
        str or None: Potential city name or None
    """
    text_lower = text.lower()

    # Different patterns based on language
    if language == 'en':
        # Look for phrases like "in [Potential City]"
        prepositions = ['in', 'at', 'for', 'near']
        for prep in prepositions:
            pattern = rf'(?:\s|^){prep}\s+([A-Z][a-zA-Z]+)(?:\s|$|\?|\.)'
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                potential_city = match.group(1).strip()
                # Verify it's likely a city (capitalized, not a common word)
                if (len(potential_city) > 3 and
                        not potential_city.lower() in ENGLISH_CITIES and
                        not potential_city.lower() in WEATHER_KEYWORDS.get('en', [])):
                    print(f"Found potential new English city: {potential_city}")
                    return potential_city
    else:
        # Polish patterns (e.g., "w [Potential City]")
        prepositions = ['w', 'dla', 'z', 'do', 'koło']
        for prep in prepositions:
            pattern = rf'(?:\s|^){prep}\s+([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)(?:\s|$|\?|\.)'
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                potential_city = match.group(1).strip()
                # Verify it's likely a city (capitalized, not a common word)
                if (len(potential_city) > 3 and
                        not potential_city.lower() in POLISH_CITIES and
                        not potential_city.lower() in WEATHER_KEYWORDS.get('pl', [])):
                    print(f"Found potential new Polish city: {potential_city}")
                    return potential_city

    return None


def load_additional_cities(file_path: Optional[str] = None) -> int:
    """
    Load additional cities from JSON file.

    Args:
        file_path (str, optional): Path to JSON file with cities

    Returns:
        int: Number of cities added
    """
    # If no file specified, try default locations
    if not file_path:
        # Try common locations
        possible_paths = [
            "data/cities.json",
            "cities.json",
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "cities.json"),
            os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data/cities.json")
        ]

        for path in possible_paths:
            if os.path.exists(path):
                file_path = path
                break

    # If no file found or provided, return 0
    if not file_path or not os.path.exists(file_path):
        print("No additional cities file found.")
        return 0

    # Load cities from file
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            cities_data = json.load(f)

        count = 0

        # Add Polish cities
        if 'polish_cities' in cities_data:
            for city in cities_data['polish_cities']:
                if add_city_to_database(city, 'pl'):
                    count += 1

        # Add English cities
        if 'english_cities' in cities_data:
            for city in cities_data['english_cities']:
                if add_city_to_database(city, 'en'):
                    count += 1

        # Add Polish city forms
        if 'polish_city_forms' in cities_data:
            for form, base in cities_data['polish_city_forms'].items():
                if add_city_to_database(base, 'pl', form):
                    count += 1

        # Add English city forms
        if 'english_city_forms' in cities_data:
            for form, base in cities_data['english_city_forms'].items():
                if add_city_to_database(base, 'en', form):
                    count += 1

        print(f"Added {count} cities from {file_path}")
        return count

    except Exception as e:
        print(f"Error loading cities from file: {str(e)}")
        return 0


# Initialize by loading additional cities if available
try:
    load_additional_cities()
except Exception as e:
    print(f"Warning: Failed to load additional cities: {str(e)}")


# Test function for the module
if __name__ == "__main__":
    # Test examples for both languages
    test_phrases_en = [
        "What's the weather in London?",
        "Is it raining in New York today?",
        "Temperature in Paris",
        "Weather forecast for Tokyo",
        "Tell me about the weather in Berlin",
        "How's the weather in Rome?",
        "Will it snow in Moscow tomorrow?",
        "Sydney weather",
        "Is it sunny in Los Angeles?",
        "Madrid forecast"
    ]

    test_phrases_pl = [
        "Jaka jest pogoda w Warszawie?",
        "Czy pada deszcz w Krakowie",
        "Temperatura w Gdańsku",
        "Pogoda dla Poznania",
        "Ile stopni jest we Wrocławiu?",
        "Pokaż mi pogodę w Lublinie",
        "Czy w Białymstoku jest ładna pogoda?",
        "Warszawa pogoda",
        "Jaka pogoda w Warszawie?"
    ]

    print("=== Testing English Phrases ===")
    for phrase in test_phrases_en:
        city = extract_city_multilingual(phrase, 'en')
        print(f"Phrase: '{phrase}'")
        print(f"Detected city: '{city}'" if city else "No city detected")
        print("-" * 50)

    print("\n=== Testing Polish Phrases ===")
    for phrase in test_phrases_pl:
        city = extract_city_multilingual(phrase, 'pl')
        print(f"Phrase: '{phrase}'")
        print(f"Detected city: '{city}'" if city else "No city detected")
        print("-" * 50)
