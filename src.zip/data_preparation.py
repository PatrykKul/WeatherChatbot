import re
import os
import json
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from utils import get_resource_path
try:
    from langdetect import detect, LangDetectException
    LANGDETECT_AVAILABLE = True
except ImportError:
    LANGDETECT_AVAILABLE = False
    print("Ostrzeżenie: Biblioteka 'langdetect' nie jest zainstalowana. Używanie uproszczonego wykrywania języka.")



# Pobierz niezbędne zasoby NLTK
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')
    nltk.download('wordnet')
    nltk.download('omw-1.4')

# Inicjalizacja lematyzatora (z obsługą błędów)
try:
    lemmatizer = WordNetLemmatizer()
except:
    print("Ostrzeżenie: Nie można zainicjować lematyzatora.")


    # Stworzymy funkcję zastępczą dla lematyzatora
    class DummyLemmatizer:
        def lemmatize(self, word):
            return word


    lemmatizer = DummyLemmatizer()

# Lista polskich stop words
# NLTK nie zawiera polskich stopwords, więc definiujemy własne
try:
    polish_stop_words = set(stopwords.words('polish'))
except OSError:
    # Definicja podstawowych polskich "stop words"
    polish_stop_words = {
        'a', 'aby', 'ach', 'acz', 'aczkolwiek', 'aj', 'albo', 'ale', 'ależ', 'ani', 'aż', 'bardziej', 'bardzo', 'bez',
        'bo',
        'bowiem', 'by', 'byli', 'bym', 'bynajmniej', 'być', 'był', 'była', 'było', 'były', 'będzie', 'będą', 'cali',
        'cała',
        'cały', 'ci', 'cię', 'ciebie', 'co', 'cokolwiek', 'coś', 'czasami', 'czasem', 'czemu', 'czy', 'czyli', 'daleko',
        'dla', 'dlaczego', 'dlatego', 'do', 'dobrze', 'dokąd', 'dość', 'dużo', 'dwa', 'dwaj', 'dwie', 'dwoje', 'dziś',
        'dzisiaj', 'gdy', 'gdyby', 'gdyż', 'gdzie', 'gdziekolwiek', 'gdzieś', 'go', 'i', 'ich', 'ile', 'im', 'inna',
        'inne',
        'inny', 'innych', 'iż', 'ja', 'ją', 'jak', 'jakaś', 'jakby', 'jaki', 'jakichś', 'jakie', 'jakiś', 'jakiż',
        'jakkolwiek',
        'jako', 'jakoś', 'je', 'jeden', 'jedna', 'jedno', 'jednak', 'jednakże', 'jego', 'jej', 'jemu', 'jest', 'jestem',
        'jeszcze', 'jeśli', 'jeżeli', 'już', 'ją', 'każdy', 'kiedy', 'kilka', 'kimś', 'kto', 'ktokolwiek', 'ktoś',
        'która',
        'które', 'którego', 'której', 'który', 'których', 'którym', 'którzy', 'ku', 'lat', 'lecz', 'lub', 'ma', 'mają',
        'mam', 'mi', 'mimo', 'między', 'mną', 'mnie', 'mogą', 'moim', 'moja', 'moje', 'może', 'możliwe', 'można', 'mu',
        'musi', 'my', 'na', 'nad', 'nam', 'nami', 'nas', 'nasi', 'nasz', 'nasza', 'nasze', 'naszego', 'naszych',
        'natomiast',
        'natychmiast', 'nawet', 'nic', 'nich', 'nie', 'niech', 'niego', 'niej', 'niemu', 'nigdy', 'nim', 'nimi', 'niż',
        'no',
        'o', 'obok', 'od', 'około', 'on', 'ona', 'one', 'oni', 'ono', 'oraz', 'oto', 'owszem', 'pan', 'pana', 'pani',
        'po',
        'pod', 'podczas', 'pomimo', 'ponad', 'ponieważ', 'powinien', 'powinna', 'powinni', 'powinno', 'poza', 'prawie',
        'przecież', 'przed', 'przede', 'przedtem', 'przez', 'przy', 'roku', 'również', 'sam', 'sama', 'są', 'się',
        'skąd',
        'sobie', 'sobą', 'sposób', 'swoje', 'ta', 'tak', 'taka', 'taki', 'takie', 'także', 'tam', 'te', 'tego', 'tej',
        'ten',
        'teraz', 'też', 'to', 'tobą', 'tobie', 'toteż', 'trzeba', 'tu', 'twoim', 'twoja', 'twoje', 'twym', 'ty', 'tych',
        'tylko', 'tym', 'u', 'w', 'wam', 'wami', 'was', 'wasz', 'wasza', 'wasze', 'we', 'według', 'wiele', 'wielu', 'więc',
        'więcej', 'wszyscy', 'wszystkich', 'wszystkie', 'wszystkim', 'wszystko', 'wtedy', 'wy', 'właśnie', 'z', 'za',
        'zapewne', 'zawsze', 'ze', 'znowu', 'znów', 'został', 'żaden', 'żadna', 'żadne', 'żadnych', 'że', 'żeby',
        'zamiast', 'odnośnie', 'względem', 'wobec', 'wskutek', 'poprzez', 'spośród', 'wewnątrz',
        'pomiędzy', 'naprzeciwko', 'naprzeciw', 'wzdłuż', 'dookoła', 'naokoło', 'niektóre', 'wszelkie',
        'niektórzy', 'żadnego', 'wszyscy', 'każdego', 'dawno', 'kiedyś', 'dawniej', 'gdzieniegdzie',
        'dokądś', 'stąd', 'stamtąd', 'przeważnie', 'zazwyczaj', 'zwykle', 'jakiś', 'jakieś', 'jakiegoś',
        'któryś', 'zrób', 'zrob', 'podaj', 'zobaczmy', 'równie', 'równy', 'tyle', 'taki', 'tacy', 'takie',
        'odpowiedni', 'stąd', 'tamtędy', 'tędy', 'odtąd', 'dotąd', 'swój', 'swoich', 'swoim', 'swego',
        'swojego', 'kiedy', 'kto', 'coś', 'cos', 'ktoś', 'ktos', 'gdzie', 'dokąd', 'czym', 'czego',
        'choć', 'choc', 'chociaz', 'chociaż', 'kilka', 'kilku', 'kilkoma', 'kilkoro', 'parę', 'pare',
        'paru', 'nieco', 'trochę', 'troche', 'dużo', 'duzo', 'wiele', 'wielu', 'najbardziej', 'prawie',
        'niemal', 'omal', 'wcale', 'zupełnie', 'dosyć', 'dosyc', 'dość', 'dosc', 'całkiem', 'calkiem',
        'naprawdę', 'naprawde', 'właśnie', 'wlasnie', 'dopiero', 'bodaj', 'niech', 'oby', 'aby', 'gdyby',
        'jakby', 'jakoby', 'gdzieś', 'gdzies', 'chyba', 'może', 'moze', 'ogólnie', 'ogolnie', 'szczególnie',
        'szczegolnie', 'głównie', 'glownie', 'zwłaszcza', 'zwlaszcza', 'jedynie', 'dopóki', 'dopoki', 'póki',
        'poki', 'póty', 'poty', 'raczej', 'właściwie', 'wlasciwie', 'oto', 'tymczasem', 'stale', 'ciągle',
        'ciagle', 'wciąż', 'wciaz', 'nadal', 'dotychczas', 'uprzednio', 'niedawno', 'ostatnio', 'przedtem',
        'najpierw', 'naprzód', 'naprzod', 'wpierw', 'zatem', 'więc', 'wiec', 'wobec', 'wobec tego',
        'skutkiem tego', 'wskutek tego', 'dalej', 'potem', 'następnie', 'nastepnie', 'ponadto', 'prócz tego',
        'procz tego', 'przy tym', 'jednocześnie', 'jednoczesnie', 'równocześnie', 'rownoczesnie', 'niemniej', 'jednak'
    }

    english_stop_words ={'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are',
        'aren\'t', 'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both',
        'but', 'by', 'cannot', 'could', 'couldn\'t', 'did', 'didn\'t', 'does', 'doesn\'t', 'doing',
        'down', 'during', 'each', 'few', 'for', 'from', 'further', 'had', 'hadn\'t', 'has', 'hasn\'t',
        'having', 'he', 'he\'d', 'he\'ll', 'he\'s', 'her', 'here', 'here\'s', 'hers', 'herself', 'him',
        'himself', 'his', 'how', 'how\'s', 'if', 'in', 'into', 'is', 'isn\'t', 'it', 'it\'s', 'its',
        'itself', 'let\'s', 'me', 'more', 'most', 'mustn\'t', 'my', 'myself', 'no', 'nor', 'not', 'of',
        'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours', 'ourselves', 'out', 'over',
        'own', 'same', 'shan\'t', 'she', 'she\'d', 'she\'ll', 'she\'s', 'should', 'shouldn\'t', 'so',
        'some', 'such', 'than', 'that', 'that\'s', 'the', 'their', 'theirs', 'them', 'themselves',
        'then', 'there', 'there\'s', 'these', 'they', 'they\'d', 'they\'ll', 'they\'re', 'they\'ve',
        'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', 'wasn\'t',
        'were', 'weren\'t', 'what', 'what\'s', 'when', 'when\'s', 'where', 'where\'s', 'which', 'while',
        'who', 'who\'s', 'whom', 'why', 'why\'s', 'with', 'won\'t', 'would', 'wouldn\'t', 'yours',
        'yourself', 'yourselves', 'anyway', 'anywhere', 'anyhow', 'anytime', 'well', 'sometimes',
        'perhaps', 'possibly', 'probably', 'definitely', 'certainly', 'surely', 'indeed', 'ever',
        'usually', 'normally', 'generally', 'frequently', 'rarely', 'seldom', 'everywhere', 'nowhere',
        'somewhere', 'anyplace', 'inside', 'outside', 'ahead', 'behind', 'above', 'below', 'beneath',
        'beside', 'near', 'far', 'close', 'away', 'within', 'without', 'across', 'along', 'around',
        'throughout', 'towards', 'toward', 'onto', 'just', 'much', 'many', 'several', 'etc', 'almost',
        'nearly', 'quite', 'rather', 'somewhat', 'either', 'neither', 'whether', 'though', 'although',
        'even', 'whatever', 'whoever', 'whenever', 'wherever', 'however', 'whichever', 'moreover',
        'nevertheless', 'furthermore', 'meanwhile', 'hence', 'therefore', 'thus', 'consequently',
        'otherwise', 'still', 'yet'
    }


def detect_language(text):
    """
    Wykrywa język podanego tekstu.

    Args:
        text (str): Tekst do analizy

    Returns:
        str: Kod języka ('pl' dla polskiego, 'en' dla angielskiego, 'unknown' jeśli nie można określić)
    """
    if not text or len(text.strip()) < 2:
        return 'unknown'

    # Przygotuj tekst do analizy
    text_lower = text.lower().strip()

    # Lista polskich powitań/pożegnań, które często nie zawierają znaków diakrytycznych
    polish_greetings = {
        'witaj', 'siema', 'elo', 'hej', 'czesc', 'witam', 'dzien dobry', 'dobry wieczor',
        'joł', 'elka', 'hejka', 'hejo', 'cze', 'siemka', 'siemano', 'witajcie',
        'serwus', 'uszanowanko', 'powitanie', 'dzień doberek', 'nara', 'narazie', 'pa',
        'do widzenia', 'zegnaj', 'papa'
    }

    # Szybki test dla typowych polskich powitań
    if text_lower in polish_greetings or any(word in polish_greetings for word in text_lower.split()):
        return 'pl'

    # Jeśli dostępna jest biblioteka langdetect, używamy jej
    if LANGDETECT_AVAILABLE:
        try:
            # Dla dłuższych tekstów langdetect jest bardziej wiarygodny
            if len(text) > 10:
                detected = detect(text)
                # Sprawdzamy tylko polskie i angielskie (dla innych zwracamy angielski jako domyślny)
                if detected == 'pl':
                    return 'pl'
                else:
                    return 'en'  # Domyślnie angielski dla innych języków
        except LangDetectException:
            # W przypadku błędu wykrywania, używamy heurystyki
            pass

    # Heurystyka oparta na obecności polskich znaków
    polish_chars = set('ąćęłńóśźżĄĆĘŁŃÓŚŹŻ')
    text_chars = set(text.lower())

    # Jeśli tekst zawiera polskie znaki diakrytyczne, uznajemy go za polski
    if polish_chars.intersection(text_chars):
        return 'pl'

    # Jeśli nie zawiera polskich znaków, sprawdzamy częstotliwość występowania charakterystycznych słów
    words = text.lower().split()

    polish_common_phrases = {
        # greetings
        'witaj', 'siema', 'elo', 'hej', 'czesc', 'witam', 'dzien dobry', 'dobry wieczor',
        'joł', 'elka', 'hejka', 'hejo', 'cze', 'siemka', 'siemano', 'witajcie',
        'serwus', 'uszanowanko', 'powitanie', 'dzień doberek',
        # farewells
        'nara', 'narazie', 'pa', 'do widzenia', 'zegnaj', 'papa',
        # thanks
        'dzieki', 'dziekuje', 'dziekuję', 'dzieki wielkie', 'dziekuje bardzo',
        'dziex', 'dziena', 'dzk', 'dzięks', 'dziękóweczka', 'dziena'
    }

    # Szybki test dla typowych polskich wyrażeń
    if text_lower in polish_common_phrases or any(word in polish_common_phrases for word in text_lower.split()):
        return 'pl'

    # Charakterystyczne słowa polskie i angielskie (rozszerzona lista)
    polish_common_words = {
        'jest', 'nie', 'czy', 'jak', 'to', 'się', 'co', 'na', 'w', 'z', 'dla', 'przez',
        'jestem', 'mam', 'chcę', 'mogę', 'będę', 'ale', 'lub', 'gdzie', 'kiedy', 'teraz',
        'jutro', 'dzisiaj', 'dziś', 'wczoraj', 'proszę', 'dziękuję', 'przepraszam'
    }

    english_common_words = {
        'is', 'the', 'a', 'an', 'in', 'on', 'at', 'and', 'or', 'for', 'with', 'by',
        'i', 'you', 'he', 'she', 'it', 'we', 'they', 'this', 'that', 'what', 'where',
        'when', 'why', 'how', 'yes', 'no', 'please', 'thank', 'sorry'
    }

    # Liczenie wystąpień charakterystycznych słów
    polish_count = sum(1 for word in words if word in polish_common_words)
    english_count = sum(1 for word in words if word in english_common_words)

    # Decyzja na podstawie częstotliwości
    if polish_count > english_count:
        return 'pl'
    elif english_count > polish_count:
        return 'en'
    else:
        # Dla intencji powitania, które mogą zawierać izolowane krótkie słowa,
        # możemy sprawdzić, czy tekst zawiera polskie znaki w całej wiadomości
        if any(char in 'ąćęłńóśźżĄĆĘŁŃÓŚŹŻ' for char in text):
            return 'pl'

        # Jeśli nie ma znaczącej różnicy i nie ma żadnych innych wskazówek,
        # domyślnie angielski
        return 'en'

def get_stop_words(language):
    """
    Zwraca listę stop words dla określonego języka.

    Args:
        language (str): Kod języka ('pl' lub 'en')

    Returns:
        set: Zbiór stop words dla danego języka
    """
    if language == 'pl':
        return polish_stop_words
    elif language == 'en':
        return english_stop_words
    else:
        # Domyślnie zwracamy polskie stop words
        return polish_stop_words


def clean_text(text):
    """
    Czyszczenie i normalizacja tekstu.

    Args:
        text (str): Tekst do przetworzenia

    Returns:
        str: Przetworzony tekst
    """
    # Konwersja na małe litery
    text = text.lower()

    # Usunięcie znaków interpunkcyjnych
    text = text.translate(str.maketrans('', '', string.punctuation))

    # Usunięcie zbędnych białych znaków
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def tokenize_and_lemmatize(text, language=None):
    """
    Tokenizacja i lematyzacja tekstu z uwzględnieniem języka.

    Args:
        text (str): Tekst do przetworzenia
        language (str, optional): Kod języka ('pl' lub 'en').
                                 Jeśli None, język zostanie wykryty automatycznie.

    Returns:
        list: Lista tokenów po lematyzacji i usunięciu stop words
    """
    # Jeśli język nie został określony, wykrywamy go
    if language is None:
        language = detect_language(text)

    # Pobranie odpowiednich stop words dla danego języka
    stop_words = get_stop_words(language)

    # Prosta tokenizacja przez podział na spacje
    words = text.split()

    # Usunięcie stop words
    words = [word for word in words if word.lower() not in stop_words]

    # Próba lematyzacji, jeśli nie działa, pozostawiamy tokeny bez zmian
    try:
        # W przyszłości można dodać różne lematyzatory dla różnych języków
        words = [lemmatizer.lemmatize(word) for word in words]
    except Exception as e:
        print(f"Ostrzeżenie: Nie można wykonać lematyzacji: {str(e)}")

    return words


def prepare_training_data(file_path=None, include_languages=None):
    """
    Przygotowanie danych treningowych dla modelu z uwzględnieniem języków.

    Args:
        file_path (str): Ścieżka do pliku JSON z intencjami
        include_languages (list): Lista języków do uwzględnienia ['pl', 'en'], domyślnie wszystkie

    Returns:
        tuple: (documents, classes, words) gdzie:
            - documents: lista par (tokenizowany_wzorzec, tag)
            - classes: lista unikalnych tagów intencji
            - words: lista wszystkich unikalnych słów w zbiorze danych
    """
    if file_path is None:
        file_path = get_resource_path('data/intents.json')

    # Ustaw domyślnie wszystkie języki, jeśli nie podano
    if include_languages is None:
        include_languages = ['pl', 'en']

    # Sprawdź, czy plik istnieje
    if not os.path.exists(file_path):
        print(f"UWAGA: Nie znaleziono pliku pod ścieżką: {file_path}")
        # Dalsze sprawdzanie alternatywnych ścieżek...

    # Wczytanie pliku JSON
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            intents = json.load(file)
    except Exception as e:
        print(f"Błąd wczytywania pliku JSON: {str(e)}")
        raise

    words = []
    classes = []
    documents = []

    # Przetwarzanie wzorców dla każdej intencji
    for intent in intents['intents']:
        tag = intent['tag']

        # Dodanie tagu do listy klas (jeśli jeszcze nie istnieje)
        if tag not in classes:
            classes.append(tag)

        # Przetwarzanie wzorców polskich
        if 'pl' in include_languages and 'patterns' in intent:
            for pattern in intent['patterns']:
                # Czyszczenie tekstu
                clean_pattern = clean_text(pattern)

                # Tokenizacja i lematyzacja
                tokens = tokenize_and_lemmatize(clean_pattern, 'pl')

                # Dodanie tokenów do listy słów
                words.extend(tokens)

                # Dodanie dokumentu do listy
                documents.append((tokens, tag))

        # Przetwarzanie wzorców angielskich
        if 'en' in include_languages and 'patterns_en' in intent:
            for pattern in intent['patterns_en']:
                # Czyszczenie tekstu
                clean_pattern = clean_text(pattern)

                # Tokenizacja i lematyzacja
                tokens = tokenize_and_lemmatize(clean_pattern, 'en')

                # Dodanie tokenów do listy słów
                words.extend(tokens)

                # Dodanie dokumentu do listy
                documents.append((tokens, tag))

    # Usunięcie duplikatów i sortowanie
    words = sorted(list(set(words)))
    classes = sorted(classes)

    return documents, classes, words


if __name__ == "__main__":
    # Test modułu
    documents, classes, words = prepare_training_data()
    print(f"Liczba dokumentów: {len(documents)}")
    print(f"Liczba klas: {len(classes)}")
    print(f"Liczba unikalnych słów: {len(words)}")
    print(f"Przykładowy dokument: {documents[0]}")