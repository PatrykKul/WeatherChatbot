import sys
import requests
import math
import random
from datetime import datetime, timedelta
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QLineEdit, QPushButton,
                             QVBoxLayout, QHBoxLayout, QGridLayout, QSizePolicy,
                             QTabWidget, QFrame, QComboBox, QSlider, QScrollArea)
from PyQt5.QtCore import Qt, QTimer, QPoint, QPropertyAnimation, QEasingCurve, QSize, QRect, pyqtProperty
from PyQt5.QtGui import (QIcon, QPixmap, QColor, QPainter, QBrush, QConicalGradient,
                         QRadialGradient, QLinearGradient, QPen, QFont, QPainterPath,
                         QFontDatabase)
import pyqtgraph as pg
import numpy as np
from PyQt5.QtCore import QRectF


class ParticleSystem:
    def __init__(self, parent_width, parent_height, particle_type="stars"):
        self.parent_width = parent_width
        self.parent_height = parent_height
        self.particle_type = particle_type
        self.particles = []
        self.init_particles()

    def init_particles(self):
        if self.particle_type == "stars":
            self.particles = [
                {
                    'x': random.randint(0, self.parent_width),
                    'y': random.randint(0, self.parent_height),
                    'size': random.uniform(0.5, 2.5),
                    'brightness': random.uniform(0.1, 0.9),
                    'twinkle_speed': random.uniform(0.01, 0.05)
                } for _ in range(300)
            ]
        elif self.particle_type == "rain":
            self.particles = [
                {
                    'x': random.randint(0, self.parent_width),
                    'y': random.randint(-100, self.parent_height),
                    'speed': random.uniform(5, 15),
                    'length': random.uniform(10, 30),
                    'width': random.uniform(1, 2)
                } for _ in range(100)
            ]
        elif self.particle_type == "snow":
            self.particles = [
                {
                    'x': random.randint(0, self.parent_width),
                    'y': random.randint(-50, self.parent_height),
                    'size': random.uniform(2, 6),
                    'speed': random.uniform(1, 3),
                    'sway': random.uniform(-1, 1),
                    'sway_speed': random.uniform(0.01, 0.03)
                } for _ in range(80)
            ]
        elif self.particle_type == "clouds":
            self.particles = [
                {
                    'x': random.randint(-200, self.parent_width),
                    'y': random.randint(0, int(self.parent_height * 0.5)),
                    'width': random.uniform(100, 300),
                    'height': random.uniform(50, 100),
                    'speed': random.uniform(0.2, 0.7),
                    'opacity': random.uniform(0.1, 0.4)
                } for _ in range(8)
            ]
        elif self.particle_type == "thunder":
            self.particles = [
                {
                    'x': random.randint(0, self.parent_width),
                    'y': random.randint(0, int(self.parent_height * 0.3)),
                    'length': random.uniform(50, 200),
                    'width': random.uniform(2, 4),
                    'segments': random.randint(3, 7),
                    'lifetime': 0,
                    'max_lifetime': random.randint(5, 10),
                    'active': False,
                    'activation_chance': 0.005
                } for _ in range(5)
            ]

    def update(self, phase=0):
        if self.particle_type == "stars":
            for p in self.particles:
                p['current_brightness'] = p['brightness'] * (0.5 + 0.5 * math.sin(phase * p['twinkle_speed'] * 10))

        elif self.particle_type == "rain":
            for p in self.particles:
                p['y'] += p['speed']
                if p['y'] > self.parent_height:
                    p['y'] = random.randint(-100, -10)
                    p['x'] = random.randint(0, self.parent_width)

        elif self.particle_type == "snow":
            for p in self.particles:
                p['y'] += p['speed']
                p['x'] += math.sin(phase * p['sway_speed']) * p['sway']
                if p['y'] > self.parent_height:
                    p['y'] = random.randint(-50, -10)
                    p['x'] = random.randint(0, self.parent_width)

        elif self.particle_type == "clouds":
            for p in self.particles:
                p['x'] += p['speed']
                if p['x'] > self.parent_width + 200:
                    p['x'] = -200 - p['width']
                    p['y'] = random.randint(0, int(self.parent_height * 0.5))

        elif self.particle_type == "thunder":
            for p in self.particles:
                if p['active']:
                    p['lifetime'] += 1
                    if p['lifetime'] > p['max_lifetime']:
                        p['active'] = False
                        p['lifetime'] = 0
                else:
                    if random.random() < p['activation_chance']:
                        p['active'] = True
                        p['x'] = random.randint(0, self.parent_width)

    def render(self, painter):
        if self.particle_type == "stars":
            for p in self.particles:
                brightness = getattr(p, 'current_brightness', p['brightness'])
                alpha = min(255, int(220 * brightness))
                painter.setBrush(QColor(255, 255, 255, alpha))
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(QPoint(int(p['x']), int(p['y'])),
                                    int(p['size']), int(p['size']))

        elif self.particle_type == "rain":
            painter.setPen(QPen(QColor(120, 190, 255, 180), 1))
            for p in self.particles:
                painter.drawLine(int(p['x']), int(p['y']),
                                 int(p['x']), int(p['y'] + p['length']))

        elif self.particle_type == "snow":
            for p in self.particles:
                painter.setBrush(QColor(255, 255, 255, 200))
                painter.setPen(QPen(QColor(255, 255, 255, 150), 0.5))
                painter.drawEllipse(QPoint(int(p['x']), int(p['y'])),
                                    int(p['size']), int(p['size']))

        elif self.particle_type == "clouds":
            for p in self.particles:
                path = QPainterPath()
                # Rysuj chmurę jako serię połączonych okręgów
                centerX = p['x'] + p['width'] / 2
                baseY = p['y'] + p['height'] / 2

                # Seria elips tworząca chmurę
                cloud_parts = [
                    (centerX - p['width'] * 0.3, baseY, p['width'] * 0.4, p['height'] * 0.6),
                    (centerX, baseY - p['height'] * 0.1, p['width'] * 0.5, p['height'] * 0.7),
                    (centerX + p['width'] * 0.3, baseY, p['width'] * 0.4, p['height'] * 0.6),
                    (centerX - p['width'] * 0.15, baseY + p['height'] * 0.1, p['width'] * 0.3, p['height'] * 0.5),
                    (centerX + p['width'] * 0.15, baseY + p['height'] * 0.1, p['width'] * 0.3, p['height'] * 0.5)
                ]

                for cx, cy, w, h in cloud_parts:
                    ellipse_rect = QRectF(int(cx - w / 2), int(cy - h / 2), int(w), int(h))
                    path.addEllipse(ellipse_rect)

                # Wypełnij chmurę kolorem
                painter.setPen(Qt.NoPen)
                cloud_color = QColor(255, 255, 255, int(255 * p['opacity']))
                painter.setBrush(QBrush(cloud_color))
                painter.drawPath(path)

        elif self.particle_type == "thunder":
            for p in self.particles:
                if p['active']:
                    # Wartość alpha bazująca na czasie życia błyskawicy
                    life_ratio = 1.0 - (p['lifetime'] / p['max_lifetime'])
                    alpha = int(255 * life_ratio)

                    # Kolor błyskawicy z pulsującą jasnością
                    thunder_color = QColor(255, 255, 100, alpha)
                    glow_color = QColor(255, 255, 200, int(alpha * 0.7))

                    path = QPainterPath()

                    # Punkt początkowy
                    start_x = p['x']
                    start_y = p['y']
                    path.moveTo(start_x, start_y)

                    # Generowanie losowych segmentów błyskawicy
                    for i in range(p['segments']):
                        # Każdy segment odchyla się losowo
                        angle = random.uniform(-60, 60)
                        segment_length = p['length'] / p['segments']

                        # Obliczanie końca segmentu
                        end_x = start_x + math.sin(math.radians(angle)) * segment_length
                        end_y = start_y + math.cos(math.radians(angle)) * segment_length

                        # Dodanie segmentu do ścieżki
                        path.lineTo(end_x, end_y)

                        # Dodanie małego rozgałęzienia
                        if random.random() < 0.4:  # 40% szans na rozgałęzienie
                            branch_angle = angle + random.uniform(-45, 45)
                            branch_length = segment_length * random.uniform(0.3, 0.7)
                            branch_x = start_x + math.sin(math.radians(branch_angle)) * branch_length
                            branch_y = start_y + math.cos(math.radians(branch_angle)) * branch_length

                            path.moveTo(start_x, start_y)  # Powrót do początku segmentu
                            path.lineTo(branch_x, branch_y)  # Narysowanie rozgałęzienia
                            path.moveTo(end_x, end_y)  # Powrót do końca głównego segmentu

                        # Przesunięcie do następnego segmentu
                        start_x = end_x
                        start_y = end_y

                    # Rysowanie poświaty
                    painter.setPen(QPen(glow_color, p['width'] + 2))
                    painter.drawPath(path)

                    # Rysowanie głównej błyskawicy
                    painter.setPen(QPen(thunder_color, p['width']))
                    painter.drawPath(path)


class AnimatedButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self._hover_opacity = 0.0
        self._angle = 0.0

        self.anim = QPropertyAnimation(self, b"hover_opacity")
        self.anim.setDuration(300)
        self.gradient_timer = QTimer(self)
        self.gradient_timer.timeout.connect(self.update_gradient)
        self.gradient_timer.start(50)

        self.setMinimumHeight(50)
        self.setCursor(Qt.PointingHandCursor)

    def update_gradient(self):
        self._angle = (self._angle + 2) % 360
        self.update()

    def get_hover_opacity(self):
        return self._hover_opacity

    def set_hover_opacity(self, opacity):
        self._hover_opacity = opacity
        self.update()

    hover_opacity = pyqtProperty(float, get_hover_opacity, set_hover_opacity)

    def enterEvent(self, event):
        self.anim.setEndValue(1.0)
        self.anim.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.anim.setEndValue(0.0)
        self.anim.start()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Podstawowy gradient
        base_gradient = QConicalGradient(self.rect().center(), self._angle)
        base_gradient.setColorAt(0.1, QColor(77, 171, 247, 200))
        base_gradient.setColorAt(0.3, QColor(33, 150, 243, 150))
        base_gradient.setColorAt(0.5, QColor(63, 81, 181, 200))
        base_gradient.setColorAt(0.7, QColor(33, 150, 243, 150))
        base_gradient.setColorAt(0.9, QColor(77, 171, 247, 200))

        # Gradient dla efektu hover
        hover_gradient = QConicalGradient(self.rect().center(), self._angle)
        hover_gradient.setColorAt(0.0, QColor(15, 150, 214, 200))
        hover_gradient.setColorAt(0.5, QColor(147, 112, 219, 150))
        hover_gradient.setColorAt(1.0, QColor(77, 171, 247, 200))

        # Mieszanie gradientów
        if self._hover_opacity > 0:
            # Rysowanie "poświaty" wokół przycisku
            glow_rect = self.rect().adjusted(-5, -5, 5, 5)
            glow_gradient = QRadialGradient(self.rect().center(), self.width() / 1.5)
            glow_gradient.setColorAt(0.0, QColor(255, 255, 255, int(100 * self._hover_opacity)))
            glow_gradient.setColorAt(1.0, QColor(255, 255, 255, 0))
            painter.setBrush(glow_gradient)
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(glow_rect, 15, 15)

        # Mieszanie gradientów na podstawie hover_opacity
        painter.setBrush(QBrush(base_gradient if self._hover_opacity == 0 else hover_gradient))

        # Grubość obramowania zależna od najechania
        border_width = 3 + int(self._hover_opacity * 3)
        border_color = QColor(128, 200, 255, 128 + int(127 * self._hover_opacity))

        painter.setPen(QPen(border_color, border_width))
        painter.drawRoundedRect(self.rect(), 15, 15)

        # Tekst z cieniem
        painter.setPen(QPen(QColor(0, 0, 0, 50), 1))
        painter.drawText(self.rect().adjusted(2, 2, 2, 2), Qt.AlignCenter, self.text())

        painter.setPen(QPen(QColor(255, 255, 255, 230), 1))
        painter.drawText(self.rect(), Qt.AlignCenter, self.text())

        painter.end()


class WeatherForecastWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(280)
        self.forecast_data = []

        self.init_ui()

    def init_ui(self):
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(10, 10, 10, 10)
        self.setLayout(self.layout)

    def update_forecast(self, forecast_data):
        # Wyczyść poprzednie dane
        while self.layout.count():
            item = self.layout.takeAt(0)
            if item.widget():
                widget = item.widget()
                widget.deleteLater()

        self.forecast_data = forecast_data

        # Dodaj nowe karty prognozy
        for day_data in forecast_data:
            card = QFrame()
            card.setObjectName("forecast_card")
            card.setFixedWidth(180)
            card.setMinimumHeight(260)

            card_layout = QVBoxLayout()

            # Data
            date_label = QLabel(day_data['date'])
            date_label.setAlignment(Qt.AlignCenter)
            date_label.setObjectName("forecast_date")

            # Ikona
            icon_label = QLabel()
            icon_label.setText(self.get_weather_icon(day_data['icon_code']))
            icon_label.setAlignment(Qt.AlignCenter)
            icon_label.setObjectName("forecast_icon")

            # Temperatura
            temp_label = QLabel(f"{day_data['temp_max']}°C / {day_data['temp_min']}°C")
            temp_label.setAlignment(Qt.AlignCenter)
            temp_label.setObjectName("forecast_temp")

            # Opis
            desc_label = QLabel(day_data['description'])
            desc_label.setAlignment(Qt.AlignCenter)
            desc_label.setObjectName("forecast_desc")
            desc_label.setWordWrap(True)

            # Wilgotność
            humidity_label = QLabel(f"Wilgotność: {day_data['humidity']}%")
            humidity_label.setAlignment(Qt.AlignCenter)

            # Wiatr
            wind_label = QLabel(f"Wiatr: {day_data['wind_speed']} m/s")
            wind_label.setAlignment(Qt.AlignCenter)

            card_layout.addWidget(date_label)
            card_layout.addWidget(icon_label)
            card_layout.addWidget(temp_label)
            card_layout.addWidget(desc_label)
            card_layout.addWidget(humidity_label)
            card_layout.addWidget(wind_label)

            card.setLayout(card_layout)
            self.layout.addWidget(card)

        self.layout.addStretch()

    def get_weather_icon(self, icon_code):
        icons = {
            '01d': '☀️', '01n': '🌕',
            '02d': '⛅', '02n': '☁️',
            '03d': '☁️', '03n': '☁️',
            '04d': '🌥️', '04n': '🌥️',
            '09d': '🌧️', '09n': '🌧️',
            '10d': '🌦️', '10n': '🌧️',
            '11d': '⛈️', '11n': '⛈️',
            '13d': '❄️', '13n': '❄️',
            '50d': '🌫️', '50n': '🌫️'
        }
        return icons.get(icon_code, '')


class WeatherChart(QWidget):
    def __init__(self, title="Temperatura"):
        super().__init__()
        self.title = title
        self.data = []
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        # Wykres
        self.plot_widget = pg.PlotWidget()
        self.plot_widget.setBackground((0, 4, 40, 150))
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget.setTitle(self.title, color='#4dabf7', size='24pt')

        # Ustawienia osi
        styles = {'color': '#4dabf7', 'font-size': '14pt'}
        self.plot_widget.setLabel('left', 'Wartość', **styles)
        self.plot_widget.setLabel('bottom', 'Godzina', **styles)

        # Ustawienia pióra
        self.pen = pg.mkPen(color=(77, 171, 247), width=3)

        layout.addWidget(self.plot_widget)
        self.setLayout(layout)

    def update_data(self, x_data, y_data, units="°C"):
        self.plot_widget.clear()

        # Dodanie linii z danymi
        self.line = self.plot_widget.plot(x_data, y_data, pen=self.pen, symbol='o', symbolSize=10,
                                          symbolBrush=(77, 171, 247))

        # Dodanie etykiet
        for i, (x, y) in enumerate(zip(x_data, y_data)):
            text = pg.TextItem(f"{y}{units}", color=(255, 255, 255), anchor=(0.5, 0))
            text.setPos(x, y)
            self.plot_widget.addItem(text)


class WeatherApp(QWidget):
    def __init__(self):
        super().__init__()
        self.api_key = "291422e57f5335e311fe5fc0a6efaab7"
        self.last_update = None
        self.forecast_data = []
        self.hourly_data = []
        self.selected_city = ""
        self.weather_condition = "clear"

        # Lista ostatnio wyszukiwanych miast
        self.recent_cities = []

        # Inicjalizacja interfejsu użytkownika (UI)
        self.init_ui()

        # Parametry animacji tła
        self.animation_params = {
            'gradient_angle': 0.0,
            'nebula_phase': 0.0,
            'star_phase': 0.0,
            'particle_phase': 0.0,
            'gradient_offset': 0.0
        }

        # Systemy cząsteczek dla różnych warunków pogodowych
        self.particles = {
            'stars': ParticleSystem(self.width(), self.height(), "stars"),
            'rain': ParticleSystem(self.width(), self.height(), "rain"),
            'snow': ParticleSystem(self.width(), self.height(), "snow"),
            'clouds': ParticleSystem(self.width(), self.height(), "clouds"),
            'thunder': ParticleSystem(self.width(), self.height(), "thunder")
        }

        # Konfiguracja timera do animacji tła
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)
        self.animation_timer.start(30)

        # Timer do automatycznego odświeżania danych
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.refresh_data)

        # Załadowanie czcionek
        self.load_fonts()

        # Inicjalizacja styli
        self.setup_styles()

    def close_application(self):
        # Zatrzymaj wszystkie timery
        self.animation_timer.stop()
        self.refresh_timer.stop()

        # Zamknij wszystkie widżety
        for widget in QApplication.topLevelWidgets():
            widget.close()

        # Zakończ aplikację
        QApplication.quit()
    def load_fonts(self):
        # Tutaj możesz dodać kod do ładowania dodatkowych czcionek
        # Na przykład za pomocą QFontDatabase
        pass

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drag_position = event.globalPos() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if hasattr(self, 'drag_position'):
            self.move(event.globalPos() - self.drag_position)
            event.accept()

    def init_ui(self):
        self.setWindowTitle("Weather App Pro Ultra")
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setWindowIcon(QIcon('moon.png'))
        self.setMinimumSize(1200, 800)

        title_bar = QWidget()
        title_bar.setObjectName("title_bar")
        title_bar_layout = QHBoxLayout()
        title_bar_layout.setContentsMargins(10, 5, 10, 5)

        # Główne layouty
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        content_layout = QVBoxLayout()
        content_layout.setContentsMargins(20, 20, 20, 20)
        content_layout.setSpacing(15)

        # Kontener na zawartość
        content_container = QWidget()
        content_container.setObjectName("content_container")
        content_container.setLayout(content_layout)

        # Przyciski kontrolne
        self.minimize_btn = QPushButton("─")
        self.close_btn = QPushButton("✕")
        title_label = QLabel("Weather App Pro Ultra")

        # Konfiguracja widgetów
        title_label.setObjectName("title_label")
        self.minimize_btn.setObjectName("window_control_btn")
        self.close_btn.setObjectName("window_control_btn")
        self.close_btn.setProperty("type", "close")

        title_bar_layout.addWidget(title_label)
        title_bar_layout.addStretch()
        title_bar_layout.addWidget(self.minimize_btn)
        title_bar_layout.addWidget(self.close_btn)
        title_bar.setLayout(title_bar_layout)

        # Pasek wyszukiwania
        search_layout = QHBoxLayout()

        # Combobox z ostatnio wyszukiwanymi miastami
        self.city_combo = QComboBox()
        self.city_combo.setEditable(True)
        self.city_combo.setObjectName("city_combo")
        self.city_combo.setMinimumHeight(50)

        # Przycisk wyszukiwania
        self.search_btn = AnimatedButton("Szukaj")
        self.search_btn.setObjectName("search_btn")

        # Przycisk odświeżania
        self.refresh_btn = AnimatedButton("⟳")
        self.refresh_btn.setObjectName("refresh_btn")
        self.refresh_btn.setFixedWidth(50)

        search_layout.addWidget(self.city_combo)
        search_layout.addWidget(self.search_btn)
        search_layout.addWidget(self.refresh_btn)

        # Zakładki
        self.tabs = QTabWidget()
        self.tabs.setObjectName("weather_tabs")

        # Zakładka - Aktualna pogoda
        self.current_tab = QWidget()
        current_layout = QGridLayout()

        # Panel lewy - ikona pogody
        self.weather_icon = QLabel()
        self.weather_icon.setObjectName("weather_icon")
        self.weather_icon.setAlignment(Qt.AlignCenter)
        pixmap = QPixmap("moon.png").scaled(250, 250, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.weather_icon.setPixmap(pixmap)

        # Panel środkowy - temperatura i warunki
        self.temperature_label = QLabel("--°C")
        self.temperature_label.setObjectName("temperature_label")
        self.temperature_label.setAlignment(Qt.AlignCenter)

        self.condition_label = QLabel("--")
        self.condition_label.setObjectName("condition_label")
        self.condition_label.setAlignment(Qt.AlignCenter)

        # Panel prawy - szczegóły
        details_widget = QWidget()
        details_widget.setObjectName("details_widget")
        details_layout = QGridLayout()

        # Etykiety szczegółów
        self.feels_like_label = QLabel("--")
        self.temp_min_label = QLabel("--")
        self.temp_max_label = QLabel("--")
        self.humidity_label = QLabel("--")
        self.pressure_label = QLabel("--")
        self.wind_label = QLabel("--")
        self.clouds_label = QLabel("--")
        self.sunrise_label = QLabel("--")
        self.sunset_label = QLabel("--")

        # Ustawienie nazw obiektów dla etykiet
        detail_labels = [
            self.feels_like_label, self.temp_min_label, self.temp_max_label,
            self.humidity_label, self.pressure_label, self.wind_label,
            self.clouds_label, self.sunrise_label, self.sunset_label
        ]

        for label in detail_labels:
            label.setObjectName("detail_label")
            label.setAlignment(Qt.AlignCenter)

        # Dodawanie etykiet do układu szczegółów
        details_layout.addWidget(QLabel("<b>Odczuwalna:</b>"), 0, 0)
        details_layout.addWidget(self.feels_like_label, 0, 1)
        details_layout.addWidget(QLabel("<b>Min:</b>"), 1, 0)
        details_layout.addWidget(self.temp_min_label, 1, 1)
        details_layout.addWidget(QLabel("<b>Max:</b>"), 2, 0)
        details_layout.addWidget(self.temp_max_label, 2, 1)
        details_layout.addWidget(QLabel("<b>Wilgotność:</b>"), 3, 0)
        details_layout.addWidget(self.humidity_label, 3, 1)
        details_layout.addWidget(QLabel("<b>Ciśnienie:</b>"), 4, 0)
        details_layout.addWidget(self.pressure_label, 4, 1)
        details_layout.addWidget(QLabel("<b>Wiatr:</b>"), 5, 0)
        details_layout.addWidget(self.wind_label, 5, 1)
        details_layout.addWidget(QLabel("<b>Zachmurzenie:</b>"), 6, 0)
        details_layout.addWidget(self.clouds_label, 6, 1)
        details_layout.addWidget(QLabel("<b>Wschód:</b>"), 7, 0)
        details_layout.addWidget(self.sunrise_label, 7, 1)
        details_layout.addWidget(QLabel("<b>Zachód:</b>"), 8, 0)
        details_layout.addWidget(self.sunset_label, 8, 1)

        details_widget.setLayout(details_layout)

        # Układ bieżącej pogody
        current_layout.addWidget(self.weather_icon, 0, 0, 3, 2)
        current_layout.addWidget(self.temperature_label, 0, 2, 1, 2)
        current_layout.addWidget(self.condition_label, 1, 2, 1, 2)
        current_layout.addWidget(details_widget, 0, 4, 3, 2)

        self.current_tab.setLayout(current_layout)

        # Zakładka - Prognoza
        self.forecast_tab = QWidget()
        forecast_layout = QVBoxLayout()

        # Widget prognozy na 5 dni
        self.forecast_widget = WeatherForecastWidget()

        # Scroll Area dla prognozy
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.forecast_widget)
        scroll_area.setObjectName("forecast_scroll")

        forecast_layout.addWidget(scroll_area)
        self.forecast_tab.setLayout(forecast_layout)

        # Zakładka - Wykresy
        self.charts_tab = QWidget()
        charts_layout = QVBoxLayout()

        # Dynamiczny wykres temperatury
        self.temp_chart = WeatherChart("Temperatura na 24h")
        self.humidity_chart = WeatherChart("Wilgotność na 24h")
        self.pressure_chart = WeatherChart("Ciśnienie na 24h")

        charts_layout.addWidget(self.temp_chart)
        charts_layout.addWidget(self.humidity_chart)
        charts_layout.addWidget(self.pressure_chart)

        self.charts_tab.setLayout(charts_layout)

        # Zakładka - Ustawienia
        self.settings_tab = QWidget()
        settings_layout = QVBoxLayout()

        # Opcje auto-odświeżania
        auto_refresh_label = QLabel("Auto-odświeżanie pogody:")
        self.auto_refresh_combo = QComboBox()
        self.auto_refresh_combo.addItems(["Wyłączone", "Co 15 minut", "Co 30 minut", "Co godzinę"])

        # Efekty wizualne
        effects_label = QLabel("Efekty wizualne:")
        self.effects_combo = QComboBox()
        self.effects_combo.addItems(["Podstawowe", "Normalne", "Wysokie", "Ultra"])

        # Ciemny/jasny motyw
        theme_label = QLabel("Motyw:")
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Ciemny", "Jasny", "Auto (pora dnia)"])

        settings_layout.addWidget(auto_refresh_label)
        settings_layout.addWidget(self.auto_refresh_combo)
        settings_layout.addSpacing(20)
        settings_layout.addWidget(effects_label)
        settings_layout.addWidget(self.effects_combo)
        settings_layout.addSpacing(20)
        settings_layout.addWidget(theme_label)
        settings_layout.addWidget(self.theme_combo)
        settings_layout.addStretch()

        self.settings_tab.setLayout(settings_layout)

        # Dodawanie zakładek
        self.tabs.addTab(self.current_tab, "Aktualna pogoda")
        self.tabs.addTab(self.forecast_tab, "Prognoza na 5 dni")
        self.tabs.addTab(self.charts_tab, "Wykresy")
        self.tabs.addTab(self.settings_tab, "Ustawienia")

        # Status i aktualizacja
        status_bar = QWidget()
        status_bar.setObjectName("status_bar")
        status_layout = QHBoxLayout()
        status_layout.setContentsMargins(10, 5, 10, 5)

        self.update_label = QLabel("Ostatnia aktualizacja: --")
        self.update_label.setObjectName("update_label")

        self.error_label = QLabel()
        self.error_label.setObjectName("error_label")

        status_layout.addWidget(self.update_label)
        status_layout.addStretch()
        status_layout.addWidget(self.error_label)

        status_bar.setLayout(status_layout)

        # Dodawanie wszystkich elementów do głównego layoutu
        main_layout.addWidget(title_bar)

        # Dodawanie layoutów do kontenera zawartości
        content_layout.addLayout(search_layout)
        content_layout.addWidget(self.tabs)
        content_layout.addWidget(status_bar)

        main_layout.addWidget(content_container)

        self.setLayout(main_layout)

        # Połączenia sygnałów
        self.search_btn.clicked.connect(self.get_weather)
        self.refresh_btn.clicked.connect(self.refresh_data)
        self.minimize_btn.clicked.connect(self.showMinimized)
        self.close_btn.clicked.connect(self.close_application)
        self.city_combo.currentIndexChanged.connect(self.on_city_selected)
        self.auto_refresh_combo.currentIndexChanged.connect(self.set_auto_refresh)
        self.effects_combo.currentIndexChanged.connect(self.set_effects_level)
        self.theme_combo.currentIndexChanged.connect(self.set_theme)

    def setup_styles(self):
        gradient_angle = self.animation_params['gradient_angle'] % 360

        self.setStyleSheet(f"""
        /* GLOBAL STYLES */
        QWidget {{
            color: #a0e7ff;
            font-family: 'Orbitron', 'Segoe UI', sans-serif;
            border-radius: 10px;
            text-shadow: 0 0 20px rgba(77, 171, 247, 0.4);
        }}

        QWidget#content_container {{
            background: rgba(0, 4, 40, 0.0);
            padding: 0px;
            margin: 0px;
        }}

        /* CUSTOM TITLE BAR */
        QWidget#title_bar {{
            background: qlineargradient(
                x1:0, y1:0, x2:1, y2:0,
                stop:0 rgba(15, 32, 64, 0.95),
                stop:1 rgba(30, 64, 128, 0.95)
            );
            border-bottom: 2px solid #4dabf7;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom-left-radius: 0px;
            border-bottom-right-radius: 0px;
            height: 40px;
        }}

        QLabel#title_label {{
            font-size: 24px;
            color: #4dabf7;
            text-shadow: 0 0 15px rgba(77, 171, 247, 0.8);
            background: transparent;
            border: none;
        }}

        QPushButton#window_control_btn {{
            background: transparent;
            border: 2px solid #4dabf7;
            border-radius: 8px;
            min-width: 30px;
            min-height: 30px;
            color: #4dabf7;
            font-size: 18px;
            padding: 0;
            margin-left: 10px;
        }}

        QPushButton#window_control_btn:hover {{
            background: rgba(77, 171, 247, 0.2);
            border-color: #a0e7ff;
        }}

        QPushButton[type="close"]:hover {{
            background: rgba(231, 76, 60, 0.3);
            border-color: #E74C3C;
            color: #E74C3C;
        }}

        /* STATUS BAR */
        QWidget#status_bar {{
            background: rgba(15, 32, 64, 0.7);
            border-top: 1px solid #4dabf7;
            border-radius: 0;
            padding: 5px;
        }}

        QLabel#update_label {{
            font-size: 14px;
            color: #4dabf7;
            background: transparent;
            border: none;
        }}

        QLabel#error_label {{
            color: #E74C3C;
            font-weight: bold;
            font-size: 14px;
            background: transparent;
            border: none;
        }}

        /* COMBOBOX */
        QComboBox {{
            background: rgba(0, 4, 40, 0.7);
            border: 2px solid #4dabf7;
            border-radius: 10px;
            padding: 8px 15px;
            font-size: 18px;
            color: #a0e7ff;
            min-height: 50px;
        }}

        QComboBox::drop-down {{
            subcontrol-origin: padding;
            subcontrol-position: center right;
            width: 30px;
            border-left: 1px solid #4dabf7;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
        }}

        QComboBox::down-arrow {{
            image: url(dropdown_arrow.png);
            width: 16px;
            height: 16px;
        }}

        QComboBox QAbstractItemView {{
            background: rgba(15, 32, 64, 0.95);
            border: 2px solid #4dabf7;
            border-radius: 10px;
            selection-background-color: rgba(77, 171, 247, 0.3);
        }}

        /* TABS */
        QTabWidget::pane {{
            border: 2px solid #4dabf7;
            border-radius: 10px;
            background: rgba(15, 32, 64, 0.7);
            top: -1px;
        }}

        QTabBar::tab {{
            background: rgba(15, 32, 64, 0.8);
            border: 2px solid #4dabf7;
            border-bottom: none;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            padding: 10px 20px;
            margin-right: 5px;
            color: #a0e7ff;
        }}

        QTabBar::tab:selected {{
            background: qlineargradient(
                x1:0, y1:0, x2:0, y2:1,
                stop:0 rgba(77, 171, 247, 0.5),
                stop:1 rgba(15, 32, 64, 0.8)
            );
        }}

        QTabBar::tab:hover:!selected {{
            background: rgba(77, 171, 247, 0.2);
        }}

        /* TEMPERATURE LABEL */
        QLabel#temperature_label {{
            font-size: 48px;
            color: #4dabf7;
            text-shadow: 0 0 40px rgba(77, 171, 247, 0.8);
            background: rgba(0, 4, 40, 0.6);
            border: 3px solid #4dabf7;
            border-radius: 20px;
            padding: 20px;
        }}

        /* CONDITION LABEL */
        QLabel#condition_label {{
            font-size: 24px;
            color: #a0e7ff;
            text-shadow: 0 0 20px rgba(77, 171, 247, 0.6);
            background: rgba(0, 4, 40, 0.6);
            border: 2px solid #4dabf7;
            border-radius: 15px;
            padding: 10px;
        }}

        /* WEATHER ICON */
        QLabel#weather_icon {{
            border-radius: 20px;
            border: 2px solid #4dabf7;
            padding: 20px;
            min-width: 200px;
            min-height: 200px;
            font-size: 160px;
            background: rgba(0, 4, 40, 0.6);
        }}

        /* DETAILS WIDGET */
        QWidget#details_widget {{
            background: rgba(0, 4, 40, 0.6);
            border: 2px solid #4dabf7;
            border-radius: 15px;
            padding: 15px;
        }}

        QLabel#detail_label {{
            font-size: 16px;
            color: #a0e7ff;
            background: transparent;
            border: none;
            padding: 5px;
        }}

        /* FORECAST CARD */
        QFrame#forecast_card {{
            background: rgba(15, 32, 64, 0.7);
            border: 2px solid #4dabf7;
            border-radius: 15px;
            padding: 10px;
        }}

        QLabel#forecast_date {{
            font-size: 16px;
            font-weight: bold;
            color: #4dabf7;
            background: transparent;
            border: none;
        }}

        QLabel#forecast_icon {{
            font-size: 72px;
            background: transparent;
            border: none;
        }}

        QLabel#forecast_temp {{
            font-size: 18px;
            color: #a0e7ff;
            background: transparent;
            border: none;
        }}

        QLabel#forecast_desc {{
            font-size: 14px;
            color: #a0e7ff;
            background: transparent;
            border: none;
        }}

        /* SCROLLBAR */
        QScrollArea {{
            border: none;
            background-color: transparent;
        }}

        QScrollBar:horizontal {{
            border: none;
            background: rgba(15, 32, 64, 0.5);
            height: 14px;
            margin: 0px 20px 0px 20px;
            border-radius: 7px;
        }}

        QScrollBar::handle:horizontal {{
            background: #4dabf7;
            min-width: 30px;
            border-radius: 7px;
        }}

        QScrollBar::add-line:horizontal {{
            border: none;
            background: rgba(77, 171, 247, 0.5);
            width: 20px;
            border-top-right-radius: 7px;
            border-bottom-right-radius: 7px;
            subcontrol-position: right;
            subcontrol-origin: margin;
        }}

        QScrollBar::sub-line:horizontal {{
            border: none;
            background: rgba(77, 171, 247, 0.5);
            width: 20px;
            border-top-left-radius: 7px;
            border-bottom-left-radius: 7px;
            subcontrol-position: left;
            subcontrol-origin: margin;
        }}

        QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
            background: none;
        }}

        /* SLIDER (do ustawień) */
        QSlider::groove:horizontal {{
            border: 1px solid #4dabf7;
            height: 8px;
            background: rgba(15, 32, 64, 0.7);
            margin: 2px 0;
            border-radius: 4px;
        }}

        QSlider::handle:horizontal {{
            background: qlineargradient(
                x1:0, y1:0, x2:1, y2:1,
                stop:0 #4dabf7,
                stop:1 #2185d0
            );
            border: 1px solid #4dabf7;
            width: 18px;
            margin: -2px 0;
            border-radius: 9px;
        }}

        QSlider::add-page:horizontal {{
            background: rgba(15, 32, 64, 0.8);
            border-radius: 4px;
        }}

        QSlider::sub-page:horizontal {{
            background: rgba(77, 171, 247, 0.5);
            border-radius: 4px;
        }}
        """)

        # Ręczne ustawienia dla elementów wymagających specjalnego traktowania
        self.weather_icon.setAlignment(Qt.AlignCenter)
        self.temperature_label.setAlignment(Qt.AlignCenter)
        self.error_label.setAlignment(Qt.AlignCenter)
        self.update_label.setAlignment(Qt.AlignCenter)

    def update_animation(self):
        # Aktualizacja parametrów animacji
        self.animation_params['gradient_angle'] = (self.animation_params['gradient_angle'] + 0.5) % 360
        self.animation_params['nebula_phase'] = (self.animation_params['nebula_phase'] + 0.01) % (2 * math.pi)
        self.animation_params['star_phase'] = (self.animation_params['star_phase'] + 0.015) % (2 * math.pi)
        self.animation_params['particle_phase'] = (self.animation_params['particle_phase'] + 0.03) % (2 * math.pi)
        self.animation_params['gradient_offset'] = (self.animation_params['gradient_offset'] + 0.7) % self.width()

        # Aktualizacja systemu cząstek
        for particle_system in self.particles.values():
            particle_system.update(self.animation_params['particle_phase'])

        self.update()

    def paintEvent(self, event):
        try:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)

            # Dynamiczne tło gradientowe
            gradient = QLinearGradient(
                self.animation_params['gradient_offset'], 0,
                self.animation_params['gradient_offset'] + self.width(), self.height()
            )

            # Ustawianie koloru tła w zależności od pory dnia i pogody
            if self.weather_condition in ["clear", "clouds"]:
                # Jasne tło dla słonecznej/pochmurnej pogody
                gradient.setColorAt(0, QColor(15, 32, 64))
                gradient.setColorAt(0.5, QColor(30, 64, 128))
                gradient.setColorAt(1, QColor(15, 32, 64))
            elif self.weather_condition == "rain":
                # Ciemniejsze tło dla deszczu
                gradient.setColorAt(0, QColor(10, 20, 40))
                gradient.setColorAt(0.5, QColor(20, 40, 80))
                gradient.setColorAt(1, QColor(10, 20, 40))
            elif self.weather_condition == "snow":
                # Jaśniejsze tło dla śniegu
                gradient.setColorAt(0, QColor(20, 40, 80))
                gradient.setColorAt(0.5, QColor(40, 80, 160))
                gradient.setColorAt(1, QColor(20, 40, 80))
            elif self.weather_condition == "thunderstorm":
                # Bardzo ciemne tło dla burzy
                gradient.setColorAt(0, QColor(5, 10, 30))
                gradient.setColorAt(0.5, QColor(15, 30, 60))
                gradient.setColorAt(1, QColor(5, 10, 30))

            painter.fillRect(self.rect(), gradient)

            # Efekt mgławicy
            phase = self.animation_params['nebula_phase']
            for i in range(3):
                radius = 500 * (0.8 + 0.2 * math.sin(phase + i))
                grad = QRadialGradient(
                    self.width() / 2 + 150 * math.cos(phase + i),
                    self.height() / 2 + 100 * math.sin(phase + i),
                    radius
                )

                if self.weather_condition == "clear":
                    # Niebieska mgławica dla czystego nieba
                    color = QColor(
                        30 + int(20 * math.sin(phase)),
                        60 + int(30 * math.cos(phase)),
                        90 + int(40 * math.sin(phase * 0.7)),
                        25
                    )
                elif self.weather_condition == "clouds":
                    # Szarawa mgławica dla chmur
                    color = QColor(
                        40 + int(20 * math.sin(phase)),
                        50 + int(20 * math.cos(phase)),
                        70 + int(30 * math.sin(phase * 0.7)),
                        25
                    )
                elif self.weather_condition == "rain":
                    # Ciemno-niebieska mgławica dla deszczu
                    color = QColor(
                        20 + int(10 * math.sin(phase)),
                        40 + int(15 * math.cos(phase)),
                        70 + int(20 * math.sin(phase * 0.7)),
                        30
                    )
                elif self.weather_condition == "snow":
                    # Jasno-niebieska mgławica dla śniegu
                    color = QColor(
                        60 + int(20 * math.sin(phase)),
                        70 + int(20 * math.cos(phase)),
                        100 + int(30 * math.sin(phase * 0.7)),
                        25
                    )
                elif self.weather_condition == "thunderstorm":
                    # Purpurowa mgławica dla burzy
                    color = QColor(
                        30 + int(20 * math.sin(phase)),
                        20 + int(10 * math.cos(phase)),
                        50 + int(20 * math.sin(phase * 0.7)),
                        35
                    )

                grad.setColorAt(0, color)
                grad.setColorAt(1, Qt.transparent)
                painter.setBrush(grad)
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(self.rect().center(), int(radius), int(radius))

            # Renderowanie efektów pogodowych
            if self.weather_condition == "clear" or self.weather_condition == "clouds":
                # Gwiazdy dla czystego nieba
                self.particles['stars'].render(painter)

                # Chmury dla pochmurnej pogody
                if self.weather_condition == "clouds":
                    self.particles['clouds'].render(painter)

            elif self.weather_condition == "rain":
                # Deszcz i chmury
                self.particles['clouds'].render(painter)
                self.particles['rain'].render(painter)

            elif self.weather_condition == "snow":
                # Śnieg i chmury
                self.particles['clouds'].render(painter)
                self.particles['snow'].render(painter)

            elif self.weather_condition == "thunderstorm":
                # Burza, deszcz i chmury
                self.particles['clouds'].render(painter)
                self.particles['rain'].render(painter)
                self.particles['thunder'].render(painter)

        except Exception as e:
            print(f"Błąd renderowania: {str(e)}")
        finally:
            painter.end()

    def resizeEvent(self, event):
        # Aktualizacja systemów cząstek po zmianie rozmiaru okna
        for condition, particle_system in self.particles.items():
            self.particles[condition] = ParticleSystem(self.width(), self.height(), condition)
        super().resizeEvent(event)

    def get_weather(self):
        city = self.city_combo.currentText()
        if not city:
            self.show_error("Proszę wpisać nazwę miasta!")
            return

        try:
            # Pobranie aktualnej pogody
            weather_url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&units=metric&lang=pl&appid={self.api_key}"
            weather_response = requests.get(weather_url)

            if weather_response.status_code != 200:
                self.show_error(f"Błąd API: {weather_response.status_code}")
                return

            weather_data = weather_response.json()
            self.update_current_weather(weather_data)

            # Pobranie prognozy na 5 dni
            forecast_url = f"https://api.openweathermap.org/data/2.5/forecast?q={city}&units=metric&lang=pl&appid={self.api_key}"
            forecast_response = requests.get(forecast_url)

            if forecast_response.status_code == 200:
                forecast_data = forecast_response.json()
                self.update_forecast(forecast_data)
                self.update_charts(forecast_data)

            # Aktualizacja czasu i statusu
            self.last_update = datetime.now()
            self.update_label.setText(f"Ostatnia aktualizacja: {self.last_update:%H:%M:%S}")

            # Zapisanie miasta w historii
            self.add_to_recent_cities(city)
            self.selected_city = city

            # Ukrycie komunikatu o błędzie
            self.error_label.clear()

        except Exception as e:
            self.show_error(f"Błąd: {str(e)}")

    def update_current_weather(self, data):
        main = data.get('main', {})
        weather = data.get('weather', [{}])[0]
        wind = data.get('wind', {})
        clouds = data.get('clouds', {})
        sys = data.get('sys', {})

        # Aktualizacja wszystkich etykiet
        self.temperature_label.setText(f"{main.get('temp', '--'):.1f}°C")
        self.condition_label.setText(weather.get('description', '--').capitalize())

        # Ustawienie ikony pogodowej
        icon_code = weather.get('icon', '')
        weather_icon = self.get_weather_icon(icon_code)
        self.weather_icon.setText(weather_icon)

        # Aktualizacja szczegółów
        self.feels_like_label.setText(f"{main.get('feels_like', '--'):.1f}°C")
        self.temp_min_label.setText(f"{main.get('temp_min', '--'):.1f}°C")
        self.temp_max_label.setText(f"{main.get('temp_max', '--'):.1f}°C")
        self.humidity_label.setText(f"{main.get('humidity', '--')}%")
        self.pressure_label.setText(f"{main.get('pressure', '--')} hPa")
        self.wind_label.setText(f"{wind.get('speed', '--')} m/s")
        self.clouds_label.setText(f"{clouds.get('all', '--')}%")
        self.sunrise_label.setText(self.format_time(sys.get('sunrise')))
        self.sunset_label.setText(self.format_time(sys.get('sunset')))

        # Aktualizacja typu pogody dla animacji
        weather_id = weather.get('id', 800)
        weather_main = weather.get('main', '').lower()

        if weather_id >= 200 and weather_id < 300:
            self.weather_condition = "thunderstorm"
        elif weather_id >= 300 and weather_id < 600:
            self.weather_condition = "rain"
        elif weather_id >= 600 and weather_id < 700:
            self.weather_condition = "snow"
        elif weather_id >= 700 and weather_id < 800:
            self.weather_condition = "clouds"  # mgła i inne
        elif weather_id == 800:
            self.weather_condition = "clear"
        elif weather_id > 800:
            self.weather_condition = "clouds"

    def update_forecast(self, data):
        forecast_items = data.get('list', [])
        forecast_data = []

        # Grupowanie prognozy po dniach
        days = {}
        for item in forecast_items:
            dt = datetime.fromtimestamp(item['dt'])
            day_key = dt.strftime('%Y-%m-%d')

            if day_key not in days:
                days[day_key] = []

            days[day_key].append(item)

        # Tworzenie danych prognozy (po jednej karcie na dzień)
        for day_key, items in days.items():
            if len(forecast_data) >= 5:  # Ograniczenie do 5 dni
                break

            # Tworzenie sumowanych danych dla danego dnia
            day_data = {
                'date': datetime.strptime(day_key, '%Y-%m-%d').strftime('%d.%m.%Y'),
                'temp_min': min(item['main']['temp_min'] for item in items),
                'temp_max': max(item['main']['temp_max'] for item in items),
                'icon_code': self.get_most_frequent_value(items, lambda x: x['weather'][0]['icon']),
                'description': self.get_most_frequent_value(items, lambda x: x['weather'][0]['description']),
                'humidity': sum(item['main']['humidity'] for item in items) / len(items),
                'wind_speed': sum(item['wind']['speed'] for item in items) / len(items)
            }

            forecast_data.append(day_data)

        # Aktualizacja widgetu prognozy
        self.forecast_widget.update_forecast(forecast_data)

    def update_charts(self, data):
        forecast_items = data.get('list', [])

        # Przygotowanie danych dla wykresów (na 24h)
        times = []
        temps = []
        humidities = []
        pressures = []

        # Zbieranie danych na najbliższe 24h (co 3h, 8 punktów)
        for i, item in enumerate(forecast_items[:8]):
            dt = datetime.fromtimestamp(item['dt'])
            hour = dt.strftime('%H:%M')

            times.append(i)  # Indeks jako X
            temps.append(round(item['main']['temp'], 1))
            humidities.append(item['main']['humidity'])
            pressures.append(item['main']['pressure'])

        # Aktualizacja wykresów
        self.temp_chart.update_data(times, temps, "°C")
        self.humidity_chart.update_data(times, humidities, "%")
        self.pressure_chart.update_data(times, pressures, " hPa")

    def get_most_frequent_value(self, items, key_func):
        # Funkcja pomocnicza do znajdowania najczęściej występującej wartości
        values = {}
        for item in items:
            value = key_func(item)
            if value in values:
                values[value] += 1
            else:
                values[value] = 1

        # Znajdź wartość z największą liczbą wystąpień
        return max(values.items(), key=lambda x: x[1])[0]

    def add_to_recent_cities(self, city):
        # Dodawanie miasta do historii ostatnio wyszukiwanych
        if city in self.recent_cities:
            self.recent_cities.remove(city)

        self.recent_cities.insert(0, city)
        if len(self.recent_cities) > 10:  # Ogranicz do 10 ostatnich miast
            self.recent_cities.pop()

        # Aktualizacja ComboBox z miastami
        self.city_combo.blockSignals(True)
        self.city_combo.clear()
        self.city_combo.addItems(self.recent_cities)
        self.city_combo.setCurrentIndex(0)
        self.city_combo.blockSignals(False)

    def on_city_selected(self, index):
        if index >= 0 and self.city_combo.currentText() != self.selected_city:
            self.get_weather()

    def refresh_data(self):
        if self.selected_city:
            self.get_weather()

    def set_auto_refresh(self, index):
        # Wyłączenie poprzedniego timera
        self.refresh_timer.stop()

        # Ustawienie nowego interwału
        if index == 1:  # Co 15 minut
            self.refresh_timer.start(15 * 60 * 1000)
        elif index == 2:  # Co 30 minut
            self.refresh_timer.start(30 * 60 * 1000)
        elif index == 3:  # Co godzinę
            self.refresh_timer.start(60 * 60 * 1000)

    def set_effects_level(self, index):
        # Dostosowanie liczby cząstek w zależności od wybranego poziomu efektów
        particles_count = {
            0: {  # Podstawowe
                'stars': 100, 'rain': 30, 'snow': 20, 'clouds': 3, 'thunder': 2
            },
            1: {  # Normalne
                'stars': 200, 'rain': 70, 'snow': 50, 'clouds': 5, 'thunder': 3
            },
            2: {  # Wysokie
                'stars': 300, 'rain': 100, 'snow': 80, 'clouds': 8, 'thunder': 5
            },
            3: {  # Ultra
                'stars': 500, 'rain': 200, 'snow': 150, 'clouds': 12, 'thunder': 8
            }
        }

        # Aktualizacja systemów cząstek
        for condition, count in particles_count.get(index, particles_count[1]).items():
            self.particles[condition] = ParticleSystem(self.width(), self.height(), condition)

    def set_theme(self, index):
        # Implementacja zmiany motywu
        pass

    def get_weather_icon(self, icon_code):
        icons = {
            '01d': '☀️', '01n': '🌕',
            '02d': '⛅', '02n': '☁️',
            '03d': '☁️', '03n': '☁️',
            '04d': '🌥️', '04n': '🌥️',
            '09d': '🌧️', '09n': '🌧️',
            '10d': '🌦️', '10n': '🌧️',
            '11d': '⛈️', '11n': '⛈️',
            '13d': '❄️', '13n': '❄️',
            '50d': '🌫️', '50n': '🌫️'
        }
        return icons.get(icon_code, '🌡️')

    def format_time(self, timestamp):
        if timestamp:
            return datetime.fromtimestamp(timestamp).strftime("%H:%M:%S")
        return "--"

    def show_error(self, message):
        self.error_label.setText(message)
        QTimer.singleShot(5000, self.error_label.clear)


class NotificationManager:
    """Klasa zarządzająca powiadomieniami pogodowymi"""

    def __init__(self):
        self.notifications = []

    def add_alert(self, title, message, level="info"):
        """Dodaje nowe powiadomienie"""
        self.notifications.append({
            "id": len(self.notifications),
            "title": title,
            "message": message,
            "level": level,
            "time": datetime.now()
        })

    def get_alerts(self):
        """Zwraca wszystkie powiadomienia"""
        return self.notifications

    def clear_alerts(self):
        """Czyści wszystkie powiadomienia"""
        self.notifications = []


class WeatherWidget(QWidget):
    """Widget małej pogody do umieszczenia na pulpicie"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(200, 100)



    def update_weather(self, temp, icon, city):
        self.temp_label.setText(f"{temp}°C")
        self.icon_label.setText(icon)
        self.city_label.setText(city)

    def mousePressEvent(self, event):
        self.old_pos = event.globalPos()

    def mouseMoveEvent(self, event):
        delta = QPoint(event.globalPos() - self.old_pos)
        self.move(self.x() + delta.x(), self.y() + delta.y())
        self.old_pos = event.globalPos()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Załadowanie czcionek
    QFontDatabase.addApplicationFont("fonts/Orbitron-Regular.ttf")
    QFontDatabase.addApplicationFont("fonts/Orbitron-Bold.ttf")

    window = WeatherApp()
    window.show()

    # Tworzenie małego widgetu pogody
    desktop_widget = WeatherWidget()
    desktop_widget.show()

    sys.exit(app.exec_())