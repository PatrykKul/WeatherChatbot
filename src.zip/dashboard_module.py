from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QFrame, QTabWidget, QSplitter, QScrollArea,
                             QGridLayout, QPushButton, QComboBox)
from PyQt5.QtCore import Qt, QPropertyAnimation, QRect, pyqtSignal, QTimer
from PyQt5.QtGui import QFont, QColor, QPainter

from visualization_module import (WeatherChart, WeatherForecastWidget,
                                  WeatherInfoWidget, WeatherMapWidget)


class WeatherDashboard(QWidget):
    """
    Główny widget dashboardu wyświetlający wszystkie informacje pogodowe
    w formie wizualnej z wykorzystaniem komponentów z UltraWeatherApi.
    """
    # Sygnały
    city_changed = pyqtSignal(str)

    def __init__(self, weather_service):
        super().__init__()
        self.weather_service = weather_service
        self.current_data = None
        self.forecast_data = None

        # Inicjalizacja UI
        self.init_ui()

        # Timer do auto-odświeżania
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh_data)

    def init_ui(self):
        # Główny układ
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)

        # Widget z informacją o bieżącej pogodzie
        self.current_weather_widget = WeatherInfoWidget()

        # Splitter do dynamicznego podziału
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.current_weather_widget)

        # Zakładki z różnymi widokami
        tabs = QTabWidget()
        tabs.setObjectName("dashboard_tabs")

        # Zakładka - Prognoza
        forecast_tab = QWidget()
        forecast_layout = QVBoxLayout(forecast_tab)

        # Filtr prognozy
        filter_widget = QWidget()
        filter_layout = QHBoxLayout(filter_widget)
        filter_layout.setContentsMargins(0, 0, 0, 10)

        filter_layout.addWidget(QLabel("Pokaż prognozę:"))

        self.forecast_period_combo = QComboBox()
        self.forecast_period_combo.addItems([
            "Dzisiaj (co godzinę)",
            "5 dni (co 3 godziny)",
            "Najbliższy tydzień"
        ])
        self.forecast_period_combo.currentIndexChanged.connect(self.on_forecast_period_changed)
        filter_layout.addWidget(self.forecast_period_combo)

        filter_layout.addStretch()

        self.forecast_unit_combo = QComboBox()
        self.forecast_unit_combo.addItem("Wybierz jednostkę", None)  # Placeholder item
        self.forecast_unit_combo.addItem("°C", "celsius")
        self.forecast_unit_combo.addItem("°F", "fahrenheit")
        self.forecast_unit_combo.addItem("K", "kelvin")
        self.forecast_unit_combo.currentIndexChanged.connect(self.on_unit_changed)
        filter_layout.addWidget(QLabel("Jednostka:"))
        filter_layout.addWidget(self.forecast_unit_combo)

        forecast_layout.addWidget(filter_widget)

        # Widget prognozy na 5 dni
        self.forecast_widget = WeatherForecastWidget()
        forecast_scroll = QScrollArea()
        forecast_scroll.setWidgetResizable(True)
        forecast_scroll.setWidget(self.forecast_widget)
        forecast_scroll.setObjectName("forecast_scroll")

        forecast_layout.addWidget(forecast_scroll)

        # Zakładka - Wykresy
        charts_tab = QWidget()
        charts_layout = QVBoxLayout(charts_tab)
        charts_layout.setContentsMargins(10, 10, 10, 10)

        # Grupa przycisków do wyboru wykresu
        chart_buttons = QWidget()
        chart_buttons_layout = QHBoxLayout(chart_buttons)
        chart_buttons_layout.setContentsMargins(0, 0, 0, 10)

        self.temp_btn = QPushButton("Temperatura")
        self.temp_btn.setObjectName("chart_select_btn")
        self.temp_btn.setCheckable(True)
        self.temp_btn.setChecked(True)
        self.temp_btn.clicked.connect(lambda: self.show_chart(0))

        self.humid_btn = QPushButton("Wilgotność")
        self.humid_btn.setObjectName("chart_select_btn")
        self.humid_btn.setCheckable(True)
        self.humid_btn.clicked.connect(lambda: self.show_chart(1))

        self.press_btn = QPushButton("Ciśnienie")
        self.press_btn.setObjectName("chart_select_btn")
        self.press_btn.setCheckable(True)
        self.press_btn.clicked.connect(lambda: self.show_chart(2))

        self.wind_btn = QPushButton("Wiatr")
        self.wind_btn.setObjectName("chart_select_btn")
        self.wind_btn.setCheckable(True)
        self.wind_btn.clicked.connect(lambda: self.show_chart(3))

        self.precip_btn = QPushButton("Opady")
        self.precip_btn.setObjectName("chart_select_btn")
        self.precip_btn.setCheckable(True)
        self.precip_btn.clicked.connect(lambda: self.show_chart(4))

        self.chart_buttons = [self.temp_btn, self.humid_btn, self.press_btn, self.wind_btn, self.precip_btn]

        chart_buttons_layout.addWidget(self.temp_btn)
        chart_buttons_layout.addWidget(self.humid_btn)
        chart_buttons_layout.addWidget(self.press_btn)
        chart_buttons_layout.addWidget(self.wind_btn)
        chart_buttons_layout.addWidget(self.precip_btn)
        chart_buttons_layout.addStretch()

        charts_layout.addWidget(chart_buttons)

        # Stos wykresów
        from PyQt5.QtWidgets import QStackedWidget
        self.chart_stack = QStackedWidget()

        # Wykres temperatury
        self.temp_chart = WeatherChart("Temperatura na 24h")
        self.chart_stack.addWidget(self.temp_chart)

        # Wykres wilgotności
        self.humidity_chart = WeatherChart("Wilgotność na 24h")
        self.chart_stack.addWidget(self.humidity_chart)

        # Wykres ciśnienia
        self.pressure_chart = WeatherChart("Ciśnienie na 24h")
        self.chart_stack.addWidget(self.pressure_chart)

        # Wykres wiatru
        self.wind_chart = WeatherChart("Prędkość wiatru na 24h")
        self.chart_stack.addWidget(self.wind_chart)

        # Wykres opadów
        self.precip_chart = WeatherChart("Prawdopodobieństwo opadów na 24h")
        self.chart_stack.addWidget(self.precip_chart)

        charts_layout.addWidget(self.chart_stack)

        # Zakładka - Mapa
        map_tab = QWidget()
        map_layout = QVBoxLayout(map_tab)

        self.map_widget = WeatherMapWidget()
        map_layout.addWidget(self.map_widget)

        # Zakładka - Statystyki
        stats_tab = QWidget()
        stats_layout = QGridLayout(stats_tab)

        # Statystyki historyczne
        history_frame = QFrame()
        history_frame.setObjectName("stats_frame")
        history_layout = QVBoxLayout(history_frame)

        history_title = QLabel("Statystyki historyczne")
        history_title.setObjectName("frame_title")
        history_layout.addWidget(history_title)

        self.history_chart = WeatherChart("Temperatury w ostatnich 30 dniach")
        history_layout.addWidget(self.history_chart)

        # Widget porównawczy
        comparison_frame = QFrame()
        comparison_frame.setObjectName("stats_frame")
        comparison_layout = QVBoxLayout(comparison_frame)

        comparison_title = QLabel("Porównanie z normami")
        comparison_title.setObjectName("frame_title")
        comparison_layout.addWidget(comparison_title)

        comparison_content = QLabel(
            "Średnia temperatura: +2.3°C powyżej normy wieloletniej\nSuma opadów: 87% normy wieloletniej")
        comparison_content.setObjectName("stats_content")
        comparison_layout.addWidget(comparison_content)

        # Rekordy
        records_frame = QFrame()
        records_frame.setObjectName("stats_frame")
        records_layout = QVBoxLayout(records_frame)

        records_title = QLabel("Rekordy dla wybranej lokalizacji")
        records_title.setObjectName("frame_title")
        records_layout.addWidget(records_title)

        records_content = QLabel(
            "Najwyższa temperatura: 37.8°C (08.08.2015)\nNajniższa temperatura: -28.3°C (06.01.1987)\nNajwyższe opady dobowe: 98mm (12.07.2011)")
        records_content.setObjectName("stats_content")
        records_layout.addWidget(records_content)

        # Układanie elementów w siatce
        stats_layout.addWidget(history_frame, 0, 0, 1, 2)
        stats_layout.addWidget(comparison_frame, 1, 0)
        stats_layout.addWidget(records_frame, 1, 1)

        # Dodanie zakładek
        tabs.addTab(forecast_tab, "Prognoza")
        tabs.addTab(charts_tab, "Wykresy")
        tabs.addTab(map_tab, "Mapa")
        tabs.addTab(stats_tab, "Statystyki")

        splitter.addWidget(tabs)

        # Proporcje splittera
        splitter.setSizes([300, 500])

        main_layout.addWidget(splitter)

        # Ustawienie domyślnego pierwszego wykresu
        self.show_chart(0)

    def show_chart(self, index):
        """Przełącza aktywny wykres"""
        self.chart_stack.setCurrentIndex(index)

        # Aktualizacja zaznaczonych przycisków
        for i, btn in enumerate(self.chart_buttons):
            btn.setChecked(i == index)

    def on_forecast_period_changed(self, index):
        """Obsługa zmiany okresu prognozy"""
        if self.forecast_data:
            # Aktualizacja widoku prognozy w zależności od wybranego okresu
            if index == 0:  # Dzisiaj co godzinę
                self.forecast_widget.update_forecast(self.forecast_data.get('hourly', [])[:24])
            elif index == 1:  # 5 dni co 3 godziny
                self.forecast_widget.update_forecast(self.forecast_data.get('five_day', []))
            elif index == 2:  # Najbliższy tydzień
                self.forecast_widget.update_forecast(self.forecast_data.get('daily', []))

    def on_unit_changed(self, index):
        """Obsługa zmiany jednostki temperatury"""
        # Skip if the placeholder is selected
        if index == 0:
            return

        units = [None, "celsius", "fahrenheit", "kelvin"]
        selected_unit = units[index]

        # Skip if None is selected
        if not selected_unit:
            return

        # Aktualizacja jednostek w widgetach
        self.current_weather_widget.set_temperature_unit(selected_unit)
        self.forecast_widget.set_temperature_unit(selected_unit)

        # Aktualizacja wykresów
        self.update_charts(selected_unit)

    # Dodaj tę metodę do klasy DashboardWidget w pliku dashboard_module.py

    def apply_language(self, language, translations):
        """Aktualizuje język interfejsu dashboardu"""
        # Dodaj tłumaczenia specyficzne dla dashboardu
        dashboard_translations = {
            "pl": {
                "forecast_tab": "Prognoza",
                "charts_tab": "Wykresy",
                "map_tab": "Mapa",
                "stats_tab": "Statystyki",
                "show_forecast": "Pokaż prognozę:",
                "unit": "Jednostka:",
                "today_hourly": "Dzisiaj (co godzinę)",
                "five_days": "5 dni (co 3 godziny)",
                "next_week": "Najbliższy tydzień",
                "choose_unit": "Wybierz jednostkę",
                "temperature": "Temperatura",
                "humidity": "Wilgotność",
                "pressure": "Ciśnienie",
                "wind": "Wiatr",
                "precipitation": "Opady",
                "historical_stats": "Statystyki historyczne",
                "norm_comparison": "Porównanie z normami",
                "location_records": "Rekordy dla wybranej lokalizacji",
                "avg_temp": "Średnia temperatura:",
                "precip_sum": "Suma opadów:",
                "highest_temp": "Najwyższa temperatura:",
                "lowest_temp": "Najniższa temperatura:",
                "highest_precip": "Najwyższe opady dobowe:",
                "above_norm": "powyżej normy wieloletniej",
                "below_norm": "poniżej normy wieloletniej",
                "of_norm": "normy wieloletniej",
                "temp_24h": "Temperatura na 24h",
                "humidity_24h": "Wilgotność na 24h",
                "pressure_24h": "Ciśnienie na 24h",
                "wind_24h": "Prędkość wiatru na 24h",
                "precip_prob_24h": "Prawdopodobieństwo opadów na 24h",
                "temp_30days": "Temperatury w ostatnich 30 dniach",
                "weather_map": "Mapa Pogodowa",
                "location": "Lokalizacja:",
                "select_layer": "Wybierz warstwę poniżej",
                "no_weather_data": "Brak danych pogodowych",
                "data_available": "Dane pogodowe dostępne",
                "layers": "Warstwy:"
            },
            "en": {
                "forecast_tab": "Forecast",
                "charts_tab": "Charts",
                "map_tab": "Map",
                "stats_tab": "Statistics",
                "show_forecast": "Show forecast:",
                "unit": "Unit:",
                "today_hourly": "Today (hourly)",
                "five_days": "5 days (every 3 hours)",
                "next_week": "Next week",
                "choose_unit": "Choose unit",
                "temperature": "Temperature",
                "humidity": "Humidity",
                "pressure": "Pressure",
                "wind": "Wind",
                "precipitation": "Precipitation",
                "historical_stats": "Historical Statistics",
                "norm_comparison": "Comparison with norms",
                "location_records": "Records for selected location",
                "avg_temp": "Average temperature:",
                "precip_sum": "Precipitation sum:",
                "highest_temp": "Highest temperature:",
                "lowest_temp": "Lowest temperature:",
                "highest_precip": "Highest daily precipitation:",
                "above_norm": "above long-term norm",
                "below_norm": "below long-term norm",
                "of_norm": "of long-term norm",
                "temp_24h": "Temperature for 24h",
                "humidity_24h": "Humidity for 24h",
                "pressure_24h": "Pressure for 24h",
                "wind_24h": "Wind speed for 24h",
                "precip_prob_24h": "Precipitation probability for 24h",
                "temp_30days": "Temperatures in the last 30 days",
                "weather_map": "Weather Map",
                "location": "Location:",
                "select_layer": "Select a layer below",
                "no_weather_data": "No weather data",
                "data_available": "Weather data available",
                "layers": "Layers:"
            }
        }

        # Aktualizacja nazw zakładek
        tabs = self.findChild(QTabWidget)
        if tabs:
            tabs.setTabText(0, dashboard_translations[language]["forecast_tab"])
            tabs.setTabText(1, dashboard_translations[language]["charts_tab"])
            tabs.setTabText(2, dashboard_translations[language]["map_tab"])
            tabs.setTabText(3, dashboard_translations[language]["stats_tab"])

        # Aktualizacja etykiet filtrów prognozy
        for label in self.findChildren(QLabel):
            if "Pokaż prognozę" in label.text() or "Show forecast" in label.text():
                label.setText(dashboard_translations[language]["show_forecast"])
            elif "Jednostka" in label.text() or "Unit" in label.text():
                label.setText(dashboard_translations[language]["unit"])
            elif "Lokalizacja" in label.text() or "Location" in label.text():
                label.setText(dashboard_translations[language]["location"])
            elif "Warstwy" in label.text() or "Layers" in label.text():
                label.setText(dashboard_translations[language]["layers"])

        # Aktualizacja pozycji w comboboxach
        if hasattr(self, 'forecast_period_combo') and self.forecast_period_combo:
            self.forecast_period_combo.setItemText(0, dashboard_translations[language]["today_hourly"])
            self.forecast_period_combo.setItemText(1, dashboard_translations[language]["five_days"])
            self.forecast_period_combo.setItemText(2, dashboard_translations[language]["next_week"])

        if hasattr(self, 'forecast_unit_combo') and self.forecast_unit_combo:
            self.forecast_unit_combo.setItemText(0, dashboard_translations[language]["choose_unit"])

        # Aktualizacja przycisków wykresów
        if hasattr(self, 'temp_btn') and self.temp_btn:
            self.temp_btn.setText(dashboard_translations[language]["temperature"])
        if hasattr(self, 'humid_btn') and self.humid_btn:
            self.humid_btn.setText(dashboard_translations[language]["humidity"])
        if hasattr(self, 'press_btn') and self.press_btn:
            self.press_btn.setText(dashboard_translations[language]["pressure"])
        if hasattr(self, 'wind_btn') and self.wind_btn:
            self.wind_btn.setText(dashboard_translations[language]["wind"])
        if hasattr(self, 'precip_btn') and self.precip_btn:
            self.precip_btn.setText(dashboard_translations[language]["precipitation"])

        # Aktualizacja tytułów wykresów
        if hasattr(self, 'temp_chart') and self.temp_chart:
            self.temp_chart.title = dashboard_translations[language]["temp_24h"]
            # Może być konieczna dodatkowa metoda do odświeżenia wykresu
        if hasattr(self, 'humidity_chart') and self.humidity_chart:
            self.humidity_chart.title = dashboard_translations[language]["humidity_24h"]
        if hasattr(self, 'pressure_chart') and self.pressure_chart:
            self.pressure_chart.title = dashboard_translations[language]["pressure_24h"]
        if hasattr(self, 'wind_chart') and self.wind_chart:
            self.wind_chart.title = dashboard_translations[language]["wind_24h"]
        if hasattr(self, 'precip_chart') and self.precip_chart:
            self.precip_chart.title = dashboard_translations[language]["precip_prob_24h"]
        if hasattr(self, 'history_chart') and self.history_chart:
            self.history_chart.title = dashboard_translations[language]["temp_30days"]

        if hasattr(self, 'current_weather_widget'):
            print(f"Wywołuję apply_language dla current_weather_widget z językiem: {language}")  # Debugging
            self.current_weather_widget.apply_language(language)
        else:
            print("Nie znaleziono current_weather_widget!")

        # Aktualizacja mapy
        if hasattr(self, 'map_widget') and self.map_widget:
            if hasattr(self.map_widget, 'map_title') and self.map_widget.map_title:
                self.map_widget.map_title.setText(dashboard_translations[language]["weather_map"])
            if hasattr(self.map_widget, 'data_status') and self.map_widget.data_status:
                current_text = self.map_widget.data_status.text()
                if "Brak danych" in current_text or "No weather data" in current_text:
                    self.map_widget.data_status.setText(dashboard_translations[language]["no_weather_data"])
                elif "Dane pogodowe dostępne" in current_text or "Weather data available" in current_text:
                    self.map_widget.data_status.setText(dashboard_translations[language]["data_available"])

        # Aktualizacja tytułów w zakładce statystyk
        for label in self.findChildren(QLabel, "frame_title"):
            if "Statystyki historyczne" in label.text() or "Historical Statistics" in label.text():
                label.setText(dashboard_translations[language]["historical_stats"])
            elif "Porównanie z normami" in label.text() or "Comparison with norms" in label.text():
                label.setText(dashboard_translations[language]["norm_comparison"])
            elif "Rekordy dla wybranej lokalizacji" in label.text() or "Records for selected location" in label.text():
                label.setText(dashboard_translations[language]["location_records"])

        # Aktualizacja tekstów porównania z normami
        stats_frames = self.findChildren(QFrame, "stats_frame")
        for frame in stats_frames:
            for label in frame.findChildren(QLabel, "stats_content"):
                # Dla porównania z normami
                if "+2.3°C" in label.text() and "normy wieloletniej" in label.text():
                    new_text = f"{dashboard_translations[language]['avg_temp']} +2.3°C {dashboard_translations[language]['above_norm']}\n"
                    new_text += f"{dashboard_translations[language]['precip_sum']} 87% {dashboard_translations[language]['of_norm']}"
                    label.setText(new_text)
                # Dla rekordów
                elif "Najwyższa temperatura" in label.text() or "Highest temperature" in label.text():
                    new_text = f"{dashboard_translations[language]['highest_temp']} 37.8°C (08.08.2015)\n"
                    new_text += f"{dashboard_translations[language]['lowest_temp']} -28.3°C (06.01.1987)\n"
                    new_text += f"{dashboard_translations[language]['highest_precip']} 98mm (12.07.2011)"
                    label.setText(new_text)

    def update_data(self, app_context):
        """Aktualizacja danych w dashboardzie"""
        city = app_context.get("current_city")
        if not city:
            return

        # Asynchroniczne pobieranie danych
        self.weather_service.get_weather_data(city, self.on_weather_data_received)
        self.weather_service.get_forecast_data(city, self.on_forecast_data_received)

    def on_weather_data_received(self, data):
        """Callback po otrzymaniu aktualnych danych pogodowych"""
        if not data.get("success", False):
            return

        self.current_data = data

        # Aktualizacja widgetu aktualnej pogody
        self.current_weather_widget.update_weather(data)

        # Aktualizacja mapy
        self.map_widget.set_location(data.get("lat", 0), data.get("lon", 0))

    def on_forecast_data_received(self, data):
        """Callback po otrzymaniu danych prognozy"""
        if not data.get("success", False):
            return

        self.forecast_data = data

        # Aktualizacja widgetu prognozy zgodnie z wybranym okresem
        period_index = self.forecast_period_combo.currentIndex()

        if period_index == 0:  # Dzisiaj co godzinę
            self.forecast_widget.update_forecast(data.get('hourly', [])[:24])
        elif period_index == 1:  # 5 dni co 3 godziny
            self.forecast_widget.update_forecast(data.get('five_day', []))
        elif period_index == 2:  # Najbliższy tydzień
            self.forecast_widget.update_forecast(data.get('daily', []))

        # Aktualizacja wykresów
        self.update_charts()

        # Aktualizacja danych historycznych
        self.update_historical_data()

    def update_charts(self, unit="celsius"):
        """Aktualizacja danych na wykresach"""
        if not self.forecast_data:
            return

        # Dane dla wykresów
        times = []
        temps = []
        humidities = []
        pressures = []
        wind_speeds = []
        precip_probs = []

        # Zbieranie danych na najbliższe 24h
        hourly_data = self.forecast_data.get('hourly', [])[:24]

        for i, item in enumerate(hourly_data):
            hour = item.get('time', f"{i}:00")

            times.append(i)  # Indeks jako X
            # Zaokrąglanie wszystkich wartości do 2 miejsc po przecinku
            temps.append(round(self.convert_temp(item.get('temp', 0), unit), 2))
            humidities.append(round(item.get('humidity', 0), 2))
            pressures.append(round(item.get('pressure', 1000), 2))
            wind_speeds.append(round(item.get('wind_speed', 0), 2))
            precip_probs.append(round(item.get('pop', 0) * 100, 2))  # Prawdopodobieństwo opadów w %

        # Aktualizacja wykresów
        self.temp_chart.update_data(times, temps, self.get_temp_unit_symbol(unit))
        self.humidity_chart.update_data(times, humidities, "%")
        self.pressure_chart.update_data(times, pressures, " hPa")
        self.wind_chart.update_data(times, wind_speeds, " m/s")
        self.precip_chart.update_data(times, precip_probs, "%")


    def update_historical_data(self):
        """Aktualizacja danych historycznych"""
        # W rzeczywistej implementacji tutaj byłoby pobieranie danych historycznych
        # Na potrzeby demonstracji generujemy przykładowe dane
        import random
        import numpy as np

        days = list(range(1, 31))
        # Zaokrąglanie temperatur do 2 miejsc po przecinku
        temps = [round(random.uniform(10, 25), 2) for _ in range(30)]

        # Dodanie trendu
        trend = np.linspace(-2, 2, 30)
        temps = [round(t + tr, 2) for t, tr in zip(temps, trend)]

        self.history_chart.update_data(days, temps, "°C")

    def convert_temp(self, celsius, unit):
        """Konwersja temperatury z Celsjusza na wybraną jednostkę"""
        if unit == "celsius":
            return celsius
        elif unit == "fahrenheit":
            return (celsius * 9 / 5) + 32
        elif unit == "kelvin":
            return celsius + 273.15
        return celsius

    def get_temp_unit_symbol(self, unit):
        """Zwraca symbol jednostki temperatury"""
        if unit == "celsius":
            return "°C"
        elif unit == "fahrenheit":
            return "°F"
        elif unit == "kelvin":
            return "K"
        return "°C"

    def refresh_data(self):
        """Odświeżenie danych pogodowych"""
        if self.current_data:
            city = self.current_data.get("city")
            if city:
                self.weather_service.get_weather_data(city, self.on_weather_data_received)
                self.weather_service.get_forecast_data(city, self.on_forecast_data_received)

    def apply_preferences(self, prefs):
        """Zastosowanie preferencji użytkownika"""
        # Ustawienie jednostki temperatury
        unit_map = {"celsius": 1, "fahrenheit": 2, "kelvin": 3}
        unit = prefs.get("temperature_unit", "celsius")
        self.forecast_unit_combo.setCurrentIndex(unit_map.get(unit, 0))

        # Ustawienie auto-odświeżania
        refresh_minutes = prefs.get("auto_refresh", 30)
        if refresh_minutes > 0:
            self.refresh_timer.start(refresh_minutes * 60 * 1000)
        else:
            self.refresh_timer.stop()