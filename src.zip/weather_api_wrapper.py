import threading
from datetime import datetime, timedelta
from PyQt5.QtCore import QObject, pyqtSignal, pyqtSlot
import numpy as np
# Importowanie istniejącej implementacji API pogodowego
from weather_api import WeatherAPI

class WeatherAPIService(QObject):
    """
    Wrapper dla API pogodowego, który obsługuje asynchroniczne zapytania
    i formatuje dane dla interfejsu użytkownika.
    """
    # Sygnały
    weather_data_ready = pyqtSignal(dict)
    forecast_data_ready = pyqtSignal(dict)
    historical_data_ready = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, api_key="291422e57f5335e311fe5fc0a6efaab7"):
        super().__init__()
        # Inicjalizacja API
        self.api = WeatherAPI(api_key)
        
        # Cache dla danych
        self.weather_cache = {}
        self.forecast_cache = {}
        self.historical_cache = {}
        
        # Okres ważności danych w cache (w sekundach)
        self.cache_lifetime = 10 * 60  # 10 minut
        
    def get_weather_data(self, city, callback=None):
        """
        Pobiera aktualne dane pogodowe dla miasta.
        Używa cache jeśli dane są aktualne.
        
        Args:
            city (str): Nazwa miasta
            callback (function, optional): Funkcja wywoływana po otrzymaniu danych
        """
        if not city:
            error_data = {"success": False, "message": "Nie podano nazwy miasta"}
            if callback:
                callback(error_data)
            else:
                self.weather_data_ready.emit(error_data)
            return
        
        # Sprawdzenie cache
        if city in self.weather_cache:
            cache_entry = self.weather_cache[city]
            cache_time = cache_entry.get('timestamp')
            current_time = datetime.now()
            
            # Jeśli dane są aktualne
            if cache_time and (current_time - cache_time).total_seconds() < self.cache_lifetime:
                if callback:
                    callback(cache_entry['data'])
                else:
                    self.weather_data_ready.emit(cache_entry['data'])
                return
        
        # Uruchomienie wątku pobierającego dane
        def fetch_worker():
            try:
                # Pobieranie danych
                data = self.api.get_weather_data(city)
                
                # Dodanie danych wymaganych przez interfejs
                if data.get('success', False):
                    # Dodanie czasu pobrania
                    data['timestamp'] = datetime.now()
                    
                    # Dodanie ID pogody
                    if 'weather' in data and 'main' in data['weather']:
                        weather_main = data['weather']['main'].lower()
                        
                        if 'thunderstorm' in weather_main:
                            data['weather_id'] = 200
                        elif 'drizzle' in weather_main or 'rain' in weather_main:
                            data['weather_id'] = 300
                        elif 'snow' in weather_main:
                            data['weather_id'] = 600
                        elif 'mist' in weather_main or 'fog' in weather_main:
                            data['weather_id'] = 700
                        elif 'clear' in weather_main:
                            data['weather_id'] = 800
                        elif 'cloud' in weather_main:
                            data['weather_id'] = 801
                        else:
                            data['weather_id'] = 800
                
                # Aktualizacja cache
                self.weather_cache[city] = {
                    'data': data,
                    'timestamp': datetime.now()
                }
                
                # Wywołanie callback lub emisja sygnału
                if callback:
                    callback(data)
                else:
                    self.weather_data_ready.emit(data)
                    
            except Exception as e:
                error_data = {"success": False, "message": f"Błąd: {str(e)}"}
                if callback:
                    callback(error_data)
                else:
                    self.error_occurred.emit(str(e))
                    self.weather_data_ready.emit(error_data)
        
        # Uruchomienie w tle
        thread = threading.Thread(target=fetch_worker)
        thread.daemon = True
        thread.start()
        
    def get_forecast_data(self, city, callback=None):
        """
        Pobiera dane prognozy dla miasta.
        Używa cache jeśli dane są aktualne.
        
        Args:
            city (str): Nazwa miasta
            callback (function, optional): Funkcja wywoływana po otrzymaniu danych
        """
        if not city:
            error_data = {"success": False, "message": "Nie podano nazwy miasta"}
            if callback:
                callback(error_data)
            else:
                self.forecast_data_ready.emit(error_data)
            return
        
        # Sprawdzenie cache
        if city in self.forecast_cache:
            cache_entry = self.forecast_cache[city]
            cache_time = cache_entry.get('timestamp')
            current_time = datetime.now()
            
            # Jeśli dane są aktualne
            if cache_time and (current_time - cache_time).total_seconds() < self.cache_lifetime:
                if callback:
                    callback(cache_entry['data'])
                else:
                    self.forecast_data_ready.emit(cache_entry['data'])
                return
        
        # Uruchomienie wątku pobierającego dane
        def fetch_worker():
            try:
                # Pobieranie danych
                data = self.api.get_forecast_data(city)
                
                # Rozszerzenie danych dla interfejsu
                if data.get('success', False):
                    # Dodanie czasu pobrania
                    data['timestamp'] = datetime.now()
                    
                    # Przygotowanie danych dla różnych widoków prognozy
                    self._prepare_forecast_views(data)
                
                # Aktualizacja cache
                self.forecast_cache[city] = {
                    'data': data,
                    'timestamp': datetime.now()
                }
                
                # Wywołanie callback lub emisja sygnału
                if callback:
                    callback(data)
                else:
                    self.forecast_data_ready.emit(data)
                    
            except Exception as e:
                error_data = {"success": False, "message": f"Błąd: {str(e)}"}
                if callback:
                    callback(error_data)
                else:
                    self.error_occurred.emit(str(e))
                    self.forecast_data_ready.emit(error_data)
        
        # Uruchomienie w tle
        thread = threading.Thread(target=fetch_worker)
        thread.daemon = True
        thread.start()
        
    def get_historical_data(self, city, days=30, callback=None):
        """
        Pobiera dane historyczne dla miasta.
        
        Args:
            city (str): Nazwa miasta
            days (int): Liczba dni wstecz
            callback (function, optional): Funkcja wywoływana po otrzymaniu danych
        """
        # W rzeczywistej implementacji tutaj byłoby pobieranie danych historycznych z API
        # Na potrzeby demonstracji generujemy przykładowe dane
        
        import random
        import numpy as np
        
        # Klucz cache dla miasta i liczby dni
        cache_key = f"{city}_{days}"
        
        # Sprawdzenie cache
        if cache_key in self.historical_cache:
            cache_entry = self.historical_cache[cache_key]
            cache_time = cache_entry.get('timestamp')
            current_time = datetime.now()
            
            # Jeśli dane są aktualne
            if cache_time and (current_time - cache_time).total_seconds() < self.cache_lifetime:
                if callback:
                    callback(cache_entry['data'])
                else:
                    self.historical_data_ready.emit(cache_entry['data'])
                return
        
        # Generowanie przykładowych danych historycznych
        def generate_historical_data():
            try:
                # Przygotowanie dat
                end_date = datetime.now()
                start_date = end_date - timedelta(days=days)
                
                dates = []
                temps = []
                
                # Generowanie danych dzień po dniu
                current_date = start_date
                while current_date <= end_date:
                    dates.append(current_date.strftime('%Y-%m-%d'))
                    
                    # Bazowa temperatura z losowymi wahaniami
                    base_temp = 15 + 10 * np.sin(np.pi * (current_date.month - 1) / 6)
                    random_fluctuation = random.uniform(-3, 3)
                    temp = base_temp + random_fluctuation
                    
                    temps.append(round(temp, 1))
                    current_date += timedelta(days=1)
                
                # Przygotowanie odpowiedzi
                data = {
                    'success': True,
                    'city': city,
                    'days': days,
                    'start_date': start_date.strftime('%Y-%m-%d'),
                    'end_date': end_date.strftime('%Y-%m-%d'),
                    'dates': dates,
                    'temperatures': temps,
                    'timestamp': datetime.now()
                }
                
                # Aktualizacja cache
                self.historical_cache[cache_key] = {
                    'data': data,
                    'timestamp': datetime.now()
                }
                
                # Wywołanie callback lub emisja sygnału
                if callback:
                    callback(data)
                else:
                    self.historical_data_ready.emit(data)
                    
            except Exception as e:
                error_data = {"success": False, "message": f"Błąd: {str(e)}"}
                if callback:
                    callback(error_data)
                else:
                    self.error_occurred.emit(str(e))
                    self.historical_data_ready.emit(error_data)
        
        # Uruchomienie w tle
        thread = threading.Thread(target=generate_historical_data)
        thread.daemon = True
        thread.start()
        
    def _prepare_forecast_views(self, data):
        """
        Przygotowuje różne widoki danych prognozy dla interfejsu.
        
        Args:
            data (dict): Dane prognozy
        """
        if not data.get('success', False):
            return
            
        forecast = data.get('forecast', [])
        if not forecast:
            return
            
        # Dane godzinowe (przygotowanie)
        hourly_data = []
        
        # Dane dzienne (przygotowanie)
        daily_data = []
        
        # Dane 5-dniowe co 3 godziny (oryginalny format)
        data['five_day'] = forecast
        
        # Wykrycie unikalnych dat
        dates = set()
        for item in forecast:
            date = datetime.strptime(item['date'], '%d.%m.%Y').date()
            dates.add(date)
        
        # Sortowanie dat
        sorted_dates = sorted(dates)
        
        # Agregacja danych dziennych
        for date in sorted_dates:
            date_str = date.strftime('%d.%m.%Y')
            day_items = [item for item in forecast if date_str in item['date']]
            
            if day_items:
                # Obliczanie średnich, min, max dla dnia
                temp_min = min(item['temp_min'] for item in day_items)
                temp_max = max(item['temp_max'] for item in day_items)
                avg_humidity = sum(item['humidity'] for item in day_items) / len(day_items)
                avg_pressure = sum(item['pressure'] for item in day_items) / len(day_items)
                avg_wind = sum(item['wind_speed'] for item in day_items) / len(day_items)
                
                # Znajdowanie najczęstszego opisu
                descriptions = [item['description'] for item in day_items]
                description = max(set(descriptions), key=descriptions.count)
                
                # Znajdowanie najczęstszej ikony
                icons = [item['icon'] for item in day_items]
                icon = max(set(icons), key=icons.count)
                
                # Tworzenie wpisu dziennego
                daily_entry = {
                    'date': date_str,
                    'day_name': date.strftime('%A'),  # Nazwa dnia tygodnia
                    'temp_min': temp_min,
                    'temp_max': temp_max,
                    'humidity': avg_humidity,
                    'pressure': avg_pressure,
                    'wind_speed': avg_wind,
                    'description': description,
                    'icon': icon
                }
                
                daily_data.append(daily_entry)
        
        # Dane godzinowe - symulacja na podstawie dostępnych danych
        current_hour = datetime.now().hour
        current_day = datetime.now().date()
        
        # Generowanie danych godzinowych na podstawie dostępnych danych
        for hour in range(24):
            target_hour = (current_hour + hour) % 24
            target_time = datetime.combine(current_day, datetime.min.time()) + timedelta(hours=target_hour)
            
            if hour > 0 and target_hour == 0:
                # Przejście do następnego dnia
                current_day += timedelta(days=1)
            
            # Znalezienie najbliższych danych z prognozy
            closest_items = []
            for item in forecast:
                item_date = datetime.strptime(item['date'], '%d.%m.%Y').date()
                if item_date == current_day:
                    closest_items.append(item)
            
            if closest_items:
                # Obliczenie temperatury na podstawie dostępnych danych
                # Proste przybliżenie na podstawie min/max i godziny
                day_item = closest_items[0]  # Używamy pierwszego dostępnego
                
                # Temperatura zmienia się sinusoidalnie w ciągu dnia
                # Min o 3-4 nad ranem, max o 14-15
                hour_factor = ((target_hour - 4) % 24) / 24  # 0 o 4 rano, 0.5 o 16
                temp_range = day_item['temp_max'] - day_item['temp_min']
                temp = day_item['temp_min'] + temp_range * (0.5 - 0.5 * np.cos(2 * np.pi * hour_factor))
                
                # Tworzenie wpisu godzinowego
                hourly_entry = {
                    'date': current_day.strftime('%d.%m.%Y'),
                    'time': f"{target_hour:02d}:00",
                    'temp': round(temp, 1),
                    'humidity': day_item['humidity'],
                    'pressure': day_item['pressure'],
                    'wind_speed': day_item['wind_speed'],
                    'description': day_item['description'],
                    'icon': day_item['icon'],
                    'pop': 0.0  # Prawdopodobieństwo opadów (brak danych, ustawiamy 0)
                }
                
                hourly_data.append(hourly_entry)
        
        # Dodanie danych do wyniku
        data['hourly'] = hourly_data
        data['daily'] = daily_data