import requests
from datetime import datetime, timedelta


class WeatherAPI:
    def __init__(self, api_key="291422e57f5335e311fe5fc0a6efaab7"):
        """
        Inicjalizacja klienta API pogodowego.

        Args:
            api_key (str): Klucz API do OpenWeatherMap
        """
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"
        self.forecast_url = "https://api.openweathermap.org/data/2.5/forecast"

    def get_weather_data(self, city, language="pl"):
        """
        Pobieranie danych pogodowych dla podanego miasta.

        Args:
            city (str): Nazwa miasta
            language (str): Język odpowiedzi ('pl' lub 'en')

        Returns:
            dict: Dane pogodowe lub informacja o błędzie
        """
        if not city:
            return {
                "success": False,
                "message": "Nie podano nazwy miasta" if language == "pl" else "City name not provided"
            }

        try:
            # Parametry zapytania
            params = {
                "q": city,
                "appid": self.api_key,
                "units": "metric",  # Jednostki metryczne (Celsjusz)
                "lang": language  # Język dla opisów
            }

            # Wysłanie zapytania
            response = requests.get(self.base_url, params=params)

            # Sprawdzenie kodu odpowiedzi
            if response.status_code == 200:
                data = response.json()

                # Formatowanie danych pogodowych
                weather_info = {
                    "success": True,
                    "city": data["name"],
                    "country": data["sys"]["country"],
                    "temperature": {
                        "current": round(data["main"]["temp"], 1),
                        "feels_like": round(data["main"]["feels_like"], 1),
                        "min": round(data["main"]["temp_min"], 1),
                        "max": round(data["main"]["temp_max"], 1)
                    },
                    "weather": {
                        "main": data["weather"][0]["main"],
                        "description": data["weather"][0]["description"],
                        "icon": data["weather"][0]["icon"]
                    },
                    "wind": {
                        "speed": data["wind"]["speed"],
                        "degrees": data.get("wind", {}).get("deg", 0)
                    },
                    "humidity": data["main"]["humidity"],
                    "pressure": data["main"]["pressure"],
                    "clouds": data["clouds"]["all"],
                    "sunrise": self._format_time(data["sys"]["sunrise"]),
                    "sunset": self._format_time(data["sys"]["sunset"]),
                    "timezone": data["timezone"],
                    "language": language  # Zapisujemy język zapytania
                }

                return weather_info

            else:
                # Obsługa błędów API
                if response.status_code == 404:
                    return {
                        "success": False,
                        "message": f"Nie znaleziono miasta: {city}" if language == "pl" else f"City not found: {city}"
                    }
                elif response.status_code == 401:
                    return {
                        "success": False,
                        "message": "Nieprawidłowy klucz API" if language == "pl" else "Invalid API key"
                    }
                else:
                    return {
                        "success": False,
                        "message": f"Błąd API: {response.status_code}" if language == "pl" else f"API Error: {response.status_code}"
                    }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Błąd połączenia: {str(e)}" if language == "pl" else f"Connection error: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Wystąpił nieoczekiwany błąd: {str(e)}" if language == "pl" else f"An unexpected error occurred: {str(e)}"
            }

    def get_forecast_data(self, city, days=5, language="pl"):
        """
        Pobieranie prognozy pogodowej na kilka dni dla podanego miasta.

        Args:
            city (str): Nazwa miasta
            days (int): Liczba dni prognozy (max 5 dla darmowego API)
            language (str): Język odpowiedzi ('pl' lub 'en')

        Returns:
            dict: Dane prognozy lub informacja o błędzie
        """
        if not city:
            return {
                "success": False,
                "message": "Nie podano nazwy miasta" if language == "pl" else "City name not provided"
            }

        try:
            # Parametry zapytania
            params = {
                "q": city,
                "appid": self.api_key,
                "units": "metric",  # Jednostki metryczne (Celsjusz)
                "lang": language  # Język dla opisów
            }

            # Wysłanie zapytania
            response = requests.get(self.forecast_url, params=params)

            # Sprawdzenie kodu odpowiedzi
            if response.status_code == 200:
                data = response.json()

                # Grupowanie danych prognozy po dniach
                forecast_days = {}
                for item in data['list']:
                    dt = datetime.fromtimestamp(item['dt'])
                    day_key = dt.strftime('%Y-%m-%d')

                    if day_key not in forecast_days:
                        forecast_days[day_key] = []

                    forecast_days[day_key].append(item)

                # Formatowanie danych prognozy po dniach
                forecast_data = []
                for day_key, items in sorted(forecast_days.items())[:days]:
                    day_data = {
                        "date": datetime.strptime(day_key, '%Y-%m-%d').strftime('%d.%m.%Y'),
                        "temp_min": min(item['main']['temp_min'] for item in items),
                        "temp_max": max(item['main']['temp_max'] for item in items),
                        "humidity": sum(item['main']['humidity'] for item in items) / len(items),
                        "pressure": sum(item['main']['pressure'] for item in items) / len(items),
                        "wind_speed": sum(item['wind']['speed'] for item in items) / len(items),
                        "description": self._get_most_common([item['weather'][0]['description'] for item in items]),
                        "icon": self._get_most_common([item['weather'][0]['icon'] for item in items]),
                        "clouds": sum(item['clouds']['all'] for item in items) / len(items)
                    }
                    forecast_data.append(day_data)

                return {
                    "success": True,
                    "city": data['city']['name'],
                    "country": data['city']['country'],
                    "forecast": forecast_data,
                    "language": language  # Zapisujemy język zapytania
                }
            else:
                # Obsługa błędów API
                if response.status_code == 404:
                    return {
                        "success": False,
                        "message": f"Nie znaleziono miasta: {city}" if language == "pl" else f"City not found: {city}"
                    }
                elif response.status_code == 401:
                    return {
                        "success": False,
                        "message": "Nieprawidłowy klucz API" if language == "pl" else "Invalid API key"
                    }
                else:
                    return {
                        "success": False,
                        "message": f"Błąd API: {response.status_code}" if language == "pl" else f"API Error: {response.status_code}"
                    }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Błąd połączenia: {str(e)}" if language == "pl" else f"Connection error: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Wystąpił nieoczekiwany błąd: {str(e)}" if language == "pl" else f"An unexpected error occurred: {str(e)}"
            }

    def _get_most_common(self, items):
        """
        Zwraca najczęściej występujący element z listy.

        Args:
            items (list): Lista elementów

        Returns:
            object: Najczęściej występujący element
        """
        counts = {}
        for item in items:
            if item in counts:
                counts[item] += 1
            else:
                counts[item] = 1

        return max(counts.items(), key=lambda x: x[1])[0]

    def _format_time(self, timestamp):
        """
        Formatowanie znacznika czasu unix na czytelny format.

        Args:
            timestamp (int): Czas w formacie unix

        Returns:
            str: Sformatowany czas (HH:MM:SS)
        """
        return datetime.fromtimestamp(timestamp).strftime("%H:%M:%S")

    def format_weather_message(self, weather_data, language=None):
        """
        Formatowanie danych pogodowych do czytelnej wiadomości tekstowej.

        Args:
            weather_data (dict): Dane pogodowe z metody get_weather_data
            language (str, optional): Język odpowiedzi ('pl' lub 'en') - jeśli None, używany jest język z danych

        Returns:
            str: Sformatowana wiadomość z informacjami o pogodzie
        """
        if not weather_data.get("success", False):
            # Użyj języka z parametru, a jeśli nie jest określony, domyślnie polski
            lang = language or "pl"
            return weather_data.get("message", "Error retrieving weather data" if lang == "en" else "Błąd pobierania danych pogodowych")

        # Użyj języka z parametru, a jeśli nie jest określony, sprawdź język danych
        lang = language or weather_data.get("language", "pl")

        # Formatowanie wiadomości w zależności od języka
        if lang == "en":
            message = (
                f"📍 Weather for: {weather_data['city']}, {weather_data['country']}\n\n"
                f"🌡️ Temperature: {weather_data['temperature']['current']}°C\n"
                f"   (feels like: {weather_data['temperature']['feels_like']}°C)\n"
                f"   min: {weather_data['temperature']['min']}°C, "
                f"max: {weather_data['temperature']['max']}°C\n\n"
                f"☁️ {weather_data['weather']['description'].capitalize()}\n"
                f"💧 Humidity: {weather_data['humidity']}%\n"
                f"🌫️ Cloudiness: {weather_data['clouds']}%\n"
                f"🌬️ Wind: {weather_data['wind']['speed']} m/s\n"
                f"🧭 Pressure: {weather_data['pressure']} hPa\n\n"
                f"🌅 Sunrise: {weather_data['sunrise']}\n"
                f"🌇 Sunset: {weather_data['sunset']}"
            )
        else:
            message = (
                f"📍 Pogoda dla: {weather_data['city']}, {weather_data['country']}\n\n"
                f"🌡️ Temperatura: {weather_data['temperature']['current']}°C\n"
                f"   (odczuwalna: {weather_data['temperature']['feels_like']}°C)\n"
                f"   min: {weather_data['temperature']['min']}°C, "
                f"max: {weather_data['temperature']['max']}°C\n\n"
                f"☁️ {weather_data['weather']['description'].capitalize()}\n"
                f"💧 Wilgotność: {weather_data['humidity']}%\n"
                f"🌫️ Zachmurzenie: {weather_data['clouds']}%\n"
                f"🌬️ Wiatr: {weather_data['wind']['speed']} m/s\n"
                f"🧭 Ciśnienie: {weather_data['pressure']} hPa\n\n"
                f"🌅 Wschód słońca: {weather_data['sunrise']}\n"
                f"🌇 Zachód słońca: {weather_data['sunset']}"
            )

        return message

    def format_forecast_message(self, forecast_data, language=None):
        """
        Formatowanie danych prognozy do czytelnej wiadomości tekstowej z kompleksową obsługą błędów.

        Args:
            forecast_data (dict): Dane prognozy z metody get_forecast_data
            language (str, optional): Język odpowiedzi ('pl' lub 'en') - jeśli None, używany jest język z danych

        Returns:
            str: Sformatowana wiadomość z prognozą
        """
        try:
            print(f"Formatowanie wiadomości prognozy, język: {language}")

            # Walidacja danych wejściowych
            if not forecast_data:
                error_msg = "Brak danych prognozy" if (language or "pl") == "pl" else "No forecast data"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            if not isinstance(forecast_data, dict):
                error_msg = "Nieprawidłowy format danych prognozy" if (
                                                                                  language or "pl") == "pl" else "Invalid forecast data format"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            # Sprawdź status sukcesu
            if not forecast_data.get("success", False):
                # Użyj języka z parametru, a jeśli nie jest określony, domyślnie polski
                lang = language or "pl"
                error_msg = forecast_data.get("message",
                                              "Error retrieving forecast data" if lang == "en" else "Błąd pobierania danych prognozy")
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            # Upewnij się, że dane prognozy istnieją i są listą
            forecast = forecast_data.get('forecast', [])
            if not forecast:
                lang = language or forecast_data.get("language", "pl")
                error_msg = "No forecast data available" if lang == "en" else "Brak dostępnych danych prognozy"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            if not isinstance(forecast, list):
                lang = language or forecast_data.get("language", "pl")
                error_msg = "Invalid forecast data format (not a list)" if lang == "en" else "Nieprawidłowy format danych prognozy (nie jest listą)"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            if len(forecast) == 0:
                lang = language or forecast_data.get("language", "pl")
                error_msg = "Empty forecast data" if lang == "en" else "Puste dane prognozy"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                return error_msg

            # Pobierz dane i język
            city = forecast_data.get('city', "Unknown")
            country = forecast_data.get('country', "")

            # Użyj języka z parametru, a jeśli nie jest określony, sprawdź język danych
            lang = language or forecast_data.get("language", "pl")

            # Sprawdź integralność danych miasta i kraju
            if not city or city == "Unknown":
                print("OSTRZEŻENIE: Brak lub nieznana nazwa miasta")
                city = "Unknown" if lang == "en" else "Nieznane miasto"

            # Nagłówek wiadomości
            if lang == "en":
                message = f"📆 Forecast for: {city}, {country}\n\n"
            else:
                message = f"📆 Prognoza dla: {city}, {country}\n\n"

            # Dane dla każdego dnia
            for day_index, day in enumerate(forecast):
                try:
                    # Sprawdź, czy dzień prognozy ma wszystkie wymagane dane
                    if not isinstance(day, dict):
                        print(f"OSTRZEŻENIE: Nieprawidłowy format dnia prognozy #{day_index}")
                        continue

                    # Sprawdź obowiązkowe pola
                    required_fields = ['date', 'temp_min', 'temp_max', 'description']

                    missing_fields = [field for field in required_fields if field not in day]
                    if missing_fields:
                        print(f"OSTRZEŻENIE: Brakujące pola w dniu prognozy #{day_index}: {', '.join(missing_fields)}")
                        # Użyj bezpiecznych wartości domyślnych dla brakujących pól
                        if 'date' not in day:
                            day['date'] = f"Day {day_index + 1}"
                        if 'temp_min' not in day:
                            day['temp_min'] = 0
                        if 'temp_max' not in day:
                            day['temp_max'] = 0
                        if 'description' not in day:
                            day['description'] = "No data" if lang == "en" else "Brak danych"

                    # Bezpieczne pobieranie wartości z obsługą błędów
                    date = day.get('date', f"Day {day_index + 1}")

                    # Sprawdź format daty
                    if not isinstance(date, str) or len(date) < 8:  # Minimalna długość daty
                        print(f"OSTRZEŻENIE: Nieprawidłowy format daty: {date}")
                        date = f"Day {day_index + 1}"

                    # Bezpieczne pobieranie i formatowanie wartości liczbowych
                    try:
                        temp_min = float(day.get('temp_min', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość temp_min: {day.get('temp_min')}")
                        temp_min = 0

                    try:
                        temp_max = float(day.get('temp_max', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość temp_max: {day.get('temp_max')}")
                        temp_max = 0

                    try:
                        humidity = float(day.get('humidity', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość humidity: {day.get('humidity')}")
                        humidity = 0

                    try:
                        pressure = float(day.get('pressure', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość pressure: {day.get('pressure')}")
                        pressure = 0

                    try:
                        wind_speed = float(day.get('wind_speed', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość wind_speed: {day.get('wind_speed')}")
                        wind_speed = 0

                    # Bezpieczne pobieranie wartości zachmurzenia
                    try:
                        clouds = float(day.get('clouds', 0))
                    except (TypeError, ValueError):
                        print(f"OSTRZEŻENIE: Nieprawidłowa wartość clouds: {day.get('clouds')}")
                        clouds = 0

                    # Pobierz opis i sprawdź, czy jest stringiem
                    description = day.get('description', "No data" if lang == "en" else "Brak danych")
                    if not isinstance(description, str):
                        print(f"OSTRZEŻENIE: Nieprawidłowy format description: {description}")
                        description = "No data" if lang == "en" else "Brak danych"

                    # Tłumaczenie opisu na angielski jeśli potrzeba
                    if lang == "en" and description != "No data":
                        try:
                            description = self._translate_weather_description(description, 'pl', 'en')
                        except Exception as e:
                            print(f"OSTRZEŻENIE: Błąd tłumaczenia opisu: {str(e)}")
                            # Kontynuuj z oryginalnym opisem

                    # Formatowanie wiadomości w zależności od języka
                    if lang == "en":
                        message += (
                            f"📅 {date}:\n"
                            f"   🌡️ Temp: {temp_min:.1f}°C - {temp_max:.1f}°C\n"
                            f"   ☁️ {description.capitalize()}\n"
                            f"   💧 Humidity: {humidity:.0f}%\n"
                            f"   🧭 Pressure: {pressure:.0f} hPa\n"
                            f"   🌬️ Wind: {wind_speed:.1f} m/s\n"
                            f"   ☁️ Cloudiness: {clouds:.0f}%\n\n"
                        )
                    else:
                        message += (
                            f"📅 {date}:\n"
                            f"   🌡️ Temp: {temp_min:.1f}°C - {temp_max:.1f}°C\n"
                            f"   ☁️ {description.capitalize()}\n"
                            f"   💧 Wilgotność: {humidity:.0f}%\n"
                            f"   🧭 Ciśnienie: {pressure:.0f} hPa\n"
                            f"   🌬️ Wiatr: {wind_speed:.1f} m/s\n"
                            f"   ☁️ Zachmurzenie: {clouds:.0f}%\n\n"
                        )
                except Exception as e:
                    print(f"OSTRZEŻENIE: Błąd przy formatowaniu dnia #{day_index}: {str(e)}")
                    # Kontynuuj z następnym dniem prognozy
                    if lang == "en":
                        message += f"• Error processing forecast for day {day_index + 1}: {str(e)}\n\n"
                    else:
                        message += f"• Błąd przetwarzania prognozy dla dnia {day_index + 1}: {str(e)}\n\n"

            # Sprawdź, czy udało się dodać jakiekolwiek dane do wiadomości
            if message == (
            f"📆 Forecast for: {city}, {country}\n\n" if lang == "en" else f"📆 Prognoza dla: {city}, {country}\n\n"):
                error_msg = "Failed to process any forecast data" if lang == "en" else "Nie udało się przetworzyć żadnych danych prognozy"
                print(f"BŁĄD w format_forecast_message: {error_msg}")
                message += error_msg

            return message

        except Exception as e:
            print(f"BŁĄD w format_forecast_message: {str(e)}")
            import traceback
            traceback.print_exc()

            # Użyj języka z parametru, a jeśli nie jest określony, domyślnie polski
            lang = language or forecast_data.get("language", "pl") if isinstance(forecast_data, dict) else "pl"
            return f"Przepraszam, wystąpił błąd przy formatowaniu prognozy: {str(e)}" if lang == "pl" else f"Sorry, an error occurred while formatting the forecast: {str(e)}"

    def _translate_weather_description(self, description, from_lang, to_lang):
        """
        Prostego tłumaczenie opisów pogody między językami.

        Args:
            description (str): Opis pogody
            from_lang (str): Język źródłowy (pl lub en)
            to_lang (str): Język docelowy (pl lub en)

        Returns:
            str: Przetłumaczony opis
        """
        # Słownik tłumaczeń polsko-angielskich
        pl_to_en = {
            'bezchmurnie': 'clear sky',
            'słonecznie': 'sunny',
            'rozpogodzenia': 'clearing',
            'zachmurzenie małe': 'few clouds',
            'zachmurzenie umiarkowane': 'partly cloudy',
            'zachmurzenie duże': 'mostly cloudy',
            'pochmurno': 'cloudy',
            'mgła': 'fog',
            'mżawka': 'drizzle',
            'słabe opady deszczu': 'light rain',
            'opady deszczu': 'rain',
            'intensywne opady deszczu': 'heavy rain',
            'burza': 'thunderstorm',
            'burza z piorunami': 'thunderstorm with lightning',
            'śnieg': 'snow',
            'śnieg z deszczem': 'sleet',
            'grad': 'hail',
            'zamieć śnieżna': 'snowstorm',
            'mróz': 'frost'
        }

        # Odwrócony słownik dla tłumaczeń angielsko-polskich
        en_to_pl = {v: k for k, v in pl_to_en.items()}

        if from_lang == 'pl' and to_lang == 'en':
            # Obsługa drobnych wariantów tekstu
            description_lower = description.lower()
            for pl_text, en_text in pl_to_en.items():
                if pl_text in description_lower:
                    return en_text
            return description  # Jeśli nie znaleziono, zwróć oryginalny opis

        elif from_lang == 'en' and to_lang == 'pl':
            description_lower = description.lower()
            for en_text, pl_text in en_to_pl.items():
                if en_text in description_lower:
                    return pl_text
            return description

        # Jeśli języki są takie same lub nieznane
        return description

    def format_filtered_forecast(self, forecast_data, time_filter, language=None):
        """
        Formatowanie przefiltrowanych danych prognozy do czytelnej wiadomości tekstowej z obsługą wyjątków.

        Args:
            forecast_data (dict): Dane prognozy z metody get_forecast_data
            time_filter (str): Filtr czasowy ('tomorrow', 'weekend', 'week', 'day_name')
            language (str, optional): Język odpowiedzi ('pl' lub 'en') - jeśli None, używany jest język z danych

        Returns:
            str: Sformatowana wiadomość z przefiltrowaną prognozą
        """
        try:
            print(f"Formatowanie prognozy z filtrem: '{time_filter}', język: {language}")

            # Walidacja danych wejściowych
            if not forecast_data:
                error_msg = "Brak danych prognozy" if language == "pl" else "No forecast data"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            if not isinstance(forecast_data, dict):
                error_msg = "Nieprawidłowy format danych prognozy" if language == "pl" else "Invalid forecast data format"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            if not forecast_data.get("success", False):
                # Użyj języka z parametru, a jeśli nie jest określony, domyślnie polski
                lang = language or "pl"
                error_msg = forecast_data.get("message",
                                              "Błąd pobierania danych prognozy" if lang == "pl" else "Error retrieving forecast data")
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            # Walidacja filtra czasowego
            if not time_filter:
                error_msg = "Nie określono filtra czasowego" if language == "pl" else "Time filter not specified"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            # Użyj języka z parametru, a jeśli nie jest określony, sprawdź język danych
            lang = language or forecast_data.get("language", "pl")

            # Walidacja danych prognozy
            city = forecast_data.get('city')
            if not city:
                error_msg = "Brak nazwy miasta w danych prognozy" if lang == "pl" else "City name missing in forecast data"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            country = forecast_data.get('country')
            if not country:
                print("OSTRZEŻENIE: Brak kodu kraju w danych prognozy")
                country = ""

            forecast = forecast_data.get('forecast')
            if not forecast:
                error_msg = "Brak danych prognozy w odpowiedzi" if lang == "pl" else "No forecast data in response"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            if not isinstance(forecast, list) or len(forecast) == 0:
                error_msg = "Nieprawidłowy format danych prognozy" if lang == "pl" else "Invalid forecast data format"
                print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                return error_msg

            # Dzisiejsza data
            today = datetime.now().date()

            # Nagłówek wiadomości
            if lang == "en":
                message = f"📆 Forecast for: {city}, {country}\n\n"
            else:
                message = f"📆 Prognoza dla: {city}, {country}\n\n"

            # Sprawdź, czy time_filter powinien być przetłumaczony
            # Konwersja angielskich nazw dni na polskie i odwrotnie
            time_filter_map = {
                "tomorrow": "jutro",
                "weekend": "weekend",
                "monday": "poniedziałek", "tuesday": "wtorek", "wednesday": "środa",
                "thursday": "czwartek", "friday": "piątek", "saturday": "sobota", "sunday": "niedziela",
                "poniedziałek": "monday", "wtorek": "tuesday", "środa": "wednesday",
                "czwartek": "thursday", "piątek": "friday", "sobota": "saturday", "niedziela": "sunday"
            }

            # Filtrowanie i formatowanie danych w zależności od filtru
            if time_filter == "tomorrow" or time_filter == "jutro":
                try:
                    # Znajdź prognozę na jutro
                    tomorrow = today + timedelta(days=1)
                    tomorrow_str = tomorrow.strftime('%d.%m.%Y')

                    # Wyszukaj prognozę dla jutra
                    found_forecast = False
                    for day in forecast:
                        if day.get('date') == tomorrow_str:
                            found_forecast = True
                            if lang == "en":
                                message += (
                                    f"📅 Tomorrow ({tomorrow_str}):\n"
                                    f"   🌡️ Temperature: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'No data').capitalize()}\n"
                                    f"   💧 Humidity: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Pressure: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wind: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Cloudiness: {day.get('clouds', 0):.0f}%\n"
                                )
                            else:
                                message += (
                                    f"📅 Jutro ({tomorrow_str}):\n"
                                    f"   🌡️ Temperatura: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'Brak danych').capitalize()}\n"
                                    f"   💧 Wilgotność: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Ciśnienie: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wiatr: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Zachmurzenie: {day.get('clouds', 0):.0f}%\n"
                                )
                            break

                    if not found_forecast:
                        if lang == "en":
                            message += "No forecast found for tomorrow.\n"
                        else:
                            message += "Nie znaleziono prognozy na jutro.\n"
                except Exception as e:
                    print(f"BŁĄD przy formatowaniu prognozy na jutro: {str(e)}")
                    if lang == "en":
                        message += f"Error processing tomorrow's forecast: {str(e)}\n"
                    else:
                        message += f"Błąd przy przetwarzaniu prognozy na jutro: {str(e)}\n"

            elif time_filter == "weekend":
                try:
                    # Znajdź najbliższy weekend
                    days_to_saturday = (5 - today.weekday()) % 7
                    days_to_sunday = (6 - today.weekday()) % 7

                    saturday = today + timedelta(days=days_to_saturday)
                    sunday = today + timedelta(days=days_to_sunday)

                    saturday_str = saturday.strftime('%d.%m.%Y')
                    sunday_str = sunday.strftime('%d.%m.%Y')

                    weekend_found = False

                    # Szukaj prognozy na sobotę
                    for day in forecast:
                        if day.get('date') == saturday_str:
                            weekend_found = True
                            if lang == "en":
                                message += (
                                    f"📅 Saturday ({saturday_str}):\n"
                                    f"   🌡️ Temperature: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'No data').capitalize()}\n"
                                    f"   💧 Humidity: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Pressure: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wind: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Cloudiness: {day.get('clouds', 0):.0f}%\n\n"
                                )
                            else:
                                message += (
                                    f"📅 Sobota ({saturday_str}):\n"
                                    f"   🌡️ Temperatura: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'Brak danych').capitalize()}\n"
                                    f"   💧 Wilgotność: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Ciśnienie: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wiatr: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Zachmurzenie: {day.get('clouds', 0):.0f}%\n\n"
                                )

                    # Szukaj prognozy na niedzielę
                    for day in forecast:
                        if day.get('date') == sunday_str:
                            weekend_found = True
                            if lang == "en":
                                message += (
                                    f"📅 Sunday ({sunday_str}):\n"
                                    f"   🌡️ Temperature: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'No data').capitalize()}\n"
                                    f"   💧 Humidity: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Pressure: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wind: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Cloudiness: {day.get('clouds', 0):.0f}%\n"
                                )
                            else:
                                message += (
                                    f"📅 Niedziela ({sunday_str}):\n"
                                    f"   🌡️ Temperatura: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'Brak danych').capitalize()}\n"
                                    f"   💧 Wilgotność: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Ciśnienie: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wiatr: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Zachmurzenie: {day.get('clouds', 0):.0f}%\n"
                                )

                    if not weekend_found:
                        if lang == "en":
                            message += "No forecast found for the upcoming weekend.\n"
                        else:
                            message += "Nie znaleziono prognozy na najbliższy weekend.\n"
                except Exception as e:
                    print(f"BŁĄD przy formatowaniu prognozy na weekend: {str(e)}")
                    if lang == "en":
                        message += f"Error processing weekend forecast: {str(e)}\n"
                    else:
                        message += f"Błąd przy przetwarzaniu prognozy na weekend: {str(e)}\n"

            elif time_filter.lower() in time_filter_map:
                try:
                    # Mapowanie nazw dni tygodnia na indeksy
                    day_mapping_pl = {
                        "poniedziałek": 0, "wtorek": 1, "środa": 2, "czwartek": 3,
                        "piątek": 4, "sobota": 5, "niedziela": 6
                    }

                    day_mapping_en = {
                        "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
                        "friday": 4, "saturday": 5, "sunday": 6
                    }

                    # Standardyzacja filtra
                    standardized_filter = time_filter.lower()
                    if lang == "en" and standardized_filter in day_mapping_pl:
                        standardized_filter = time_filter_map[standardized_filter]
                    elif lang == "pl" and standardized_filter in day_mapping_en:
                        standardized_filter = time_filter_map[standardized_filter]

                    # Określ indeks dnia tygodnia
                    target_day = -1
                    day_name = ""
                    if standardized_filter in day_mapping_pl:
                        target_day = day_mapping_pl[standardized_filter]
                        day_name_pl = standardized_filter.capitalize()
                        day_name_en = list(day_mapping_en.keys())[target_day].capitalize()
                        day_name = day_name_en if lang == "en" else day_name_pl
                    elif standardized_filter in day_mapping_en:
                        target_day = day_mapping_en[standardized_filter]
                        day_name_pl = list(day_mapping_pl.keys())[target_day].capitalize()
                        day_name_en = standardized_filter.capitalize()
                        day_name = day_name_en if lang == "en" else day_name_pl
                    else:
                        # Jeśli nie znaleziono dnia tygodnia, zwróć komunikat o błędzie
                        error_msg = f"Nieznany filtr czasowy: {time_filter}" if lang == "pl" else f"Unknown time filter: {time_filter}"
                        print(f"BŁĄD w format_filtered_forecast: {error_msg}")
                        return error_msg

                    # Znajdź najbliższy dzień tygodnia o podanej nazwie
                    days_to_target = (target_day - today.weekday()) % 7
                    if days_to_target == 0:  # Jeśli to dzisiaj, szukaj następnego tygodnia
                        days_to_target = 7

                    target_date = today + timedelta(days=days_to_target)
                    target_date_str = target_date.strftime('%d.%m.%Y')

                    # Szukaj prognozy dla danego dnia
                    found_forecast = False
                    for day in forecast:
                        if day.get('date') == target_date_str:
                            found_forecast = True
                            if lang == "en":
                                message += (
                                    f"📅 {day_name} ({target_date_str}):\n"
                                    f"   🌡️ Temperature: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'No data').capitalize()}\n"
                                    f"   💧 Humidity: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Pressure: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wind: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Cloudiness: {day.get('clouds', 0):.0f}%\n"
                                )
                            else:
                                message += (
                                    f"📅 {day_name} ({target_date_str}):\n"
                                    f"   🌡️ Temperatura: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'Brak danych').capitalize()}\n"
                                    f"   💧 Wilgotność: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Ciśnienie: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wiatr: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Zachmurzenie: {day.get('clouds', 0):.0f}%\n"
                                )
                            break

                    if not found_forecast:
                        if lang == "en":
                            message += f"No forecast found for next {day_name}.\n"
                        else:
                            message += f"Nie znaleziono prognozy na najbliższy {day_name}.\n"
                except Exception as e:
                    print(f"BŁĄD przy formatowaniu prognozy dla dnia tygodnia: {str(e)}")
                    if lang == "en":
                        message += f"Error processing forecast for specific day: {str(e)}\n"
                    else:
                        message += f"Błąd przy przetwarzaniu prognozy dla konkretnego dnia: {str(e)}\n"

            else:
                # Domyślnie zwróć prognozę na 3 dni
                try:
                    days_to_show = min(3, len(forecast))

                    # Nazwy dni tygodnia i względne określenia czasowe w obu językach
                    if lang == "en":
                        day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                        today_str = "Today"
                        tomorrow_str = "Tomorrow"
                    else:
                        day_names = ["Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota", "Niedziela"]
                        today_str = "Dziś"
                        tomorrow_str = "Jutro"

                    for i in range(days_to_show):
                        try:
                            day = forecast[i]
                            # Bezpieczne parsowanie daty z obsługą wyjątków
                            try:
                                day_date = datetime.strptime(day.get('date', '01.01.2000'), '%d.%m.%Y').date()
                            except ValueError:
                                print(f"OSTRZEŻENIE: Nieprawidłowy format daty: {day.get('date')}")
                                day_date = today + timedelta(days=i)

                            # Określ dzień tygodnia
                            try:
                                day_name = day_names[day_date.weekday()]
                            except IndexError:
                                print(f"OSTRZEŻENIE: Nieprawidłowy indeks dnia tygodnia: {day_date.weekday()}")
                                day_name = "Unknown" if lang == "en" else "Nieznany"

                            # Określ względny dzień
                            if day_date == today:
                                relative_day = today_str
                            elif day_date == today + timedelta(days=1):
                                relative_day = tomorrow_str
                            else:
                                relative_day = day_name

                            if lang == "en":
                                message += (
                                    f"📅 {relative_day} ({day.get('date', 'No date')}):\n"
                                    f"   🌡️ Temperature: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'No data').capitalize()}\n"
                                    f"   💧 Humidity: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Pressure: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wind: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Cloudiness: {day.get('clouds', 0):.0f}%\n\n"
                                )
                            else:
                                message += (
                                    f"📅 {relative_day} ({day.get('date', 'Brak daty')}):\n"
                                    f"   🌡️ Temperatura: {day.get('temp_min', 0):.1f}°C - {day.get('temp_max', 0):.1f}°C\n"
                                    f"   ☁️ {day.get('description', 'Brak danych').capitalize()}\n"
                                    f"   💧 Wilgotność: {day.get('humidity', 0):.0f}%\n"
                                    f"   🧭 Ciśnienie: {day.get('pressure', 0):.0f} hPa\n"
                                    f"   🌬️ Wiatr: {day.get('wind_speed', 0):.1f} m/s\n"
                                    f"   ☁️ Zachmurzenie: {day.get('clouds', 0):.0f}%\n\n"
                                )
                        except Exception as e:
                            print(f"BŁĄD przy formatowaniu dnia {i}: {str(e)}")
                            # Kontynuuj z pozostałymi dniami
                except Exception as e:
                    print(f"BŁĄD przy formatowaniu domyślnej prognozy: {str(e)}")
                    if lang == "en":
                        message += f"Error processing default forecast: {str(e)}\n"
                    else:
                        message += f"Błąd przy przetwarzaniu domyślnej prognozy: {str(e)}\n"

            return message

        except Exception as e:
            import traceback
            print(f"BŁĄD w format_filtered_forecast dla filtra '{time_filter}': {str(e)}")
            traceback.print_exc()

            # Użyj języka z parametru, a jeśli nie jest określony, domyślnie polski
            lang = language or "pl"
            return f"Przepraszam, wystąpił błąd przy przetwarzaniu prognozy: {str(e)}" if lang == "pl" else f"Sorry, an error occurred while processing the forecast: {str(e)}"