import json
import random
import os
import sys

# Dodajemy aktualny katalog do ścieżki, aby znaleźć moduły
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

from predict import IntentClassifier
from city_extractor import (extract_city, check_if_asking_about_city_list,
                            extract_city_with_context, extract_city_with_context_improved,
                            check_if_asking_about_city_list_multilingual)
from weather_api import WeatherAPI
from utils import get_resource_path


class Chatbot:
    def __init__(self, model_path=None, intents_path=None):
        """
        Inicjalizacja chatbota.

        Args:
            model_path (str): Ścieżka do modelu klasyfikacyjnego
            intents_path (str): Ścieżka do pliku JSON z intencjami
        """
        # Sprawdzenie i dostosowanie ścieżek do plików
        # Jeśli ścieżka jest względna, przekształć ją na absolutną

        if model_path is None:
            model_path = get_resource_path('models/classifier.pkl')

        if intents_path is None:
            intents_path = get_resource_path('data/intents.json')


        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        if not os.path.isabs(model_path):
            model_path = os.path.join(base_dir, model_path)

        if not os.path.isabs(intents_path):
            intents_path = os.path.join(base_dir, intents_path)

        # Sprawdź, czy model istnieje
        if not os.path.exists(model_path):
            print(f"UWAGA: Nie znaleziono modelu w {model_path}. Spróbuję znaleźć alternatywną ścieżkę.")

            # Spróbuj znaleźć model w katalogu src lub w katalogu głównym
            alt_path_src = os.path.join(current_dir, os.path.basename(model_path))
            alt_path_root = os.path.join(base_dir, 'models', os.path.basename(model_path))

            if os.path.exists(alt_path_src):
                model_path = alt_path_src
                print(f"Znaleziono model w {model_path}")
            elif os.path.exists(alt_path_root):
                model_path = alt_path_root
                print(f"Znaleziono model w {model_path}")

        # Załadowanie modelu klasyfikatora intencji
        self.classifier = IntentClassifier(model_path)

        # Inicjalizacja API pogodowego
        self.weather_api = WeatherAPI()

        # Załadowanie intencji i odpowiedzi
        self.intents = {}
        self._load_intents(intents_path)

        # Kontekst rozmowy - przechowywanie informacji o ostatnim mieście
        self.conversation_context = {
            "last_city": None,
            "last_intent": None,
            "session_cities": [],  # Lista miast wspomnianych w bieżącej sesji
            "language": "pl"  # Domyślny język to polski
        }

    def _load_intents(self, intents_path):
        try:
            with open(intents_path, 'r', encoding='utf-8') as file:
                data = json.load(file)

                # Słownik do śledzenia już przetworzonych intentów
                processed_intents = {}

                for intent in data['intents']:
                    tag = intent['tag']

                    # Inicjalizacja lub aktualizacja intentu
                    if tag not in processed_intents:
                        processed_intents[tag] = {
                            'patterns': [],
                            'responses': [],
                            'patterns_en': [],
                            'responses_en': []
                        }

                    # Agreguj wzorce i odpowiedzi
                    processed_intents[tag]['patterns'].extend(intent.get('patterns', []))
                    processed_intents[tag]['responses'].extend(intent.get('responses', []))
                    processed_intents[tag]['patterns_en'].extend(intent.get('patterns_en', []))
                    processed_intents[tag]['responses_en'].extend(intent.get('responses_en', []))

                # Przypisanie do self.intents
                self.intents = processed_intents

                print(f"Załadowano {len(self.intents)} unikalnych intencji")

                # Debugowanie
                for tag, intent_data in self.intents.items():
                    print(f"Intent {tag}:")
                    print(f"  Polskie wzorce: {len(intent_data['patterns'])}")
                    print(f"  Polskie odpowiedzi: {len(intent_data['responses'])}")
                    print(f"  Angielskie wzorce: {len(intent_data['patterns_en'])}")
                    print(f"  Angielskie odpowiedzi: {len(intent_data['responses_en'])}")

        except Exception as e:
            print(f"Błąd podczas ładowania intencji: {str(e)}")
            import traceback
            traceback.print_exc()

    def get_response(self, text):
        """
        Główna metoda przetwarzająca tekst użytkownika i zwracająca odpowiedź.

        Args:
            text (str): Tekst od użytkownika

        Returns:
            str: Odpowiedź chatbota
        """
        if not text:
            return "Nie otrzymałem żadnego tekstu. Jak mogę Ci pomóc?"

        # Wykrywanie języka, jeśli nie jest określony w kontekście
        if not hasattr(self, 'conversation_context'):
            self.conversation_context = {}

        from data_preparation import detect_language
        detected_language = detect_language(text)
        prev_lang = self.conversation_context.get("language", detected_language)

        # Zapisanie języka w kontekście
        self.conversation_context["language"] = detected_language
        print(f"Wykryty język: {detected_language} dla tekstu: '{text}' (poprzedni: {prev_lang})")

        self.last_query = text

        # Sprawdź, czy użytkownik odpowiada na pytanie o wybór miasta
        if self.conversation_context.get("waiting_for_city_selection", False) and self.conversation_context.get(
                "session_cities", []):
            selected_city = check_if_asking_about_city_list_multilingual(
                text,
                self.conversation_context["session_cities"],
                detected_language
            )
            if selected_city:
                self.conversation_context["waiting_for_city_selection"] = False
                self.conversation_context["last_city"] = selected_city

                # Użyj ostatniej intencji z kontekstu lub domyślnie weather
                intent = self.conversation_context.get("last_intent", "weather")
                time_filter = self.conversation_context.get("last_time_filter", None)

                print(
                    f"Użytkownik wybrał miasto: {selected_city}, używam intencji: {intent}, język: {detected_language}")
                response = self._get_response_for_intent(intent, selected_city, time_filter, detected_language)
                return response

        # Klasyfikacja intencji z uwzględnieniem kontekstu
        result = self.classifier.predict_intent(text, self.conversation_context)
        intent = result['intent']
        confidence = result.get('confidence', 0)

        # Wydrukuj wynik klasyfikacji (do debugowania)
        print(
            f"Klasyfikacja: '{text}' -> intencja: '{intent}' z pewnością: {confidence:.4f}, język: {detected_language}")

        # Obsługa intencji weather, forecast, temperature, rain
        if intent in ['weather', 'forecast', 'temperature', 'rain']:
            # Użyj ulepszonej funkcji ekstrakcji miasta z kontekstem
            city = extract_city_with_context_improved(text, self.conversation_context)

            if not city and self.conversation_context.get("last_city") and len(text.split()) <= 5:
                # Dla krótkich zapytań używaj kontekstu ostatniego miasta
                city = self.conversation_context["last_city"]
                print(f"Używam ostatniego miasta z kontekstu: {city}")

            # Jeśli nadal nie znaleziono miasta i mamy listę miast z sesji, zapytaj użytkownika
            if not city and self.conversation_context.get("session_cities", []):
                cities_str = ", ".join(self.conversation_context["session_cities"])
                self.conversation_context["waiting_for_city_selection"] = True
                self.conversation_context["last_intent"] = intent

                if detected_language == "en":
                    return f"I couldn't recognize the city. Are you asking about one of these: {cities_str}? Or specify another city."
                else:
                    return f"Nie udało mi się rozpoznać miasta. Czy chodzi Ci o jedno z tych miast: {cities_str}? Lub podaj inne miasto."

            # Jeśli nadal nie znaleziono miasta, poproś o podanie
            if not city:
                if detected_language == "en":
                    return "I couldn't recognize the city. Please specify a city name, e.g. 'What's the weather in London?'"
                else:
                    return "Nie udało mi się rozpoznać miasta. Podaj proszę nazwę miasta, np. 'Jaka jest pogoda w Warszawie?'"

            # Zapisanie filtru czasowego dla prognozy
            if intent == 'forecast':
                time_filter = self._extract_time_filter(text)
                self.conversation_context["last_time_filter"] = time_filter
            else:
                time_filter = None

            # Generowanie odpowiedzi z przekazaniem języka
            response = self._get_response_for_intent(intent, city, time_filter, detected_language)

            # Aktualizacja kontekstu
            self.conversation_context["last_city"] = city
            self.conversation_context["last_intent"] = intent

            return response

        # Dla pozostałych intencji
        response = self._get_response_for_intent(intent, language=detected_language)
        self.conversation_context["last_intent"] = intent

        return response

    def _get_response_for_intent(self, intent, city=None, time_filter=None, language=None):
        # Kod debugujący
        if intent in self.intents:
            print(f"DEBUG: Intencja '{intent}' ma {len(self.intents[intent].get('responses', []))} odpowiedzi polskich")
            print(
                f"DEBUG: Intencja '{intent}' ma {len(self.intents[intent].get('responses_en', []))} odpowiedzi angielskich")
            print(f"DEBUG: Przykład pierwszej odpowiedzi PL: {self.intents[intent].get('responses', ['brak'])[:1]}")
        else:
            print(f"DEBUG: Intencja '{intent}' nie istnieje w słowniku intencji!")

        """
        Zwraca odpowiedź dla danej intencji z kompleksową obsługą błędów.

        Args:
            intent (str): Rozpoznana intencja
            city (str, optional): Nazwa miasta (dla intencji weather, forecast, temperature, rain)
            time_filter (str, optional): Filtr czasowy dla prognozy (np. 'jutro', 'weekend')
            language (str, optional): Język odpowiedzi ('pl' lub 'en')

        Returns:
            str: Odpowiedź chatbota
        """
        # Jeśli język nie jest określony, pobierz z kontekstu lub ustaw domyślny
        if language is None:
            language = self.conversation_context.get("language", "pl")

        try:
            print(
                f"Generowanie odpowiedzi dla intencji '{intent}', język: {language}, miasto: {city if city else 'brak'}")

            # Obsługa niezdefiniowanych lub pustych intencji
            if not intent:
                error_msg = "Nie określono intencji" if language == "pl" else "Intent not specified"
                print(f"BŁĄD: {error_msg}")
                return error_msg

            # Jeśli mamy do czynienia z intencją pogodową
            if intent == 'weather' and city:
                try:
                    # Pobierz dane pogodowe z przekazaniem języka
                    weather_data = self.weather_api.get_weather_data(city, language=language)

                    # Jeśli udało się pobrać dane pogodowe, zwróć je
                    if weather_data.get("success", False):
                        # Aktualizuj kontekst rozmowy
                        self.conversation_context["last_city"] = city
                        self.conversation_context["last_intent"] = "weather"

                        # Dodaj miasto do listy miast w sesji, jeśli jeszcze nie istnieje
                        if "session_cities" not in self.conversation_context:
                            self.conversation_context["session_cities"] = []

                        if city not in self.conversation_context["session_cities"]:
                            self.conversation_context["session_cities"].append(city)

                        # Dodaj specjalne informacje dla warunków pogodowych
                        weather_description = weather_data.get('weather', {}).get('description', '').lower()
                        original_text_lower = self.last_query.lower() if hasattr(self, 'last_query') else ""

                        # Bardziej precyzyjne sprawdzanie pytań o opady
                        is_asking_about_rain = any(
                            word in original_text_lower for word in
                            ['pada', 'deszcz', 'pada?', 'opady', 'burza', 'śnieg', 'opady', 'rain', 'raining', 'storm',
                             'snow',
                             'precipitation']
                        )

                        is_asking_about_conditions = any(
                            word in original_text_lower for word in
                            ['słońce', 'słonecznie', 'pochmurnie', 'chmury', 'zachmurzenie', 'bezchmurnie', 'sun',
                             'sunny',
                             'cloudy', 'clouds', 'clear']
                        )

                        # Ogólne pytania o pogodę nie powinny dodawać dodatkowych odpowiedzi
                        is_general_weather_question = (
                                ('pogoda' in original_text_lower or 'weather' in original_text_lower) and
                                not is_asking_about_rain and
                                not is_asking_about_conditions
                        )

                        # Dodaj odpowiedź tylko gdy pytanie dotyczy warunków i nie jest ogólnym pytaniem o pogodę
                        if (is_asking_about_rain or is_asking_about_conditions) and not is_general_weather_question:
                            try:
                                # Wywołanie z parametrem języka
                                weather_message = self.weather_api.format_weather_message(weather_data, language)

                                if language == "en":
                                    if 'rain' in weather_description or 'shower' in weather_description:
                                        return weather_message + "\n\nAnswering your question: Yes, it's raining."
                                    elif 'sun' in weather_description or 'clear' in weather_description:
                                        return weather_message + "\n\nAnswering your question: No, it's not raining. It's sunny."
                                    elif 'cloud' in weather_description:
                                        return weather_message + "\n\nAnswering your question: It's not raining, but it's cloudy."
                                    elif 'snow' in weather_description:
                                        return weather_message + "\n\nAnswering your question: Yes, it's snowing."
                                else:
                                    if 'deszcz' in weather_description:
                                        return weather_message + "\n\nOdpowiadając na Twoje pytanie: Tak, pada deszcz."
                                    elif 'słońce' in weather_description or 'bezchmurnie' in weather_description:
                                        return weather_message + "\n\nOdpowiadając na Twoje pytanie: Nie, nie pada. Jest słonecznie."
                                    elif 'chmur' in weather_description:
                                        return weather_message + "\n\nOdpowiadając na Twoje pytanie: Nie pada, ale jest pochmurnie."
                                    elif 'śnieg' in weather_description:
                                        return weather_message + "\n\nOdpowiadając na Twoje pytanie: Tak, pada śnieg."
                            except Exception as e:
                                print(f"BŁĄD przy tworzeniu specjalnej odpowiedzi pogodowej: {str(e)}")
                                import traceback
                                traceback.print_exc()
                                # Kontynuuj z podstawową odpowiedzią pogodową

                        # Jeśli nie pasuje do żadnego z powyższych warunków lub wystąpił błąd
                        try:
                            return self.weather_api.format_weather_message(weather_data, language)
                        except Exception as e:
                            print(f"BŁĄD przy formatowaniu podstawowej wiadomości pogodowej: {str(e)}")
                            import traceback
                            traceback.print_exc()
                            if language == "en":
                                return f"Weather information for {city} is available, but I couldn't format it properly. Error: {str(e)}"
                            else:
                                return f"Informacje pogodowe dla {city} są dostępne, ale nie mogłem ich poprawnie sformatować. Błąd: {str(e)}"
                    else:
                        # W przypadku błędu, zwróć komunikat o błędzie
                        error_msg = weather_data.get('message',
                                                     "Failed to retrieve weather data." if language == "en" else "Nie udało się pobrać danych pogodowych.")
                        print(f"BŁĄD przy pobieraniu danych pogodowych: {error_msg}")
                        return error_msg
                except Exception as e:
                    print(f"BŁĄD przy obsłudze intencji weather dla miasta '{city}': {str(e)}")
                    import traceback
                    traceback.print_exc()
                    if language == "en":
                        return f"Sorry, I encountered an error when processing your weather request for {city}. Error details: {str(e)}"
                    else:
                        return f"Przepraszam, napotkałem błąd podczas przetwarzania Twojego zapytania o pogodę dla {city}. Szczegóły błędu: {str(e)}"

            # Obsługa intencji temperature (dodaj przed intencją 'forecast')
            elif intent == 'temperature' and city:
                try:
                    # Pobierz dane pogodowe
                    weather_data = self.weather_api.get_weather_data(city, language=language)

                    # Jeśli udało się pobrać dane pogodowe
                    if weather_data.get("success", False):
                        # Aktualizuj kontekst rozmowy
                        self.conversation_context["last_city"] = city
                        self.conversation_context["last_intent"] = "temperature"

                        # Dodaj miasto do listy miast w sesji, jeśli jeszcze nie istnieje
                        if "session_cities" not in self.conversation_context:
                            self.conversation_context["session_cities"] = []

                        if city not in self.conversation_context["session_cities"]:
                            self.conversation_context["session_cities"].append(city)

                        # Pobierz dane temperatury
                        temp = weather_data.get('temperature', {}).get('current', 0)
                        feels_like = weather_data.get('temperature', {}).get('feels_like', 0)

                        # W metodzie _get_response_for_intent w chatbot.py dla intencji "temperature"
                        if language == "en":
                            return f"It's {temp}°C in {city} right now, and it feels like {feels_like}°C."
                        else:
                            return f"W {city} jest teraz {temp}°C, a temperatura odczuwalna to {feels_like}°C."
                    else:
                        # Obsługa błędu
                        error_msg = weather_data.get('message',
                                                     "Failed to retrieve temperature data." if language == "en" else "Nie udało się pobrać danych o temperaturze.")
                        print(f"BŁĄD przy pobieraniu danych o temperaturze: {error_msg}")
                        return error_msg
                except Exception as e:
                    print(f"BŁĄD przy obsłudze intencji temperature dla miasta '{city}': {str(e)}")
                    import traceback
                    traceback.print_exc()
                    if language == "en":
                        return f"Sorry, I encountered an error when processing your temperature request for {city}. Error details: {str(e)}"
                    else:
                        return f"Przepraszam, napotkałem błąd podczas przetwarzania Twojego zapytania o temperaturę dla {city}. Szczegóły błędu: {str(e)}"

            # Obsługa intencji rain
            elif intent == 'rain' and city:
                try:
                    # Pobierz dane pogodowe
                    weather_data = self.weather_api.get_weather_data(city, language=language)

                    # Jeśli udało się pobrać dane pogodowe
                    if weather_data.get("success", False):
                        # Aktualizuj kontekst rozmowy
                        self.conversation_context["last_city"] = city
                        self.conversation_context["last_intent"] = "rain"

                        # Dodaj miasto do listy miast w sesji, jeśli jeszcze nie istnieje
                        if "session_cities" not in self.conversation_context:
                            self.conversation_context["session_cities"] = []

                        if city not in self.conversation_context["session_cities"]:
                            self.conversation_context["session_cities"].append(city)

                        # Sprawdź warunki pogodowe
                        weather_description = weather_data.get('weather', {}).get('description', '').lower()
                        weather_main = weather_data.get('weather', {}).get('main', '').lower()

                        # Analiza pogody
                        is_raining = False
                        is_snowing = False

                        # Sprawdź słowa kluczowe dla deszczu/śniegu
                        rain_keywords = ['rain', 'shower', 'drizzle', 'precipitation', 'deszcz', 'mżawka', 'opad',
                                         'pada']
                        snow_keywords = ['snow', 'sleet', 'śnieg', 'śnieżyce', 'śnieży']
                        storm_keywords = ['thunderstorm', 'storm', 'burza', 'nawałnica']

                        if any(keyword in weather_description or keyword in weather_main for keyword in rain_keywords):
                            is_raining = True
                        if any(keyword in weather_description or keyword in weather_main for keyword in snow_keywords):
                            is_snowing = True
                        is_storming = any(
                            keyword in weather_description or keyword in weather_main for keyword in storm_keywords)

                        # Odpowiedź zależna od języka i warunków
                        if language == "en":
                            if is_storming:
                                response = f"Yes, there's a storm in {city} right now. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            elif is_raining:
                                response = f"Yes, it's raining in {city} right now. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            elif is_snowing:
                                response = f"Yes, it's snowing in {city} right now. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            else:
                                response = f"No, it's not raining in {city} right now. Current conditions: {weather_data.get('weather', {}).get('description', '').capitalize()}."
                        else:
                            if is_storming:
                                response = f"Tak, w {city} jest teraz burza. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            elif is_raining:
                                response = f"Tak, w {city} pada deszcz. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            elif is_snowing:
                                response = f"Tak, w {city} pada śnieg. {weather_data.get('weather', {}).get('description', '').capitalize()}."
                            else:
                                response = f"Nie, w {city} nie pada. Aktualne warunki: {weather_data.get('weather', {}).get('description', '').capitalize()}."

                        return response
                    else:
                        # Obsługa błędu
                        error_msg = weather_data.get('message',
                                                     "Failed to check if it's raining in this city." if language == "en" else "Nie udało się sprawdzić, czy pada w tym mieście.")
                        print(f"BŁĄD przy sprawdzaniu opadów: {error_msg}")
                        return error_msg
                except Exception as e:
                    print(f"BŁĄD przy obsłudze intencji rain dla miasta '{city}': {str(e)}")
                    import traceback
                    traceback.print_exc()
                    if language == "en":
                        return f"Sorry, I encountered an error when checking precipitation for {city}. Error details: {str(e)}"
                    else:
                        return f"Przepraszam, napotkałem błąd podczas sprawdzania opadów dla {city}. Szczegóły błędu: {str(e)}"

            # Jeśli mamy do czynienia z intencją prognozy
            elif intent == 'forecast' and city:
                try:
                    # Pobierz dane prognozy
                    forecast_data = self.weather_api.get_forecast_data(city, language=language)

                    # Jeśli udało się pobrać dane prognozy, zwróć je
                    if forecast_data.get("success", False):
                        # Aktualizuj kontekst rozmowy
                        self.conversation_context["last_city"] = city
                        self.conversation_context["last_intent"] = "forecast"

                        # Dodaj miasto do listy miast w sesji, jeśli jeszcze nie istnieje
                        if "session_cities" not in self.conversation_context:
                            self.conversation_context["session_cities"] = []

                        if city not in self.conversation_context["session_cities"]:
                            self.conversation_context["session_cities"].append(city)

                        try:
                            # Filtrowanie prognozy zgodnie z podanym parametrem
                            if time_filter:
                                return self.weather_api.format_filtered_forecast(forecast_data, time_filter, language)
                            else:
                                return self.weather_api.format_forecast_message(forecast_data, language)
                        except Exception as e:
                            print(
                                f"BŁĄD przy formatowaniu prognozy dla miasta '{city}' z filtrem '{time_filter}': {str(e)}")
                            import traceback
                            traceback.print_exc()
                            if language == "en":
                                return f"Forecast data for {city} is available, but I had trouble formatting it: {str(e)}"
                            else:
                                return f"Dane prognozy dla {city} są dostępne, ale miałem problem z ich sformatowaniem: {str(e)}"
                    else:
                        # W przypadku błędu, zwróć komunikat o błędzie
                        error_msg = forecast_data.get('message',
                                                      "Failed to retrieve forecast data." if language == "en" else "Nie udało się pobrać danych prognozy.")
                        print(f"BŁĄD przy pobieraniu danych prognozy: {error_msg}")
                        return error_msg
                except Exception as e:
                    print(f"BŁĄD przy obsłudze intencji forecast dla miasta '{city}': {str(e)}")
                    import traceback
                    traceback.print_exc()
                    if language == "en":
                        return f"Sorry, I encountered an error when processing your forecast request for {city}. Error details: {str(e)}"
                    else:
                        return f"Przepraszam, napotkałem błąd podczas przetwarzania Twojego zapytania o prognozę dla {city}. Szczegóły błędu: {str(e)}"

            # Dla pozostałych intencji zwróć losową odpowiedź
            if intent in self.intents:
                try:
                    # Wybór odpowiedzi w zależności od języka
                    if language == "en" and self.intents[intent].get('responses_en'):
                        responses = self.intents[intent]['responses_en']
                    else:
                        responses = self.intents[intent].get('responses', [])

                    if responses:
                        import random
                        # Wybierz losową odpowiedź
                        response = random.choice(responses)

                        # Zastąp placeholder {city} nazwą miasta, jeśli jest dostępne
                        if city:
                            response = response.replace('{city}', city)
                        elif self.conversation_context.get("last_city") and '{city}' in response:
                            response = response.replace('{city}', self.conversation_context["last_city"])

                        # Rozwiązanie awaryjne - dodaj na końcu metody _get_response_for_intent tuż przed ostatnią instrukcją return
                        # Nawet jeśli wszystko zawiedzie, dla intencji greeting, zwróć odpowiedź polską
                        if intent == "greeting" and language == "pl":
                            return "Cześć! Jak mogę Ci pomóc?"

                        return response
                except Exception as e:
                    print(f"BŁĄD przy obsłudze standardowej intencji '{intent}': {str(e)}")
                    import traceback
                    traceback.print_exc()
                    if language == "en":
                        return f"Sorry, I had trouble generating a response for '{intent}'. Error: {str(e)}"
                    else:
                        return f"Przepraszam, miałem problem z wygenerowaniem odpowiedzi dla '{intent}'. Błąd: {str(e)}"

            # Fallback jeśli nie znaleziono odpowiedzi
            if language == "en":
                return "Sorry, I can't answer that."
            else:
                return "Przepraszam, nie mogę na to odpowiedzieć."

        except Exception as e:
            import traceback
            print(f"BŁĄD przy generowaniu odpowiedzi dla intencji '{intent}' dla miasta '{city}': {str(e)}")
            traceback.print_exc()  # To wydrukuje pełny stack trace

            # Zwróć komunikat o błędzie zamiast pozwolić, by wyjątek się rozprzestrzenił
            if language == "en":
                return f"Sorry, I encountered an error when processing your request. Error details: {str(e)}"
            else:
                return f"Przepraszam, napotkałem błąd podczas przetwarzania Twojego zapytania. Szczegóły błędu: {str(e)}"

    def _extract_time_filter(self, text):
        """
        Wyodrębnij filtr czasowy z tekstu użytkownika.

        Args:
            text (str): Tekst od użytkownika

        Returns:
            str: Filtr czasowy lub None, jeśli nie znaleziono
        """
        text = text.lower()

        # Filtry dla jutra
        if any(phrase in text for phrase in ["jutro", "następny dzień", "kolejny dzień", "na jutro", "pojutrze"]):
            return "tomorrow"

        # Filtry dla weekendu
        if any(phrase in text for phrase in
               ["weekend", "w weekend", "na weekend", "sobota i niedziela", "sobota", "niedziela"]):
            return "weekend"

        # Filtry dla konkretnych dni tygodnia
        days = ["poniedziałek", "wtorek", "środa", "czwartek", "piątek", "sobota", "niedziela"]
        for day in days:
            if day in text:
                return day

        # Filtry dla prognozy długoterminowej
        if any(phrase in text for phrase in ["tydzień", "na tydzień", "za tydzień", "5 dni", "pięć dni",
                                             "długoterminowa", "za 7 dni", "przyszły tydzień"]):
            return "week"

        # Filtry dla najbliższych dni
        if any(phrase in text for phrase in ["najbliższe dni", "następne dni", "kilka dni", "nadchodzące dni",
                                             "za kilka dni", "niedługo", "wkrótce", "za parę dni"]):
            return "next_days"

        # Sprawdź filtry dla konkretnej liczby dni
        for i in range(2, 10):
            if f"za {i} dni" in text or f"za {i} dnia" in text:
                return f"days_{i}"

        return None


if __name__ == "__main__":
    # Test chatbota
    chatbot = Chatbot()

    print("Chatbot uruchomiony. Wpisz 'q' aby zakończyć.")
    while True:
        user_input = input("Ty: ")
        if user_input.lower() == 'q':
            break

        response = chatbot.get_response(user_input)
        print(f"Bot: {response}")