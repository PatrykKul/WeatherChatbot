import json
import os
import sys


def analyze_intents(file_path):
    try:
        # If no path provided, try to find intents.json
        if not file_path or not os.path.exists(file_path):
            # List of potential paths
            potential_paths = [
                'intents.json',
                'data/intents.json',
                '../data/intents.json',
                'src/data/intents.json',
                os.path.join(os.path.dirname(__file__), 'data/intents.json'),
                os.path.join(os.path.dirname(__file__), '../data/intents.json')
            ]

            for path in potential_paths:
                if os.path.exists(path):
                    file_path = path
                    break
            else:
                print("Could not find intents.json. Please provide the full path.")
                return

        print(f"Analyzing intents file: {file_path}")

        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)

        print(f"\nTotal intents: {len(data['intents'])}")

        for intent in data['intents']:
            tag = intent.get('tag', 'UNKNOWN')

            # Check responses
            polish_patterns = intent.get('patterns', [])
            polish_responses = intent.get('responses', [])
            english_patterns_en = intent.get('patterns_en', [])
            english_responses_en = intent.get('responses_en', [])

            print(f"\n--- Intent: {tag} ---")
            print(f"Polish Patterns count: {len(polish_patterns)}")
            print(f"Polish Responses count: {len(polish_responses)}")
            print(f"English Patterns count: {len(english_patterns_en)}")
            print(f"English Responses count: {len(english_responses_en)}")

            # Show first few patterns and responses
            if polish_patterns:
                print("  Sample Polish Patterns:")
                for pattern in polish_patterns[:3]:
                    print(f"    - {pattern}")

            if polish_responses:
                print("  Sample Polish Responses:")
                for response in polish_responses[:3]:
                    print(f"    - {response}")

            if english_patterns_en:
                print("  Sample English Patterns:")
                for pattern in english_patterns_en[:3]:
                    print(f"    - {pattern}")

            if english_responses_en:
                print("  Sample English Responses:")
                for response in english_responses_en[:3]:
                    print(f"    - {response}")

    except Exception as e:
        print(f"Error reading intents file: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Check if path is provided as command-line argument
    file_path = sys.argv[1] if len(sys.argv) > 1 else ''
    analyze_intents(file_path)