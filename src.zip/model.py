import os
import sys
import pickle
import random
import numpy as np
import pandas as pd
import logging
from datetime import datetime
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.utils.class_weight import compute_class_weight
from utils import get_resource_path, ensure_dir_exists

# Dodajemy aktualny katalog do ścieżki, aby znaleźć moduł data_preparation
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

from data_preparation import prepare_training_data, clean_text, detect_language

# Konfiguracja logger'a
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(get_resource_path("logs/model_training.log"), mode='a'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("model_training")


def create_model(balance_classes=True, use_grid_search=False, save_model=True, debug_mode=True):
    """
    Profesjonalna implementacja tworzenia, trenowania i zapisywania modelu klasyfikacyjnego
    dla chatbota pogodowego z obsługą dwóch języków (PL/EN).

    Funkcja implementuje:
    1. Przygotowanie rozbudowanych danych treningowych z wieloma przykładami
    2. Dokładne rozróżnienie między intencjami, zwłaszcza weather vs forecast
    3. Zaawansowane przetwarzanie języka naturalnego
    4. Optymalizację hiperparametrów z Grid Search
    5. Ocenę modelu z kompleksowymi metrykami
    6. Obsługę języka polskiego i angielskiego
    7. Szczegółowe logowanie procesu trenowania

    Args:
        balance_classes (bool): Czy zrównoważyć klasy z wagami
        use_grid_search (bool): Czy używać Grid Search do optymalizacji hiperparametrów
        save_model (bool): Czy zapisać wytrenowany model do pliku
        debug_mode (bool): Czy wyświetlać dodatkowe informacje debugowania

    Returns:
        tuple: (model, accuracy) - wytrenowany model i jego dokładność
    """
    start_time = datetime.now()
    logger.info(f"Rozpoczynanie procesu trenowania modelu - {start_time}")

    try:
        # Przygotowanie danych treningowych z jawnym włączeniem obu języków
        logger.info("Przygotowanie danych treningowych z pliku intents.json")
        documents, classes, words = prepare_training_data(include_languages=['pl', 'en'])

        # Przygotowanie X (wzorce) i y (tagi)
        X = []
        y = []

        for doc, tag in documents:
            # Łączenie tokenów z powrotem w string dla wektoryzerów
            X.append(' '.join(doc))
            y.append(tag)

        logger.info(f"Podstawowe dane treningowe: {len(X)} próbek, {len(set(y))} klas")
        if debug_mode:
            logger.info(f"Rozkład klas: {pd.Series(y).value_counts().to_dict()}")

        # ============================================================
        # ROZBUDOWA DANYCH TRENINGOWYCH - KLUCZOWY ELEMENT ROZWIĄZANIA
        # ============================================================
        logger.info("Rozpoczynam rozbudowę danych treningowych...")

        # 1. DODATKOWE POWITANIA (polskie i angielskie)
        additional_greetings_pl = [
            "cześć", "czesc", "hej", "hello", "siema", "elo", "elka", "yo", "joł",
            "witam", "witaj", "dzien dobry", "dzień dobry", "dobry wieczor", "dobry wieczór",
            "hejka", "hejo", "cze", "siemka", "siemano", "cześć wszystkim", "witajcie",
            "dzień dobry wszystkim", "witan", "czołem", "heja", "hi", "good morning",
            "siemanko", "dryń", "uszanowanko", "powitanie", "pozdrawiam", "halo",
            "howdy", "witam serdecznie", "czesc wam", "serwus", "służę uprzejmie",
            "kłaniam się", "dzień doberek", "co tam", "co słychać", "jak leci",
            "hejo", "buenos dias", "greetings", "miło cię poznać", "dobranoc",
            "yo yo", "siemka ziomki", "elo mordo", "no hej", "cieszę się że jesteś",
            "hej wszyscy", "hej hej", "cieszę się że mogę z Tobą porozmawiać",
            "hej, jestem twoim asystentem pogodowym", "dzień dobry, potrzebujesz informacji pogodowych?"
        ]

        additional_greetings_en = [
            "hello", "hi", "hey", "good morning", "good afternoon", "good evening",
            "greetings", "what's up", "howdy", "yo", "sup", "hi there", "hello there",
            "morning", "afternoon", "evening", "g'day", "hiya", "good day", "hi everyone",
            "hello everyone", "welcome", "hey there", "how are you", "how's it going",
            "pleasure to meet you", "nice to meet you", "well hello", "hello friend",
            "hey buddy", "hello dear", "hi folks", "what's happening", "hola", "bonjour",
            "ciao", "hello world", "hey ya", "hello sunshine", "top of the morning",
            "rise and shine", "hello hello", "hello my friend", "hello weather app",
            "hi weather bot", "hello chatbot", "hello weather assistant", "hi app",
            "start chat", "let's chat", "can we talk", "anyone there?", "bot?",
            "weather assistant?", "are you there?", "hello, need weather information",
            "hi, looking for weather", "good day, checking the weather", "hello! weather question"
        ]

        for greeting in additional_greetings_pl + additional_greetings_en:
            X.append(greeting)
            y.append("greeting")

        # 2. DODATKOWE POŻEGNANIA (polskie i angielskie)
        additional_goodbyes_pl = [
            "do widzenia", "pa", "nara", "do zobaczenia", "żegnaj", "zegnaj", "papa", "bye",
            "do jutra", "spadam", "narazie", "na razie", "do następnego razu", "cześć", "czesc",
            "do później", "adios", "żegnam", "dobranoc", "goodbye", "bye bye", "miłego dnia",
            "dobrego dnia", "muszę już iść", "będę lecieć", "lecę", "kończę", "koniec",
            "do widzenia miłego dnia", "muszę kończyć", "czas się pożegnać", "do usłyszenia",
            "pa pa", "to tyle", "to wszystko", "narazka", "narazicho", "narka", "bywaj",
            "żegnaj się", "kończę rozmowę", "muszę kończyć rozmowę", "to by było na tyle",
            "do następnego", "trzymaj się", "szerokiej drogi", "do rychłego zobaczenia",
            "pozwól że się pożegnam", "znikam", "uciekam", "żegnam się", "kończę na dziś",
            "wystarczy na dziś", "kończymy rozmowę", "chciałbym już skończyć", "dość pytań",
            "wylogowuję się", "to koniec naszej rozmowy", "to tyle z moich pytań"
        ]

        additional_goodbyes_en = [
            "goodbye", "bye", "see you", "later", "farewell", "see you later", "bye bye",
            "so long", "take care", "catch you later", "have a good one", "until next time",
            "see ya", "see you soon", "catch you tomorrow", "have a nice day", "good night",
            "gotta go", "I'm off", "leaving now", "talk to you later", "signing off",
            "cheers", "adios", "ciao", "peace out", "until we meet again", "bye for now",
            "I'm done", "that's all", "exiting", "quit", "terminate", "end session",
            "goodbye for now", "that's it for me", "see you around", "I'll be on my way",
            "time to go", "need to run", "got to dash", "have to leave", "catch you on the flipside",
            "see you next time", "take it easy", "I must depart", "end chat", "catch you later alligator",
            "I bid you adieu", "shutting down", "gotta bounce", "I'm out", "bye bye now",
            "bye bye bye", "see you later", "got to go", "and with that, goodbye",
            "I'm going to leave now", "ending the conversation", "that's enough for today"
        ]

        for goodbye in additional_goodbyes_pl + additional_goodbyes_en:
            X.append(goodbye)
            y.append("goodbye")

        # 3. DODATKOWE PODZIĘKOWANIA (polskie i angielskie)
        additional_thanks_pl = [
            "dzięki", "dziękuję", "dziekuje", "dzieki", "dziekuje bardzo", "dziękuję bardzo",
            "thx", "thanks", "dzięks", "dziękóweczka", "dzieki wielkie", "thank you",
            "dziękuję ci", "dziękuje ci", "wielkie dzięki", "dzięks", "dziex", "dziena",
            "dz", "dzk", "jestem wdzięczny", "jestem wdzieczny", "super dzięki", "dziena",
            "dzięki za pomoc", "dziękuję za informacje", "dzięki za sprawdzenie",
            "dzięki za odpowiedź", "dziękuję za wszystkie informacje", "ogromne dzięki",
            "dzięki za radę", "dzięki stary", "dziękuję bardzo serdecznie", "dziękuję z całego serca",
            "bardzo ci dziękuję", "jestem bardzo wdzięczny", "dziękuję za wskazówki",
            "dzięki wielkie za informację", "dziękuję za szybką odpowiedź", "dzięki za wsparcie",
            "dziękuję za twoją pomoc", "dzięki za wyjaśnienie", "wdzięczny za informację",
            "dziękuję bardzo za szczegóły", "ogromne podziękowania dla ciebie",
            "dziękuję za współpracę", "doceniam twoją pomoc", "bardzo dziękuję za twoją pomoc"
        ]

        additional_thanks_en = [
            "thanks", "thank you", "thank you very much", "thanks a lot", "many thanks",
            "thx", "ty", "thank you so much", "I appreciate it", "much appreciated",
            "thanks for your help", "grateful", "appreciate it", "cheers", "ta",
            "thanks a million", "thank you kindly", "thanks for that", "thank you for",
            "you're the best", "that's very kind", "much obliged", "thanks heaps",
            "thank you for checking", "thanks for the information", "thank you for helping me",
            "thanks for your assistance", "I'm grateful for your help", "thanks for everything",
            "I owe you one", "thank you for taking the time", "many thanks for your support",
            "I can't thank you enough", "I'm indebted", "thanks for the quick response",
            "that was helpful, thanks", "great help, thank you", "thanks for looking into this",
            "thank you for the detailed information", "many thanks for your guidance",
            "thanks a bunch", "thanks for being so helpful", "I really appreciate your help",
            "thank you, that was exactly what I needed", "thanks for the clarification",
            "thank you for the weather information", "thanks for the forecast", "thanks for checking the weather"
        ]

        for thanks in additional_thanks_pl + additional_thanks_en:
            X.append(thanks)
            y.append("thanks")

        # 4. DODATKOWE PYTANIA O POMOC (polskie i angielskie)
        additional_help_pl = [
            "pomoc", "co potrafisz", "jak działa", "opcje", "co umiesz", "instrukcja",
            "jak cię używać", "pokaż funkcje", "możliwości", "co możesz zrobić",
            "jak mogę cię użyć", "funkcje", "polecenia", "komendy",
            "jakie masz możliwości", "co powinienem wiedzieć", "jak mogę uzyskać informacje",
            "jak pytać o pogodę", "jak sprawdzić prognozę", "co umiesz robić",
            "czego mogę się dowiedzieć", "jak uzyskać pomoc", "pokaż instrukcję",
            "pokaż możliwości", "jak korzystać z aplikacji", "jak korzystać z chatbota",
            "wytłumacz jak działa chatbot", "pokaż dostępne opcje", "jak używać bota",
            "nie wiem jak cię używać", "jak mogę zadawać pytania", "jakie dane pokazujesz",
            "jak działa aplikacja", "potrzebuję instrukcji obsługi", "jak skorzystać z aplikacji",
            "jak sprawdzić pogodę", "jak sprawdzić temperaturę", "jak sprawdzić czy pada deszcz",
            "jak sprawdzić prognozę na kilka dni", "jak uzyskać szczegółowe informacje pogodowe",
            "podaj przykłady użycia", "jak mam pytać o pogodę", "jakie polecenia rozumiesz",
            "jakie są twoje funkcje", "co jeszcze potrafisz oprócz pogody", "jak dokładne są twoje dane"
        ]

        additional_help_en = [
            "help", "what can you do", "how does this work", "options", "what are you capable of",
            "instructions", "how to use you", "show features", "capabilities", "what can you help with",
            "how can I use you", "functions", "commands", "guide", "manual", "tutorial",
            "what commands", "help me understand", "show me how", "directions",
            "how to check weather", "how to use this bot", "how do I ask about weather",
            "what can I ask", "what information do you provide", "how detailed is your weather data",
            "what cities do you cover", "what's the best way to use this", "how to get forecast",
            "show me a tutorial", "I need guidance", "how accurate are your forecasts",
            "what weather data do you show", "teach me how to use this app", "list all commands",
            "what functionality do you have", "how to get started", "I'm new here, help",
            "getting started guide", "show me the ropes", "how do I interact with you",
            "how is this supposed to work", "explain your features", "give me some examples",
            "what questions can I ask you", "how do I check current conditions", "how can I check temperature",
            "examples of usage", "how do I get the most from this bot", "explain what this app does"
        ]

        for help_query in additional_help_pl + additional_help_en:
            X.append(help_query)
            y.append("help")

        # 5. DODATKOWE FRAZY SMALLTALK (polskie i angielskie)
        additional_smalltalk_pl = [
            "co robisz", "co słychać", "co u ciebie", "jak leci", "jak się masz", "co tam",
            "jak tam", "co porabiasz", "opowiedz mi coś", "nudzi mi się", "jestem znudzony",
            "pogadajmy", "porozmawiajmy", "powiedz coś ciekawego", "masz jakieś hobby",
            "lubisz pogodę", "jaka jest twoja ulubiona pogoda", "znasz jakiś dowcip",
            "powiedz żart", "jaka pogoda jest najlepsza", "co lubisz robić", "skąd jesteś",
            "gdzie mieszkasz", "czy masz rodzeństwo", "czy lubisz deszcz", "czy lubisz śnieg",
            "czy lubisz lato", "czy lubisz zimę", "czy masz przyjaciół", "co sądzisz o ludziach",
            "jaki jest twój ulubiony kolor", "jaki jest sens istnienia", "czy wierzysz w ufo",
            "jak długo już działasz", "czy się nudzisz", "czy lubisz swoją pracę",
            "co robisz w wolnym czasie", "o czym lubisz rozmawiać", "czy lubisz rozmawiać",
            "jaki jest twój ulubiony sport", "jaki jest twój ulubiony film", "co sądzisz o książkach",
            "opowiedz o sobie coś ciekawego", "jakie masz plany na przyszłość",
            "jak myślisz, jaka będzie pogoda za 100 lat", "opowiedz mi o zmianie klimatu",
            "co wiesz o globalnym ociepleniu", "czy prognozy pogody są dokładne",
            "co myślisz o meteorologach", "co myślisz o swojej pracy"
        ]

        additional_smalltalk_en = [
            "how are you", "what's up", "what's new", "how's it going", "how do you feel",
            "what are you doing", "tell me something", "I'm bored", "let's chat",
            "tell me a joke", "say something funny", "what's your favorite weather",
            "do you like rain", "do you have siblings", "where are you from", "how old are you",
            "tell me about yourself", "what do you like to do", "what's your name",
            "are you a robot", "are you human", "tell me something interesting", "how smart are you",
            "what's your favorite color", "what's your favorite season", "do you like summer",
            "do you like winter", "what do you think about humans", "what's the meaning of life",
            "do you believe in aliens", "how long have you been working", "do you get bored",
            "do you like your job", "what do you do in your free time", "what do you like to talk about",
            "do you enjoy conversations", "what's your favorite sport", "what's your favorite movie",
            "what do you think about books", "tell me something interesting about yourself",
            "what are your plans for the future", "how do you think weather will be in 100 years",
            "tell me about climate change", "what do you know about global warming",
            "are weather forecasts accurate", "what do you think about meteorologists",
            "what's your opinion on your job", "can you tell me a weather fact"
        ]

        for smalltalk in additional_smalltalk_pl + additional_smalltalk_en:
            X.append(smalltalk)
            y.append("smalltalk")

        # 6. DODATKOWE FRAZY ZAPYTAŃ O POGODĘ (polskie i angielskie)
        # Kluczowe rozróżnienie między weather (aktualną) i forecast (przyszłą)

        # 6.1. WYRAŹNE ZAPYTANIA O AKTUALNĄ POGODĘ (WEATHER)
        additional_weather_pl = [
            # Bardzo wyraźne zapytania o AKTUALNĄ pogodę (weather)
            "jaka jest teraz pogoda w Warszawie",
            "jaka jest aktualna pogoda w Krakowie",
            "jaka jest pogoda w tej chwili w Gdańsku",
            "jaka jest obecnie pogoda w Poznaniu",
            "jaka jest dzisiejsza pogoda w Łodzi",
            "pogoda teraz w Szczecinie",
            "obecna pogoda w Bydgoszczy",
            "aktualna pogoda w Lublinie",
            "dzisiaj pogoda w Białymstoku",
            "jaka jest w tej chwili pogoda w Katowicach",
            "czy teraz pada w Gdyni",
            "jak jest dzisiaj w Częstochowie",
            "jakie są aktualne warunki w Radomiu",
            "pogoda na dworze w Sosnowcu",
            "warunki pogodowe teraz w Toruniu",
            "jak jest dzisiaj na dworze w Kielcach",
            "czy obecnie pada deszcz w Rzeszowie",
            "jakie są warunki w tym momencie w Olsztynie",
            "aktualna temperatura w Opolu",
            "jak ciepło jest teraz w Gorzowie",
            "jaka jest teraz pogoda w Zielonej Górze",
            "dzisiejsza temperatura w Koszalinie",
            "jaka jest pogoda obecnie w Płocku",
            "aktualna wilgotność w Gliwicach",
            "jakie jest teraz ciśnienie w Zabrzu",
            "czy w tej chwili wieje w Bytomiu",
            "jaka jest aktualna widoczność w Bielsku-Białej",
            "pogoda w tym momencie w Rudzie Śląskiej",
            "czy w tej chwili świeci słońce w Rybniku",
            "obecne zachmurzenie w Tychach",
            "jak wygląda teraz niebo w Dąbrowie Górniczej",
            "aktualna temperatura odczuwalna w Jastrzębiu-Zdroju",

            # Popularne miasta światowe z wyraźnymi markerami aktualnej pogody
            "jaka jest teraz pogoda w Londynie",
            "aktualna pogoda w Nowym Jorku",
            "jaka jest w tej chwili pogoda w Paryżu",
            "obecna temperatura w Berlinie",
            "dzisiejsza pogoda w Rzymie",
            "jakie są aktualne warunki w Madrycie",
            "czy teraz pada w Tokio",
            "jak jest dzisiaj w Pekinie",
            "pogoda na dworze w Sydney",
            "jaka jest obecnie pogoda w Toronto",
            "jak ciepło jest teraz w Los Angeles",
            "aktualna temperatura w Chicago",
            "jaka jest pogoda w tej chwili w Singapurze",
            "obecne warunki w Moskwie",

            # Pytania o pogodę bez nazwy miasta (trzeba obsłużyć kontekstowo)
            "jaka jest teraz pogoda",
            "aktualna pogoda",
            "pogoda w tej chwili",
            "obecna temperatura",
            "czy teraz pada",
            "jak jest dzisiaj na dworze",
            "aktualne warunki",
            "co się dzieje za oknem",
            "jaka jest pogoda dziś",
            "czy teraz świeci słońce",
            "jakie jest zachmurzenie teraz",
            "jaka jest aktualna wilgotność",
            "jakie jest ciśnienie w tej chwili",
            "czy jest w tej chwili mgła",
            "obecna siła wiatru",

            # Dodatkowe warianty dla różnych miast polskich
            "pogoda aktualnie w Kielcach",
            "obecna aura w Rzeszowie",
            "aktualne zjawiska pogodowe w Toruniu",
            "stan pogody teraz w Radomiu",
            "warunki atmosferyczne obecnie w Sosnowcu",
            "jaka jest teraz aura w Gdyni",
            "czy w tej chwili jest ładnie w Olsztynie",
            "jak się prezentuje niebo teraz w Gliwicach",
            "teraźniejszy stan nieba w Zabrzu",
            "bieżąca temperatura w Bytomiu",
            "aktualna sytuacja pogodowa w Białymstoku",
            "dane pogodowe na teraz dla Rudy Śląskiej",
            "jak się teraz przedstawia pogoda w Tychach",
            "co obecnie pokazują czujniki w Dąbrowie Górniczej",
            "stan powietrza w tej chwili w Płocku",
            "jak wygląda dzisiejsza pogoda w Elblągu"
        ]

        for query in additional_weather_pl:
            X.append(query)
            y.append("weather")  # Intencja 'weather'

        additional_weather_en = [
            # Wyraźne zapytania o AKTUALNĄ pogodę (weather) po angielsku
            "what is the current weather in London",
            "what is the weather right now in New York",
            "how is the weather currently in Paris",
            "current weather in Berlin",
            "weather now in Rome",
            "today's weather in Madrid",
            "present weather conditions in Barcelona",
            "how is the weather at the moment in Amsterdam",
            "what's the current weather like in Prague",
            "weather outside in Vienna",
            "what's happening weather-wise in Budapest",
            "current weather conditions in Athens",
            "how is it outside in Lisbon",
            "what's the weather today in Dublin",
            "present weather in Copenhagen",
            "actual weather in Oslo",
            "what is the temperature right now in Stockholm",
            "current conditions in Helsinki",
            "what's the sky like now in Moscow",
            "weather at this moment in Warsaw",
            "how's the temperature currently in Krakow",
            "what is the present weather in Bucharest",
            "live weather report for Belgrade",
            "weather readings now in Zagreb",
            "what's the weather doing right now in Sofia",
            "current precipitation in Kyiv",
            "present humidity level in Vilnius",
            "weather situation right now in Riga",
            "how's the weather looking today in Tallinn",

            # Popularne miasta światowe z wyraźnymi markerami aktualnej pogody po angielsku
            "what's the current weather in Tokyo",
            "present conditions in Beijing",
            "what is the weather right now in Shanghai",
            "current weather in Hong Kong",
            "today's temperature in Singapore",
            "how is it outside in Sydney",
            "current conditions in Melbourne",
            "what's the weather like now in Cairo",
            "present weather situation in Dubai",
            "how is the sky looking right now in Mumbai",
            "current weather reading in Delhi",
            "what's happening weather-wise in Rio de Janeiro",
            "actual weather conditions in Mexico City",
            "weather at this moment in Buenos Aires",

            # Pytania o pogodę bez nazwy miasta (trzeba obsłużyć kontekstowo) - angielskie
            "what's the current weather",
            "present weather conditions",
            "how is the weather right now",
            "what's the temperature at the moment",
            "is it raining currently",
            "what's it like outside today",
            "current weather reading",
            "what's happening outside",
            "today's weather conditions",
            "is the sun shining now",
            "what's the cloud coverage right now",
            "what's the present humidity",
            "what's the current air pressure",
            "is there fog at the moment",
            "present wind strength",

            # Dodatkowe warianty dla miast po angielsku
            "weather at this time in Chicago",
            "ongoing conditions in Los Angeles",
            "current meteorological data for New York",
            "atmospheric conditions right now in Houston",
            "weather environment presently in Philadelphia",
            "current climate conditions in Phoenix",
            "is it nice outside right now in San Antonio",
            "how's the sky looking presently in San Diego",
            "current state of weather in Dallas",
            "now temperature in San Jose",
            "actual weather situation in Austin",
            "weather data right now for Indianapolis",
            "how's the current weather in Jacksonville",
            "what's the weather showing now in San Francisco",
            "air quality right now in Columbus",
            "what's today's weather like in Fort Worth"
        ]

        for query in additional_weather_en:
            X.append(query)
            y.append("weather")  # Intencja 'weather'

        # 6.2. WYRAŹNE ZAPYTANIA O PROGNOZĘ (FORECAST)
        additional_forecast_pl = [
            # Wyraźne zapytania o PROGNOZĘ (forecast)
            "jaka będzie pogoda jutro w Warszawie",
            "jaka będzie pogoda za tydzień w Krakowie",
            "prognoza na weekend dla Gdańska",
            "pogoda na następne dni w Poznaniu",
            "czy będzie padać w następnym tygodniu w Łodzi",
            "prognoza pogody na jutro dla Szczecina",
            "jak będzie za kilka dni w Bydgoszczy",
            "prognoza długoterminowa dla Lublina",
            "jaka pogoda czeka nas w Białymstoku",
            "pogoda na przyszły tydzień w Katowicach",
            "pogoda jutro w Gdyni",
            "przewidywana pogoda na weekend w Częstochowie",
            "przyszłotygodniowa pogoda w Radomiu",
            "nadchodząca pogoda w Sosnowcu",
            "prognoza na następne 3 dni w Toruniu",
            "czy będzie ciepło w weekend w Kielcach",
            "jaka będzie jutrzejsza temperatura w Rzeszowie",
            "czy będzie padać za 2 dni w Olsztynie",
            "jak będzie się zmieniać pogoda w Opolu",
            "prognoza na najbliższe dni w Gorzowie",
            "jaka będzie pogoda za 3 dni w Zielonej Górze",
            "przewidywana temperatura w przyszłym tygodniu w Koszalinie",
            "czy będzie padać jutro w Płocku",
            "pogoda na weekend w Gliwicach",
            "jaka będzie aura za kilka dni w Zabrzu",
            "prognoza długoterminowa dla Bytomia",
            "pogoda w przyszłym miesiącu w Bielsku-Białej",
            "prognoza na jutro dla Rudy Śląskiej",
            "jaka będzie pogoda pojutrze w Rybniku",
            "czy w weekend będzie słońce w Tychach",
            "pogoda w następnym tygodniu w Dąbrowie Górniczej",
            "prognoza na najbliższe dni dla Jastrzębia-Zdroju",

            # Popularne miasta światowe z wyraźnymi markerami prognozy
            "jaka będzie jutro pogoda w Londynie",
            "pogoda na weekend w Nowym Jorku",
            "prognoza na następny tydzień dla Paryża",
            "jak będzie pogoda za 2 dni w Berlinie",
            "czy będzie padać jutro w Rzymie",
            "pogoda na przyszły tydzień w Madrycie",
            "prognoza długoterminowa dla Tokio",
            "jaka będzie temperatura w weekend w Pekinie",
            "pogoda na następne dni w Sydney",
            "czy będzie słońce jutro w Toronto",
            "jaka będzie pogoda za tydzień w Los Angeles",
            "prognoza na weekend dla Chicago",
            "czy będzie burza w przyszłym tygodniu w Singapurze",
            "pogoda długoterminowa dla Moskwy",

            # Pytania o prognozę bez nazwy miasta (trzeba obsłużyć kontekstowo)
            "jaka będzie jutro pogoda",
            "prognoza na weekend",
            "pogoda na następne dni",
            "czy będzie padać jutro",
            "jaka temperatura będzie za tydzień",
            "jak będzie w przyszłym tygodniu",
            "prognoza długoterminowa",
            "czy będzie słońce w weekend",
            "jak się zmieni pogoda",
            "nadchodząca pogoda",
            "czy będzie ciepło za kilka dni",
            "prognoza na najbliższe dni",
            "czy będzie burza jutro",
            "jaka będzie pogoda za 3 dni",
            "przewidywane warunki pogodowe",

            # Dodatkowe warianty dla różnych miast polskich
            "prognoza pogodowa na jutro dla Kielc",
            "przyszła aura w Rzeszowie",
            "nadchodzące zjawiska pogodowe w Toruniu",
            "przewidywany stan pogody jutro w Radomiu",
            "prognozowane warunki atmosferyczne w Sosnowcu",
            "jaka będzie aura za tydzień w Gdyni",
            "czy będzie ładnie w weekend w Olsztynie",
            "jak będzie wyglądać niebo jutro w Gliwicach",
            "pogoda na najbliższą sobotę w Zabrzu",
            "przewidywana temperatura jutro w Bytomiu",
            "nadchodząca sytuacja pogodowa w Białymstoku",
            "prognoza na 5 dni dla Rudy Śląskiej",
            "jak będzie się prezentować pogoda za kilka dni w Tychach",
            "co przewidują modele pogodowe dla Dąbrowy Górniczej",
            "prognoza stanu powietrza na jutro w Płocku",
            "jak będzie wyglądać jutrzejsza pogoda w Elblągu"
        ]

        for query in additional_forecast_pl:
            X.append(query)
            y.append("forecast")  # Intencja 'forecast'

        additional_forecast_en = [
            # Wyraźne zapytania o PROGNOZĘ (forecast) po angielsku
            "what will the weather be tomorrow in London",
            "weather forecast for New York next week",
            "will it rain in Paris this weekend",
            "Berlin weather for the coming days",
            "weather prediction for Rome",
            "Madrid forecast for tomorrow",
            "what's the weather going to be like in Barcelona",
            "upcoming weather in Amsterdam",
            "Prague weather forecast for the weekend",
            "what will the weather be like in Vienna next week",
            "forecast for the next few days in Budapest",
            "will it be sunny in Athens tomorrow",
            "future weather conditions in Lisbon",
            "Dublin weather next week",
            "Copenhagen forecast for the weekend",
            "weather prediction for Oslo",
            "what will be the temperature tomorrow in Stockholm",
            "forecast conditions for Helsinki",
            "what will the sky be like tomorrow in Moscow",
            "weather prediction for Warsaw",
            "how will the temperature be tomorrow in Krakow",
            "what's the forecast for Bucharest",
            "weather prediction for Belgrade",
            "forecast readings for Zagreb",
            "what will the weather be tomorrow in Sofia",
            "predicted precipitation for Kyiv",
            "future humidity level in Vilnius",
            "weather forecast for Riga",
            "how will the weather be tomorrow in Tallinn",

            # Popularne miasta światowe z wyraźnymi markerami prognozy po angielsku
            "what will the weather be in Tokyo tomorrow",
            "forecast conditions for Beijing",
            "what will the weather be like in Shanghai",
            "weather forecast for Hong Kong",
            "tomorrow's predicted temperature in Singapore",
            "how will it be outside in Sydney",
            "forecast conditions for Melbourne",
            "what will the weather be like tomorrow in Cairo",
            "forecast weather situation in Dubai",
            "how will the sky look tomorrow in Mumbai",
            "weather prediction for Delhi",
            "what's the forecast for Rio de Janeiro",
            "predicted weather conditions in Mexico City",
            "weather forecast for Buenos Aires",

            # Pytania o prognozę bez nazwy miasta (trzeba obsłużyć kontekstowo) - angielskie
            "what will the weather be tomorrow",
            "forecast for the weekend",
            "weather for the coming days",
            "will it rain tomorrow",
            "what temperature will it be next week",
            "how will it be next week",
            "long-term forecast",
            "will there be sun on the weekend",
            "how will the weather change",
            "upcoming weather",
            "will it be warm in a few days",
            "forecast for the next few days",
            "will there be a storm tomorrow",
            "what will the weather be in 3 days",
            "predicted weather conditions",

            # Dodatkowe warianty dla miast po angielsku
            "weather forecast for tomorrow in Chicago",
            "future conditions in Los Angeles",
            "predicted meteorological data for New York",
            "forecasted atmospheric conditions in Houston",
            "predicted weather environment in Philadelphia",
            "forecast climate conditions in Phoenix",
            "will it be nice outside tomorrow in San Antonio",
            "how will the sky look tomorrow in San Diego",
            "predicted state of weather in Dallas",
            "tomorrow's temperature in San Jose",
            "future weather situation in Austin",
            "weather prediction for Indianapolis",
            "how will the weather be in Jacksonville",
            "what will the weather show tomorrow in San Francisco",
            "predicted air quality tomorrow in Columbus",
            "what will tomorrow's weather be like in Fort Worth"
        ]

        for query in additional_forecast_en:
            X.append(query)
            y.append("forecast")  # Intencja 'forecast'

        # 7. PYTANIA O TEMPERATURĘ (polskie i angielskie)
        additional_temperature_pl = [
            "jaka jest temperatura w Warszawie",
            "ile stopni jest w Krakowie",
            "temperatura w Gdańsku",
            "ile stopni pokazuje termometr w Poznaniu",
            "jak ciepło jest w Łodzi",
            "ile jest stopni celsjusza w Szczecinie",
            "jak zimno jest w Bydgoszczy",
            "aktualna temperatura w Lublinie",
            "temperatura teraz w Białymstoku",
            "temperatura powietrza w Katowicach",
            "ile stopni na zewnątrz w Gdyni",
            "ciepło czy zimno w Częstochowie",
            "temperatura dziś w Radomiu",
            "aktualne odczyty temperatur w Sosnowcu",
            "ile jest teraz stopni w Toruniu",
            "jaka jest temperatura odczuwalna w Kielcach",
            "termometr w Rzeszowie",
            "temperatura maksymalna w Olsztynie",
            "temperatura minimalna w Opolu",
            "czy jest ciepło w Gorzowie",
            "czy jest zimno w Zielonej Górze",
            "jaką temperaturę pokazują czujniki w Koszalinie",
            "ile stopni będzie dziś w Płocku",
            "jaka jest średnia temperatura w Gliwicach",
            "temperatura o poranku w Zabrzu",
            "temperatura w południe w Bytomiu",
            "temperatura wieczorem w Bielsku-Białej",
            "wahania temperatury w Rudzie Śląskiej",
            "amplituda temperatury w Rybniku",
            "temperatura w ciągu dnia w Tychach",
            "najwyższa temperatura w Dąbrowie Górniczej",
            "najniższa temperatura w Jastrzębiu-Zdroju"
        ]

        for query in additional_temperature_pl:
            X.append(query)
            y.append("temperature")  # Intencja 'temperature'

        additional_temperature_en = [
            "what's the temperature in London",
            "how many degrees is it in New York",
            "temperature in Paris",
            "what does the thermometer show in Berlin",
            "how warm is it in Rome",
            "how many degrees Celsius in Madrid",
            "how cold is it in Barcelona",
            "current temperature in Amsterdam",
            "temperature now in Prague",
            "air temperature in Vienna",
            "how many degrees outside in Budapest",
            "is it warm or cold in Athens",
            "temperature today in Lisbon",
            "current temperature readings in Dublin",
            "how many degrees is it now in Copenhagen",
            "what's the feels-like temperature in Oslo",
            "thermometer in Stockholm",
            "maximum temperature in Helsinki",
            "minimum temperature in Moscow",
            "is it warm in Warsaw",
            "is it cold in Krakow",
            "what temperature do the sensors show in Bucharest",
            "how many degrees will it be today in Belgrade",
            "what's the average temperature in Zagreb",
            "morning temperature in Sofia",
            "noon temperature in Kyiv",
            "evening temperature in Vilnius",
            "temperature fluctuations in Riga",
            "temperature amplitude in Tallinn",
            "daytime temperature in Tokyo",
            "highest temperature in Beijing",
            "lowest temperature in Shanghai"
        ]

        for query in additional_temperature_en:
            X.append(query)
            y.append("temperature")  # Intencja 'temperature'

        # 8. PYTANIA O DESZCZ/OPADY (polskie i angielskie)
        additional_rain_pl = [
            "czy pada deszcz w Warszawie",
            "czy pada w Krakowie",
            "czy są opady w Gdańsku",
            "czy leje w Poznaniu",
            "czy będzie padać w Łodzi",
            "czy jest ulewa w Szczecinie",
            "pada czy nie pada w Bydgoszczy",
            "czy jest deszczowo w Lublinie",
            "czy pada śnieg w Białymstoku",
            "czy jest burza w Katowicach",
            "czy są burze w Gdyni",
            "czy jest obecnie deszcz w Częstochowie",
            "opady deszczu w Radomiu",
            "opady śniegu w Sosnowcu",
            "burze w Toruniu",
            "czy pada grad w Kielcach",
            "czy jest mżawka w Rzeszowie",
            "czy pada bardzo mocno w Olsztynie",
            "czy będzie ulewa w Opolu",
            "czy zbliża się deszcz do Gorzowa",
            "czy zbliża się burza do Zielonej Góry",
            "kiedy będzie padać w Koszalinie",
            "kiedy przestanie padać w Płocku",
            "czy są jakieś opady w Gliwicach",
            "czy pada jakikolwiek deszcz w Zabrzu",
            "czy są przelotne opady w Bytomiu",
            "czy będą przelotne opady w Bielsku-Białej",
            "czy jest sucho w Rudzie Śląskiej",
            "czy będą jakieś opady w Rybniku",
            "prawdopodobieństwo opadów w Tychach",
            "intensywność opadów w Dąbrowie Górniczej",
            "wielkość opadów w Jastrzębiu-Zdroju"
        ]

        for query in additional_rain_pl:
            X.append(query)
            y.append("rain")  # Intencja 'rain'

        additional_rain_en = [
            "is it raining in London",
            "is it raining in New York",
            "is there precipitation in Paris",
            "is it pouring in Berlin",
            "will it rain in Rome",
            "is there a downpour in Madrid",
            "is it raining or not in Barcelona",
            "is it rainy in Amsterdam",
            "is it snowing in Prague",
            "is there a storm in Vienna",
            "are there storms in Budapest",
            "is it currently raining in Athens",
            "rainfall in Lisbon",
            "snowfall in Dublin",
            "storms in Copenhagen",
            "is it hailing in Oslo",
            "is there drizzle in Stockholm",
            "is it raining heavily in Helsinki",
            "will there be a downpour in Moscow",
            "is rain approaching Warsaw",
            "is a storm approaching Krakow",
            "when will it rain in Bucharest",
            "when will it stop raining in Belgrade",
            "is there any precipitation in Zagreb",
            "is there any rain in Sofia",
            "are there scattered showers in Kyiv",
            "will there be scattered showers in Vilnius",
            "is it dry in Riga",
            "will there be any precipitation in Tallinn",
            "chance of precipitation in Tokyo",
            "rainfall intensity in Beijing",
            "amount of precipitation in Shanghai"
        ]

        for query in additional_rain_en:
            X.append(query)
            y.append("rain")  # Intencja 'rain'

        # 9. PYTANIA FALLBACK (polskie i angielskie)
        additional_fallback_pl = [
            "kompletnie niezrozumiałe zdanie",
            "blablabla",
            "xyz abc",
            "12345",
            "nie wiem co powiedzieć",
            "przyklad tekstu bez sensu",
            "test test test",
            "to nie ma sensu",
            "czy rozumiesz co mówię",
            "jaki jest kolor kwadratu",
            "ile wynosi pierwiastek z 1764",
            "kto wygrał mistrzostwa"
        ]

        additional_fallback_en = [
            "completely incomprehensible sentence",
            "blablabla",
            "xyz abc",
            "12345",
            "I don't know what to say",
            "example of nonsensical text",
            "test test test",
            "this makes no sense",
            "do you understand what I'm saying",
            "what is the color of the square",
            "what is the square root of 1764",
            "who won the championship"
        ]

        for query in additional_fallback_pl + additional_fallback_en:
            X.append(query)
            y.append("fallback")  # Intencja 'fallback'

        logger.info(f"Rozbudowane dane treningowe: {len(X)} próbek, {len(set(y))} klas")
        if debug_mode:
            logger.info(f"Rozkład klas po rozbudowie: {pd.Series(y).value_counts().to_dict()}")

        # ============================================================
        # PODZIAŁ DANYCH I ZRÓWNOWAŻENIE KLAS
        # ============================================================

        # Podział na zbiór treningowy i testowy (stratyfikowany)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        logger.info(f"Zbiór treningowy: {len(X_train)} próbek, testowy: {len(X_test)} próbek")

        # Obliczanie wag klas (więcej wagi dla klas z mniejszą liczbą próbek)
        if balance_classes:
            class_weights = compute_class_weight(
                class_weight='balanced',
                classes=np.unique(y_train),
                y=y_train
            )
            class_weight_dict = {cls: weight for cls, weight in zip(np.unique(y_train), class_weights)}
            logger.info(f"Wagi klas: {class_weight_dict}")
        else:
            class_weight_dict = None

        # ============================================================
        # BUDOWA MODELU Z ZAAWANSOWANYMI FUNKCJAMI
        # ============================================================

        # Stworzenie pipeline'u z wektoryzacją i klasyfikatorem
        logger.info("Tworzenie pipeline'u klasyfikacyjnego")

        # 1. Podstawowy pipeline
        if not use_grid_search:
            pipeline = Pipeline([
                ('vectorizer', TfidfVectorizer(
                    max_features=10000,
                    ngram_range=(1, 4),  # Zwiększamy zakres n-gramów do 4 (ważne dla rozróżniania intencji)
                    analyzer='char_wb',  # Używamy analizy znaków z granicami słów
                    min_df=1,
                    sublinear_tf=True,
                    use_idf=True
                )),
                ('classifier', LogisticRegression(
                    max_iter=5000,  # Zwiększamy liczbę iteracji
                    C=10.0,  # Parametr regularyzacji
                    class_weight=class_weight_dict,  # Wagi klas
                    solver='liblinear',  # Solver
                    multi_class='ovr'  # One-vs-rest
                ))
            ])

            logger.info("Trenowanie modelu podstawowego...")
            pipeline.fit(X_train, y_train)

            # Ocena modelu
            y_pred = pipeline.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)

            # Raport klasyfikacji
            try:
                report = classification_report(y_test, y_pred, zero_division=0)
            except:
                report = classification_report(y_test, y_pred)

            logger.info(f"Dokładność modelu: {accuracy:.4f}")
            logger.info(f"\nRaport klasyfikacji:\n{report}")

            # Macierz pomyłek
            conf_matrix = confusion_matrix(y_test, y_pred)
            logger.info(f"\nMacierz pomyłek:\n{conf_matrix}")

            # Szukanie błędnych klasyfikacji dla analizy
            if debug_mode:
                errors = []
                for i, (true, pred) in enumerate(zip(y_test, y_pred)):
                    if true != pred:
                        errors.append({
                            'text': X_test[i],
                            'true': true,
                            'predicted': pred
                        })

                if errors:
                    logger.info(f"\nPrzykłady błędnych klasyfikacji (max 10):")
                    for i, err in enumerate(errors[:10]):
                        logger.info(
                            f"{i + 1}. Tekst: '{err['text']}', Prawdziwa klasa: '{err['true']}', Przewidywana: '{err['predicted']}'")

                # Szczególnie sprawdzamy błędy między 'weather' a 'forecast'
                weather_forecast_errors = [e for e in errors if
                                           (e['true'] == 'weather' and e['predicted'] == 'forecast') or
                                           (e['true'] == 'forecast' and e['predicted'] == 'weather')]
                if weather_forecast_errors:
                    logger.info(f"\nPrzykłady błędnych klasyfikacji między 'weather' i 'forecast' (max 10):")
                    for i, err in enumerate(weather_forecast_errors[:10]):
                        logger.info(
                            f"{i + 1}. Tekst: '{err['text']}', Prawdziwa klasa: '{err['true']}', Przewidywana: '{err['predicted']}'")

        # 2. Zaawansowany pipeline z Grid Search
        else:
            logger.info("Tworzenie zaawansowanego pipeline'u z Grid Search")

            # Ustawienie parametrów wektoryzeara i klasyfikatora
            pipeline = Pipeline([
                ('vectorizer', TfidfVectorizer()),
                ('classifier', LogisticRegression())
            ])

            # Parametry do optymalizacji z Grid Search
            param_grid = {
                'vectorizer__max_features': [5000, 10000],
                'vectorizer__ngram_range': [(1, 2), (1, 3), (1, 4)],
                'vectorizer__analyzer': ['word', 'char_wb'],
                'vectorizer__min_df': [1, 2],
                'vectorizer__sublinear_tf': [True],
                'classifier__C': [0.1, 1.0, 10.0, 100.0],
                'classifier__solver': ['liblinear', 'saga'],
                'classifier__max_iter': [3000, 5000]
            }

            # Wykonanie Grid Search z walidacją krzyżową
            logger.info("Rozpoczynam Grid Search z walidacją krzyżową (to może potrwać kilka minut)...")

            grid_search = GridSearchCV(
                pipeline,
                param_grid,
                cv=5,  # 5-krotna walidacja krzyżowa
                scoring='accuracy',
                verbose=1,
                n_jobs=-1  # Wykorzystaj wszystkie dostępne rdzenie
            )

            try:
                # Trenowanie modelu
                grid_search.fit(X_train, y_train)

                # Najlepsze parametry
                best_params = grid_search.best_params_
                logger.info(f"Najlepsze parametry: {best_params}")

                # Używamy najlepszego modelu
                pipeline = grid_search.best_estimator_

                # Ocena modelu
                y_pred = pipeline.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)

                # Raport klasyfikacji
                try:
                    report = classification_report(y_test, y_pred, zero_division=0)
                except:
                    report = classification_report(y_test, y_pred)

                logger.info(f"Dokładność modelu po Grid Search: {accuracy:.4f}")
                logger.info(f"\nRaport klasyfikacji:\n{report}")

                # Macierz pomyłek
                conf_matrix = confusion_matrix(y_test, y_pred)
                logger.info(f"\nMacierz pomyłek:\n{conf_matrix}")

                # Wyniki walidacji krzyżowej
                logger.info(f"Wyniki walidacji krzyżowej:")
                for i, score in enumerate(grid_search.cv_results_['mean_test_score']):
                    params = grid_search.cv_results_['params'][i]
                    logger.info(f"Parametry: {params}, Średni wynik: {score:.4f}")

                # Najważniejsze właściwości
                if hasattr(pipeline.named_steps['classifier'], 'coef_'):
                    vectorizer = pipeline.named_steps['vectorizer']
                    classifier = pipeline.named_steps['classifier']

                    feature_names = vectorizer.get_feature_names_out()

                    # Najważniejsze właściwości dla każdej klasy
                    logger.info(f"\nNajważniejsze właściwości dla każdej klasy:")

                    for i, class_label in enumerate(classifier.classes_):
                        if len(classifier.coef_) > i:  # Sprawdzamy, czy mamy odpowiednią liczbę współczynników
                            coefs = classifier.coef_[i]
                            top_features_idx = coefs.argsort()[-20:]  # 20 najważniejszych właściwości

                            top_features = [(feature_names[j], coefs[j]) for j in top_features_idx]
                            top_features.sort(key=lambda x: x[1], reverse=True)

                            logger.info(f"\nKlasa: {class_label}")
                            for feature, coef in top_features:
                                logger.info(f"  - {feature}: {coef:.4f}")

            except Exception as e:
                logger.error(f"Błąd podczas Grid Search: {str(e)}")

                # Fallback do standardowego modelu
                logger.info("Używam standardowego modelu jako fallback")

                pipeline = Pipeline([
                    ('vectorizer', TfidfVectorizer(
                        max_features=10000,
                        ngram_range=(1, 3),
                        analyzer='char_wb',
                        min_df=1,
                        sublinear_tf=True
                    )),
                    ('classifier', LogisticRegression(
                        max_iter=5000,
                        C=10.0,
                        class_weight=class_weight_dict,
                        solver='liblinear',
                        multi_class='ovr'
                    ))
                ])

                pipeline.fit(X_train, y_train)

                # Ocena modelu
                y_pred = pipeline.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)

                try:
                    report = classification_report(y_test, y_pred, zero_division=0)
                except:
                    report = classification_report(y_test, y_pred)

                logger.info(f"Dokładność modelu fallback: {accuracy:.4f}")
                logger.info(f"\nRaport klasyfikacji:\n{report}")

        # ============================================================
        # TESTOWANIE MODELU NA PRZYKŁADOWYCH FRAZACH
        # ============================================================
        logger.info("Testowanie modelu na przykładowych frazach")

        test_phrases_pl = [
            "Cześć", "Dzień dobry", "Hej", "Siema", "Elo", "Witaj", "Joł",
            "Do widzenia", "Pa", "Spadam", "Nara", "Żegnaj", "Do jutra",
            "Dziękuję", "Dzięki", "Dzieki", "dziekuje", "thx", "Dziękuję bardzo",
            # Testowanie rozróżniania weather vs forecast - kluczowe
            "Jaka jest pogoda w Warszawie",
            "Jaka jest teraz pogoda w Warszawie",
            "Jaka będzie pogoda w Warszawie",
            "Jaka będzie jutro pogoda w Warszawie",
            "Pogoda w Krakowie",
            "Aktualna pogoda w Krakowie",
            "Prognoza dla Krakowa",
            "Pogoda w Krakowie na jutro",
            "Temperatura w Gdańsku",
            "Jak ciepło dziś w Łodzi",
            "Jak ciepło będzie jutro w Łodzi",
            "Czy pada w Poznaniu",
            "Czy będzie padać w Poznaniu",
            "Pogoda",
            "Temperatura",
            "Jaka będzie pogoda jutro",
            "Jaka jest pogoda dzisiaj",
            "Prognoza na weekend",
            "Pogoda na dziś"
        ]

        test_phrases_en = [
            "Hello", "Good morning", "Hey", "Hi there", "What's up", "Greetings",
            "Goodbye", "Bye", "See you", "Later", "Farewell", "Till tomorrow",
            "Thank you", "Thanks", "Thx", "Thanks a lot", "Appreciate it",
            # Testing weather vs forecast distinction - critical
            "What's the weather in London",
            "What's the current weather in London",
            "What will the weather be in London",
            "What will the weather be tomorrow in London",
            "Weather in New York",
            "Current weather in New York",
            "Forecast for New York",
            "Weather in New York tomorrow",
            "Temperature in Paris",
            "How warm is it in Berlin",
            "How warm will it be tomorrow in Berlin",
            "Is it raining in Madrid",
            "Will it rain in Madrid",
            "Weather",
            "Temperature",
            "What will the weather be tomorrow",
            "What's the weather today",
            "Forecast for the weekend",
            "Weather for today"
        ]

        logger.info("\nTestowanie modelu na prostych frazach (polskich):")
        test_results_pl = {}

        for phrase in test_phrases_pl:
            # Przeprowadź predykcję
            cleaned_phrase = clean_text(phrase)
            prediction = pipeline.predict([cleaned_phrase])[0]
            probabilities = pipeline.predict_proba([cleaned_phrase])[0]
            best_probability = max(probabilities)

            test_results_pl[phrase] = {
                'prediction': prediction,
                'probability': best_probability
            }

            # Wydrukuj wynik
            logger.info(f"'{phrase}' -> {prediction} (pewność: {best_probability:.4f})")

            # Jeśli pewność jest niska, wyświetl wszystkie prawdopodobieństwa
            if best_probability < 0.5:
                classes = pipeline.classes_
                probs = list(zip(classes, probabilities))
                probs.sort(key=lambda x: x[1], reverse=True)
                logger.info(
                    f"  Wszystkie prawdopodobieństwa: {', '.join([f'{cls}: {prob:.4f}' for cls, prob in probs])}")

        logger.info("\nTestowanie modelu na prostych frazach (angielskich):")
        test_results_en = {}

        for phrase in test_phrases_en:
            # Przeprowadź predykcję
            cleaned_phrase = clean_text(phrase)
            prediction = pipeline.predict([cleaned_phrase])[0]
            probabilities = pipeline.predict_proba([cleaned_phrase])[0]
            best_probability = max(probabilities)

            test_results_en[phrase] = {
                'prediction': prediction,
                'probability': best_probability
            }

            # Wydrukuj wynik
            logger.info(f"'{phrase}' -> {prediction} (confidence: {best_probability:.4f})")

            # Jeśli pewność jest niska, wyświetl wszystkie prawdopodobieństwa
            if best_probability < 0.5:
                classes = pipeline.classes_
                probs = list(zip(classes, probabilities))
                probs.sort(key=lambda x: x[1], reverse=True)
                logger.info(
                    f"  All probabilities: {', '.join([f'{cls}: {prob:.4f}' for cls, prob in probs])}")

        # ============================================================
        # ZAPISANIE MODELU
        # ============================================================
        if save_model:
            try:
                # Określ ścieżkę do zapisu
                model_save_path = get_resource_path('models/classifier.pkl')

                # Upewnij się, że katalog istnieje
                models_dir = os.path.dirname(model_save_path)
                ensure_dir_exists(models_dir)

                # Zapisz model
                with open(model_save_path, 'wb') as f:
                    pickle.dump(pipeline, f)

                logger.info(f"Model zapisany jako '{model_save_path}'")

                # Utworzenie kopii modelu w dodatkowej lokalizacji jako zabezpieczenie
                backup_path = os.path.join(current_dir, 'models', 'classifier_backup.pkl')
                os.makedirs(os.path.dirname(backup_path), exist_ok=True)

                with open(backup_path, 'wb') as f:
                    pickle.dump(pipeline, f)

                logger.info(f"Kopia modelu zapisana jako '{backup_path}'")
            except Exception as e:
                logger.error(f"Błąd podczas zapisywania modelu: {str(e)}")

        end_time = datetime.now()
        training_duration = end_time - start_time
        logger.info(f"Zakończono proces trenowania modelu. Czas trwania: {training_duration}")

        return pipeline, accuracy

    except Exception as e:
        logger.error(f"Wystąpił krytyczny błąd podczas tworzenia modelu: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())

        # Tworzenie bardzo prostego modelu awaryjnego
        logger.info("Tworzenie modelu awaryjnego (fallback)...")

        # Bardzo proste dane treningowe na wypadek awarii
        X = [
            # Polskie przykłady
            "cześć", "hej", "dzień dobry", "witaj", "siema", "elo", "witam", "joł",  # greeting
            "do widzenia", "pa", "żegnaj", "nara", "papa", "bye", "do jutra",  # goodbye
            "pomoc", "co potrafisz", "jak działa", "opcje", "co umiesz",  # help
            "dziękuję", "dzięki", "dzieki", "dziekuje", "thx", "thank you",  # thanks
            "pogoda w warszawie", "temperatura w krakowie", "jaka jest pogoda", "pogoda",
            "czy pada", "temperatura", "stopnie", "ciepło", "zimno",  # weather
            "jaka będzie pogoda jutro", "prognoza na weekend", "czy będzie padać",  # forecast

            # Angielskie przykłady
            "hello", "hi", "good morning", "greetings", "hey", "yo", "what's up",  # greeting
            "goodbye", "bye", "see you", "later", "farewell", "see ya", "until next time",  # goodbye
            "help", "what can you do", "how does this work", "options", "capabilities",  # help
            "thank you", "thanks", "thx", "appreciate it", "grateful",  # thanks
            "weather in london", "temperature in new york", "what's the weather", "weather",
            "is it raining", "temperature", "degrees", "warm", "cold",  # weather
            "what will the weather be tomorrow", "forecast for weekend", "will it rain"  # forecast
        ]

        y = [
            # Polski
            "greeting", "greeting", "greeting", "greeting", "greeting", "greeting", "greeting", "greeting",
            "goodbye", "goodbye", "goodbye", "goodbye", "goodbye", "goodbye", "goodbye",
            "help", "help", "help", "help", "help",
            "thanks", "thanks", "thanks", "thanks", "thanks", "thanks",
            "weather", "weather", "weather", "weather",
            "weather", "weather", "weather", "weather", "weather",
            "forecast", "forecast", "forecast",

            # Angielski
            "greeting", "greeting", "greeting", "greeting", "greeting", "greeting", "greeting",
            "goodbye", "goodbye", "goodbye", "goodbye", "goodbye", "goodbye", "goodbye",
            "help", "help", "help", "help", "help",
            "thanks", "thanks", "thanks", "thanks", "thanks",
            "weather", "weather", "weather", "weather",
            "weather", "weather", "weather", "weather", "weather",
            "forecast", "forecast", "forecast"
        ]

        # Prosty pipeline z TF-IDF i LogisticRegression
        fallback_pipeline = Pipeline([
            ('vectorizer', TfidfVectorizer(ngram_range=(1, 3), analyzer='char_wb')),
            ('classifier', LogisticRegression(max_iter=3000))
        ])

        try:
            fallback_pipeline.fit(X, y)

            # Utworzenie katalogu models, jeśli nie istnieje
            os.makedirs('models', exist_ok=True)

            # Ścieżka względna do katalogu models w katalogu głównym projektu
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            main_models_dir = os.path.join(base_dir, 'models')
            os.makedirs(main_models_dir, exist_ok=True)

            # Zapisanie modelu w obu lokalizacjach dla pewności
            with open('models/classifier.pkl', 'wb') as f:
                pickle.dump(fallback_pipeline, f)

            with open(os.path.join(main_models_dir, 'classifier.pkl'), 'wb') as f:
                pickle.dump(fallback_pipeline, f)

            logger.info("Model fallback zapisany jako 'models/classifier.pkl' i w katalogu głównym projektu")

            return fallback_pipeline, 0.0

        except Exception as nested_e:
            logger.critical(f"Nie udało się utworzyć nawet modelu awaryjnego: {str(nested_e)}")
            return None, 0.0


def test_prediction(model, text):
    """
    Testowa predykcja na podstawie wprowadzonego tekstu.

    Args:
        model: Wytrenowany model
        text (str): Tekst do klasyfikacji

    Returns:
        tuple: (przewidywana_intencja, prawdopodobieństwa)
    """
    if model is None:
        print("Błąd: Model nie jest dostępny.")
        return "fallback", np.array([1.0])

    try:
        # Wykrywanie języka
        language = detect_language(text)
        print(f"Wykryty język: {language}")

        # Czyszczenie i przygotowanie tekstu
        cleaned_text = clean_text(text)
        print(f"Oczyszczony tekst: '{cleaned_text}'")

        # Predykcja
        prediction = model.predict([cleaned_text])[0]
        probabilities = model.predict_proba([cleaned_text])[0]

        # Wydrukowanie wyników
        classes = model.classes_
        probs_sorted = sorted(list(zip(classes, probabilities)), key=lambda x: x[1], reverse=True)

        print("\nWyniki klasyfikacji:")
        print(f"Najlepsze dopasowanie: {prediction} ({max(probabilities):.4f})")
        print("\nWszystkie prawdopodobieństwa:")
        for intent, prob in probs_sorted:
            print(f"{intent}: {prob:.4f}")

        return prediction, probabilities

    except Exception as e:
        print(f"Błąd podczas predykcji: {str(e)}")
        return "fallback", np.array([1.0])


if __name__ == "__main__":
    # Parametry trenowania modelu
    balance_classes = True
    use_grid_search = False  # Ustaw na True, aby użyć Grid Search (zajmie więcej czasu)
    save_model = True
    debug_mode = True

    print("=" * 80)
    print("TRENOWANIE MODELU KLASYFIKACYJNEGO DLA CHATBOTA POGODOWEGO")
    print("=" * 80)

    # Trenowanie modelu
    model, accuracy = create_model(
        balance_classes=balance_classes,
        use_grid_search=use_grid_search,
        save_model=save_model,
        debug_mode=debug_mode
    )

    print(f"\nModel wytrenowany z dokładnością: {accuracy:.4f}")

    # Testowanie predykcji w pętli
    print("\nMożesz teraz testować model. Wpisz 'q' aby zakończyć.")
    while True:
        text = input("\nWprowadź tekst do klasyfikacji: ")
        if text.lower() == 'q':
            break

        prediction, _ = test_prediction(model, text)
        print(f"Przewidywana intencja: {prediction}")