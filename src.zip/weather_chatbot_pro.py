import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QStackedWidget, QPushButton, QLabel, QComboBox)
from PyQt5.QtCore import Qt, QTimer
# Importy własnych modułów
from chat_module import ChatbotWidget
from dashboard_module import WeatherDashboard
from alert_module import AlertModule
from settings_module import SettingsDialog
from particle_system import ParticleSystemManager
from weather_api_wrapper import WeatherAPIService
from sound_module import SoundManager

import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QStackedWidget, QPushButton, QLabel, QComboBox)
from PyQt5.QtCore import Qt, QTimer
# Importy własnych modułów
from chat_module import ChatbotWidget
from dashboard_module import WeatherDashboard
from alert_module import AlertModule
from settings_module import SettingsDialog
from particle_system import ParticleSystemManager
from weather_api_wrapper import WeatherAPIService
from sound_module import SoundManager


class WeatherChatbotPro(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Weather Chatbot Pro")
        self.setMinimumSize(1500, 1000)

        # Dodajemy słowniki tłumaczeń
        self.translations = {
            "pl": {
                "window_title": "Weather Chatbot Pro",
                "chatbot_mode": "Chatbot",
                "dashboard_mode": "Dashboard",
                "city_label": "Miasto:",
                "mute_tooltip": "Wycisz dźwięki",
                "unmute_tooltip": "Włącz dźwięki",
                "settings_tooltip": "Ustawienia",
                "alerts_tooltip": "Alerty",
                "search_tooltip": "Szukaj",
                "last_update": "Ostatnia aktualizacja:",
                "status": "Status:",
                "status_ready": "Gotowy",
                "status_updating": "Pobieranie danych...",
                "status_error": "Błąd",
                "enter_city": "Wprowadź nazwę miasta",
                "error_empty_city": "Wprowadź nazwę miasta",
                "language_button": "EN"  # Gdy język to PL, pokazujemy EN jako opcję zmiany
            },
            "en": {
                "window_title": "Weather Chatbot Pro",
                "chatbot_mode": "Chatbot",
                "dashboard_mode": "Dashboard",
                "city_label": "City:",
                "mute_tooltip": "Mute sounds",
                "unmute_tooltip": "Unmute sounds",
                "settings_tooltip": "Settings",
                "alerts_tooltip": "Alerts",
                "search_tooltip": "Search",
                "last_update": "Last update:",
                "status": "Status:",
                "status_ready": "Ready",
                "status_updating": "Fetching data...",
                "status_error": "Error",
                "enter_city": "Enter city name",
                "error_empty_city": "Enter city name",
                "language_button": "PL"  # Gdy język to EN, pokazujemy PL jako opcję zmiany
            }
        }

        # Domyślny język aplikacji
        self.current_language = "pl"

        # Inicjalizacja menedżera dźwięku
        self.sound_manager = SoundManager()

        # Inicjalizacja usług
        self.weather_service = WeatherAPIService()
        self.particle_manager = ParticleSystemManager(self.width(), self.height())

        # Inicjalizacja UI
        self.init_ui()

        # Inicjalizacja timera animacji
        self.animation_timer = QTimer(self)
        self.animation_timer.timeout.connect(self.update_animation)
        self.animation_timer.start(30)

        # Bieżący kontekst aplikacji
        self.app_context = {
            "current_city": None,
            "current_weather_condition": "clear",
            "recent_cities": [],
            "user_preferences": self.load_user_preferences(),
            "current_language": self.current_language
        }

        # Połączenie sygnałów między modułami
        self.connect_signals()

        # Odtwórz dźwięk waterfall.mp3 automatycznie przy starcie
        self.sound_manager.ambient_playlist.setCurrentIndex(2)  # waterfall.mp3 jest na pozycji 2
        self.sound_manager.ambient_player.play()

    def init_ui(self):
        # Główny widget centralny
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Główny układ
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Pasek tytułowy niestandardowy
        self.title_bar = self.create_title_bar()
        main_layout.addWidget(self.title_bar)
        self.setWindowFlags(Qt.FramelessWindowHint)

        # Pasek narzędzi z przełącznikami trybów
        self.toolbar = self.create_toolbar()
        main_layout.addWidget(self.toolbar)

        # Stos widgetów dla różnych trybów (chat / dashboard)
        self.stacked_widget = QStackedWidget()

        # Tryb chatbota
        self.chat_widget = ChatbotWidget(self.weather_service)

        # Tryb dashboardu (korzysta z UltraWeatherApi)
        self.dashboard_widget = WeatherDashboard(self.weather_service)

        self.setAttribute(Qt.WA_TranslucentBackground)

        # Dodanie widgetów do stosu
        self.stacked_widget.addWidget(self.chat_widget)
        self.stacked_widget.addWidget(self.dashboard_widget)

        # Dodanie do głównego układu
        main_layout.addWidget(self.stacked_widget)

        # Pasek stanu
        self.status_bar = self.create_status_bar()
        main_layout.addWidget(self.status_bar)

        # Ustawienie domyślnego trybu
        self.stacked_widget.setCurrentIndex(0)  # Domyślnie tryb chatbota

        # Zastosowanie stylu
        self.apply_style()

    def apply_language(self, language):
        """Aktualizuje język interfejsu panelu informacji pogodowych"""
        if language not in ["pl", "en"]:
            return

        self.current_language = language

        # Aktualizacja etykiet opisów
        if hasattr(self, 'feels_like_text'):
            self.feels_like_text.setText(f"<b>{self.labels_translations[language]['feels_like']}</b>")
        if hasattr(self, 'temp_min_text'):
            self.temp_min_text.setText(f"<b>{self.labels_translations[language]['min']}</b>")
        if hasattr(self, 'temp_max_text'):
            self.temp_max_text.setText(f"<b>{self.labels_translations[language]['max']}</b>")
        if hasattr(self, 'humidity_text'):
            self.humidity_text.setText(f"<b>{self.labels_translations[language]['humidity']}</b>")
        if hasattr(self, 'pressure_text'):
            self.pressure_text.setText(f"<b>{self.labels_translations[language]['pressure']}</b>")
        if hasattr(self, 'wind_text'):
            self.wind_text.setText(f"<b>{self.labels_translations[language]['wind']}</b>")
        if hasattr(self, 'clouds_text'):
            self.clouds_text.setText(f"<b>{self.labels_translations[language]['clouds']}</b>")
        if hasattr(self, 'sunrise_text'):
            self.sunrise_text.setText(f"<b>{self.labels_translations[language]['sunrise']}</b>")
        if hasattr(self, 'sunset_text'):
            self.sunset_text.setText(f"<b>{self.labels_translations[language]['sunset']}</b>")

        # Aktualizacja opisu pogody
        if hasattr(self, 'condition_label') and self.condition_label:
            current_text = self.condition_label.text()
            # Tłumaczenia konkretnych opisów pogody
            weather_translations = {
                "pl": {
                    "Zachmurzenie duże": "Zachmurzenie duże",
                    "Pochmurno": "Pochmurno",
                    "Słonecznie": "Słonecznie",
                    "Bezchmurnie": "Bezchmurnie",
                    "Deszcz": "Deszcz",
                    "Śnieg": "Śnieg",
                    "Burza": "Burza",
                    "Mgła": "Mgła"
                },
                "en": {
                    "Zachmurzenie duże": "Overcast",
                    "Pochmurno": "Cloudy",
                    "Słonecznie": "Sunny",
                    "Bezchmurnie": "Clear",
                    "Deszcz": "Rain",
                    "Śnieg": "Snow",
                    "Burza": "Thunderstorm",
                    "Mgła": "Fog"
                }
            }

            # Sprawdź czy tekst znajduje się w słowniku tłumaczeń
            for pl_text, en_text in weather_translations["pl"].items():
                if language == "en" and pl_text in current_text:
                    self.condition_label.setText(weather_translations["en"][pl_text])
                    break
                elif language == "pl" and en_text in current_text:
                    # Znajdź odpowiedni klucz
                    for pl_key, en_val in weather_translations["en"].items():
                        if en_val == en_text:
                            self.condition_label.setText(pl_key)
                            break


    def create_title_bar(self):
        # Niestandardowy pasek tytułowy z przyciskami minimalizacji, maksymalizacji i zamknięcia
        title_bar = QWidget()
        title_bar.setFixedHeight(40)
        title_bar.setObjectName("title_bar")

        layout = QHBoxLayout(title_bar)
        layout.setContentsMargins(10, 0, 10, 0)

        title_label = QLabel("Weather Chatbot Pro")
        title_label.setObjectName("title_label")

        min_btn = QPushButton("—")
        min_btn.setObjectName("window_control_btn")
        min_btn.clicked.connect(self.showMinimized)

        max_btn = QPushButton("□")
        max_btn.setObjectName("window_control_btn")
        max_btn.clicked.connect(self.toggle_maximize)

        close_btn = QPushButton("✕")
        close_btn.setObjectName("window_control_btn")
        close_btn.setProperty("type", "close")
        close_btn.clicked.connect(self.close)

        layout.addWidget(title_label)
        layout.addStretch()
        layout.addWidget(min_btn)
        layout.addWidget(max_btn)
        layout.addWidget(close_btn)

        return title_bar

    def create_toolbar(self):
        # Pasek narzędzi z przełącznikami trybów i dodatkowymi kontrolkami
        toolbar = QWidget()
        toolbar.setFixedHeight(50)
        toolbar.setObjectName("toolbar")

        layout = QHBoxLayout(toolbar)
        layout.setContentsMargins(10, 5, 10, 5)

        # Przycisk trybu chatbota
        chat_btn = QPushButton(self.get_text("chatbot_mode"))
        chat_btn.setObjectName("mode_button")
        chat_btn.setCheckable(True)
        chat_btn.setChecked(True)
        chat_btn.clicked.connect(lambda: self.switch_mode(0))

        # Przycisk trybu dashboardu
        dashboard_btn = QPushButton(self.get_text("dashboard_mode"))
        dashboard_btn.setObjectName("mode_button")
        dashboard_btn.setCheckable(True)
        dashboard_btn.clicked.connect(lambda: self.switch_mode(1))

        # Przycisk wyciszenia/odciszenia dźwięku
        self.mute_btn = QPushButton("🔊")
        self.mute_btn.setObjectName("toolbar_icon_button")
        self.mute_btn.clicked.connect(self.toggle_sound)
        self.mute_btn.setToolTip(self.get_text("mute_tooltip"))

        # Przycisk języka
        self.language_btn = QPushButton(self.get_text("language_button"))
        self.language_btn.setObjectName("toolbar_icon_button")
        self.language_btn.clicked.connect(self.toggle_language)
        self.language_btn.setToolTip("Change language / Zmień język")

        # Przycisk ustawień
        settings_btn = QPushButton("⚙")
        settings_btn.setObjectName("toolbar_icon_button")
        settings_btn.clicked.connect(self.show_settings)
        settings_btn.setToolTip(self.get_text("settings_tooltip"))

        # Przycisk alertów
        alerts_btn = QPushButton("🔔")
        alerts_btn.setObjectName("toolbar_icon_button")
        alerts_btn.clicked.connect(self.show_alerts)
        alerts_btn.setToolTip(self.get_text("alerts_tooltip"))

        # Pole miasta
        city_label = QLabel(self.get_text("city_label"))
        city_label.setObjectName("city_label")

        city_combo = QComboBox()
        city_combo.setEditable(True)
        city_combo.setMinimumWidth(200)
        city_combo.setObjectName("city_combo")
        city_combo.currentTextChanged.connect(self.on_city_changed)
        city_combo.setPlaceholderText(self.get_text("enter_city"))
        self.city_combo = city_combo

        # Przycisk wyszukiwania
        search_btn = QPushButton("🔍")
        search_btn.setObjectName("toolbar_icon_button")
        search_btn.clicked.connect(self.search_city)
        search_btn.setToolTip(self.get_text("search_tooltip"))

        # Dodanie przycisków do paska
        layout.addWidget(chat_btn)
        layout.addWidget(dashboard_btn)
        layout.addSpacing(20)
        layout.addWidget(city_label)
        layout.addWidget(city_combo)
        layout.addWidget(search_btn)
        layout.addStretch()
        layout.addWidget(alerts_btn)
        layout.addWidget(self.language_btn)
        layout.addWidget(self.mute_btn)
        layout.addWidget(settings_btn)

        # Grupa przycisków do zachowania zaznaczenia
        self.mode_buttons = [chat_btn, dashboard_btn]

        return toolbar

    def get_text(self, key):
        """Zwraca tekst w aktualnym języku dla podanego klucza"""
        if key in self.translations[self.current_language]:
            return self.translations[self.current_language][key]
        return key  # Jeśli brak tłumaczenia, zwróć klucz

    def toggle_language(self):
        """Przełącza język interfejsu między polskim a angielskim"""
        if self.current_language == "pl":
            self.current_language = "en"
        else:
            self.current_language = "pl"

        # Aktualizacja języka w kontekście aplikacji
        self.app_context["current_language"] = self.current_language

        # Aktualizacja tekstu przycisku
        self.language_btn.setText(self.get_text("language_button"))

        # Aktualizacja interfejsu
        self.update_ui_language()

    def update_ui_language(self):
        """Aktualizuje wszystkie teksty interfejsu według aktualnego języka"""
        # Tytuł okna
        self.setWindowTitle(self.get_text("window_title"))

        # Przyciski trybu
        self.mode_buttons[0].setText(self.get_text("chatbot_mode"))
        self.mode_buttons[1].setText(self.get_text("dashboard_mode"))

        # Etykieta miasta
        city_label = self.toolbar.findChild(QLabel, "city_label")
        if city_label:
            city_label.setText(self.get_text("city_label"))

        # Tooltips przycisków
        self.mute_btn.setToolTip(self.get_text("mute_tooltip") if not self.sound_manager.muted
                                 else self.get_text("unmute_tooltip"))

        # Etykiety w pasku statusu
        update_text = self.get_text("last_update")
        status_text = self.get_text("status")

        last_update_time = self.update_label.text().split(": ")[1] if ": " in self.update_label.text() else "--"
        self.update_label.setText(f"{update_text} {last_update_time}")

        current_status = self.status_label.text().split(": ")[1] if ": " in self.status_label.text() else self.get_text(
            "status_ready")
        self.status_label.setText(f"{status_text} {current_status}")

        # Aktualizacja placeholdera w polu miasta
        self.city_combo.setPlaceholderText(self.get_text("enter_city"))

        # Aktualizacja językowa komponentów
        self.chat_widget.apply_language(self.current_language, self.translations[self.current_language])
        self.dashboard_widget.apply_language(self.current_language, self.translations[self.current_language])

        # Bezpośrednia aktualizacja widgetu informacji pogodowych
        try:
            if hasattr(self.dashboard_widget, 'current_weather_widget'):
                self.dashboard_widget.current_weather_widget.apply_language(self.current_language)

            # Dodatkowe komponenty, które mogą wymagać tłumaczenia
            if self.stacked_widget.currentIndex() == 1:  # Jeśli aktywny jest dashboard
                # Aktualizacja wszystkich komponentów dashboardu
                if hasattr(self.dashboard_widget, 'forecast_widget'):
                    if hasattr(self.dashboard_widget.forecast_widget, 'apply_language'):
                        self.dashboard_widget.forecast_widget.apply_language(self.current_language)

                # Aktualizacja map i innych komponentów
                if hasattr(self.dashboard_widget, 'map_widget'):
                    if hasattr(self.dashboard_widget.map_widget, 'apply_language'):
                        self.dashboard_widget.map_widget.apply_language(self.current_language)

                # Aktualizacja wykresów
                for chart_name in ['temp_chart', 'humidity_chart', 'pressure_chart', 'wind_chart', 'precip_chart',
                                   'history_chart']:
                    if hasattr(self.dashboard_widget, chart_name):
                        chart = getattr(self.dashboard_widget, chart_name)
                        if hasattr(chart, 'apply_language'):
                            chart.apply_language(self.current_language)
        except Exception as e:
            print(f"Błąd podczas aktualizacji komponentów: {str(e)}")

        # Upewnij się, że wszystkie elementy interfejsu są właściwie zaktualizowane
        # Czasami potrzebne jest odświeżenie widoków
        self.dashboard_widget.update()
        self.chat_widget.update()

        # Zapewnienie, że aktualny język jest zapisany w kontekście aplikacji
        self.app_context["current_language"] = self.current_language
        self.app_context["user_preferences"]["current_language"] = self.current_language

        # Aktualizacja etykiety przycisku języka po zmianie
        self.language_btn.setText(self.get_text("language_button"))

        # Jeśli jest to potrzebne, wymuś odświeżenie wyświetlania
        QApplication.processEvents()
    def toggle_sound(self):
        """Obsługa przełączenia stanu wyciszenia"""
        self.sound_manager.toggle_mute()

        # Aktualizacja ikony przycisku
        if self.sound_manager.muted:
            self.mute_btn.setText("🔇")
            self.mute_btn.setToolTip(self.get_text("unmute_tooltip"))
        else:
            self.mute_btn.setText("🔊")
            self.mute_btn.setToolTip(self.get_text("mute_tooltip"))

    def create_status_bar(self):
        # Pasek stanu z informacjami o aktualizacji, statusie połączenia itp.
        status_bar = QWidget()
        status_bar.setObjectName("status_bar")
        status_bar.setFixedHeight(30)

        layout = QHBoxLayout(status_bar)
        layout.setContentsMargins(10, 0, 10, 0)

        self.update_label = QLabel(f"{self.get_text('last_update')} --")
        self.status_label = QLabel(f"{self.get_text('status')} {self.get_text('status_ready')}")
        self.error_label = QLabel("")
        self.error_label.setObjectName("error_label")

        layout.addWidget(self.update_label)
        layout.addStretch()
        layout.addWidget(self.status_label)
        layout.addStretch()
        layout.addWidget(self.error_label)

        return status_bar

    def switch_mode(self, index):
        # Przełączanie między trybami (chat/dashboard)
        self.stacked_widget.setCurrentIndex(index)

        # Aktualizacja zaznaczonych przycisków
        for i, btn in enumerate(self.mode_buttons):
            btn.setChecked(i == index)

        # Aktualizacja informacji o pogodzie w aktywnym widgecie
        if index == 0:  # Tryb chatbota
            self.chat_widget.update_ui(self.app_context)
        else:  # Tryb dashboardu
            self.dashboard_widget.update_data(self.app_context)

    def toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def update_animation(self):
        # Aktualizacja animacji tła i efektów pogodowych
        self.particle_manager.update_animation()
        self.update()

    def paintEvent(self, event):
        # Renderowanie animowanego tła
        self.particle_manager.render(self, event, self.app_context["current_weather_condition"])

    def resizeEvent(self, event):
        # Aktualizacja systemów cząstek po zmianie rozmiaru okna
        self.particle_manager.resize(self.width(), self.height())
        super().resizeEvent(event)

    def on_city_changed(self, city):
        # Zapobiegaj automatycznemu wyszukiwaniu - będziemy wyszukiwać dopiero po kliknięciu przycisku
        # lub po naciśnięciu Enter
        self.app_context["current_city"] = city
        # NIE WYWOŁUJEMY TU self.search_city()

    def search_city(self):
        # Wyszukanie pogody dla wybranego miasta
        city = self.city_combo.currentText()
        if not city:
            self.error_label.setText(self.get_text("error_empty_city"))
            return

        # Aktualizacja statusu
        self.status_label.setText(f"{self.get_text('status')} {self.get_text('status_updating')}")
        self.error_label.setText("")  # Wyczyść poprzednie błędy

        # Dodaj dodatkowe logowanie
        print(f"Wyszukiwanie miasta: {city}")

        # Ustawienie bieżącego miasta w kontekście aplikacji
        self.app_context["current_city"] = city

        try:
            # Asynchroniczne pobieranie danych pogodowych
            self.weather_service.get_weather_data(city, self.on_weather_data_received)
        except Exception as e:
            self.error_label.setText(f"Błąd: {str(e)}")
            print(f"Błąd podczas wyszukiwania: {str(e)}")

        # Dodaj bezpośrednie wywołanie aktualizacji UI nawet przed otrzymaniem danych
        # To zapewni, że przynajmniej nazwa miasta zostanie zaktualizowana
        if self.stacked_widget.currentIndex() == 0:
            self.chat_widget.update_ui(self.app_context)
        else:
            self.dashboard_widget.update_data(self.app_context)
            self.chat_widget.update_ui(self.app_context)

    def on_weather_data_received(self, data):
        # Callback po otrzymaniu danych pogodowych
        if data.get("success", False):
            # Aktualizacja kontekstu aplikacji
            self.app_context["current_city"] = data["city"]
            self.add_to_recent_cities(data["city"])

            # Określenie warunków pogodowych do animacji
            weather_id = data.get("weather_id", 800)
            weather_condition = self.determine_weather_condition(weather_id)
            self.app_context["current_weather_condition"] = self.determine_weather_condition(weather_id)

            # Ustaw dźwięk tła odpowiedni dla warunków pogodowych
            self.sound_manager.set_ambient_sound_for_weather(weather_condition)
            # Aktualizacja etykiety czasu
            from datetime import datetime
            self.update_label.setText(f"{self.get_text('last_update')} {datetime.now().strftime('%H:%M:%S')}")

            # Aktualizacja statusu
            self.status_label.setText(f"{self.get_text('status')} {self.get_text('status_ready')}")

            # Aktualizacja aktywnego widgetu
            if self.stacked_widget.currentIndex() == 0:
                self.chat_widget.update_ui(self.app_context)
            else:
                self.dashboard_widget.update_data(self.app_context)

            # Ukrycie błędu
            self.error_label.setText("")

        else:
            # Obsługa błędu
            error_msg = data.get("message", "Nieznany błąd")
            self.error_label.setText(f"{self.get_text('status_error')}: {error_msg}")
            self.status_label.setText(f"{self.get_text('status')} {self.get_text('status_error')}")

    def determine_weather_condition(self, weather_id):
        # Określenie typu animacji pogodowej na podstawie kodu pogody
        if weather_id >= 200 and weather_id < 300:
            return "thunderstorm"
        elif weather_id >= 300 and weather_id < 600:
            return "rain"
        elif weather_id >= 600 and weather_id < 700:
            return "snow"
        elif weather_id >= 700 and weather_id < 800:
            return "clouds"  # mgła i inne
        elif weather_id == 800:
            return "clear"
        else:  # 801-899
            return "clouds"

    def add_to_recent_cities(self, city):
        # Dodawanie miasta do historii ostatnio wyszukiwanych
        if city in self.app_context["recent_cities"]:
            self.app_context["recent_cities"].remove(city)

        self.app_context["recent_cities"].insert(0, city)

        # Ograniczenie do 10 ostatnich miast
        if len(self.app_context["recent_cities"]) > 10:
            self.app_context["recent_cities"] = self.app_context["recent_cities"][:10]

        # Aktualizacja combobox
        self.update_cities_combo()

    def update_cities_combo(self):
        # Aktualizacja combo box z miastami
        current_text = self.city_combo.currentText()

        self.city_combo.blockSignals(True)
        self.city_combo.clear()
        self.city_combo.addItems(self.app_context["recent_cities"])

        # Przywrócenie aktualnego tekstu
        if current_text:
            self.city_combo.setEditText(current_text)

        self.city_combo.blockSignals(False)

    def show_settings(self):
        # Wyświetlenie okna ustawień
        settings_dialog = SettingsDialog(self.app_context["user_preferences"])
        if settings_dialog.exec_():
            # Aktualizacja preferencji po zamknięciu
            self.app_context["user_preferences"] = settings_dialog.get_preferences()
            self.save_user_preferences()
            self.apply_preferences()

    def show_alerts(self):
        # Dodanie menedżera dźwięku do kontekstu aplikacji
        self.app_context["sound_manager"] = self.sound_manager

        # Wyświetlenie okna alertów
        alert_dialog = AlertModule(self.app_context)

        # Odtworzenie dźwięku alertu
        self.sound_manager.play_alert_sound("default")

        alert_dialog.exec_()

    def load_user_preferences(self):
        # Ładowanie preferencji użytkownika
        # Tu możesz dodać kod do ładowania z pliku
        return {
            "theme": "dark",
            "animation_level": "high",
            "auto_refresh": 30,  # minuty
            "default_city": "Warszawa",
            "temperature_unit": "celsius",
            "notification_alerts": True,
            "current_language": self.current_language
        }

    def save_user_preferences(self):
        # Zapisywanie preferencji użytkownika
        # Dodaj zapisywanie aktualnego języka
        self.app_context["user_preferences"]["current_language"] = self.current_language
        # Tu możesz dodać kod do zapisywania do pliku

    def apply_preferences(self):
        # Zastosowanie preferencji użytkownika do UI
        prefs = self.app_context["user_preferences"]

        # Zastosowanie motywu
        self.apply_theme(prefs["theme"])

        # Ustawienie poziomu animacji
        self.particle_manager.set_effect_level(prefs["animation_level"])

        # Ustawienia dźwięku
        if "sound_volume" in prefs:
            self.sound_manager.set_volume(prefs["sound_volume"])

        # Zastosowanie ustawienia wyciszenia
        if prefs.get("muted", False) != self.sound_manager.muted:
            self.sound_manager.toggle_mute()  # Przełącz stan wyciszenia, jeśli różni się od preferencji

        # Zastosowanie języka
        if "current_language" in prefs:
            self.current_language = prefs["current_language"]
            self.app_context["current_language"] = self.current_language
            self.language_btn.setText(self.get_text("language_button"))
            self.update_ui_language()

        # Aktualizacja innych ustawień
        self.chat_widget.apply_preferences(prefs)
        self.dashboard_widget.apply_preferences(prefs)

    def apply_theme(self, theme_name):
        # Zastosowanie motywu (ciemny/jasny)
        if theme_name == "dark":
            # Ciemny motyw
            self.apply_style()
        else:
            # Jasny motyw (do uzupełnienia)
            pass

    def apply_style(self):
        # Zastosowanie stylów CSS do aplikacji
        self.setStyleSheet("""
            QWidget {
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                color: #a0e7ff;
                font-size: 14px;
                background-color: transparent; 
            }

            QMainWindow {
                background-color: transparent; 
            }

            /* NIESTANDARDOWY PASEK TYTUŁOWY */
            QWidget#title_bar {
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba(15, 32, 64, 0.95),
                    stop:1 rgba(30, 64, 128, 0.95)
                );
                border-bottom: 2px solid #4dabf7;
            }

            QLabel#title_label {
                font-size: 22px;
                font-weight: bold;
                color: #4dabf7;
                text-shadow: 0 0 10px rgba(77, 171, 247, 0.5);
            }

            QLabel#app_icon {
                font-size: 20px;
                color: #4dabf7;
            }

            QPushButton#window_control_btn {
                background: transparent;
                border: 2px solid #4dabf7;
                border-radius: 15px;
                min-width: 30px;
                min-height: 30px;
                color: #4dabf7;
                font-weight: bold;
                font-size: 16px;
            }

            QPushButton#window_control_btn:hover {
                background: rgba(77, 171, 247, 0.2);
                border-color: #a0e7ff;
            }

            QPushButton[type="close"]:hover {
                background: rgba(231, 76, 60, 0.7);
                border-color: #E74C3C;
                color: white;
            }

            /* PASEK NARZĘDZI */
            QWidget#toolbar {
                background-color: transparent; 
                border-bottom: 1px solid #4dabf7;
            }

            QPushButton#mode_button {
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 10px;
                color: #a0e7ff;
                padding: 8px 15px;
                font-size: 15px;
                min-height: 36px;
                text-shadow: 0 0 5px rgba(160, 231, 255, 0.5);
                font-weight: normal;
            }

            QPushButton#mode_button:checked {
                background: qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 rgba(77, 171, 247, 0.7),
                    stop:1 rgba(15, 32, 64, 0.8)
                );
                font-weight: bold;
                border-width: 3px;
            }

            QPushButton#mode_button:hover {
                background: rgba(77, 171, 247, 0.3);
                border-color: #a0e7ff;
            }

            QPushButton#toolbar_icon_button {
                background: transparent;
                border: 2px solid #4dabf7;
                border-radius: 15px;
                min-width: 30px;
                min-height: 30px;
                font-size: 18px;
                color: #4dabf7;
            }

            QPushButton#toolbar_icon_button:hover {
                background: rgba(77, 171, 247, 0.2);
                border-color: #a0e7ff;
                color: #a0e7ff;
            }

            /* COMBO BOX WYSZUKIWANIA */
            QComboBox {
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 10px;
                padding: 5px 10px;
                color: #a0e7ff;
                min-height: 36px;
                font-size: 15px;
            }

            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: center right;
                width: 30px;
                border-left: 1px solid #4dabf7;
                border-top-right-radius: 10px;
                border-bottom-right-radius: 10px;
            }

            QComboBox QAbstractItemView {
                background-color: rgba(15, 32, 64, 0.95);
                border: 2px solid #4dabf7;
                border-radius: 10px;
                selection-background-color: rgba(77, 171, 247, 0.3);
                padding: 5px;
            }

            /* PASEK STANU */
            QWidget#status_bar {
                background-color: transparent; 
                border-top: 1px solid #4dabf7;
            }

            QLabel#error_label {
                color: #E74C3C;
                font-weight: bold;
            }

            /* STYLE DLA CHATBOTA */
            QTextEdit#chat_history {
                background-color: transparent; 
                border: 2px solid #4dabf7;
                font-size: 15px;
                border-radius: 10px;
                padding: 10px;
            }

            QLineEdit#chat_input {
                min-height: 40px;
                font-size: 15px;
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 10px;
                padding: 5px 10px;
                color: #a0e7ff;
            }

            /* PRZYCISKI W PANELU MIAST */
            QPushButton#example_button {
                text-align: left;
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 8px;
                color: #a0e7ff;
                padding: 8px;
                font-size: 14px;
                min-height: 36px;
            }

            QPushButton#example_button:hover {
                background-color: rgba(77, 171, 247, 0.3);
                border-color: #a0e7ff;
            }

            QPushButton#city_button {
                text-align: left;
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 8px;
                color: #a0e7ff;
                padding: 8px;
                font-size: 14px;
                min-height: 36px;
            }

            QPushButton#city_button:hover {
                background-color: rgba(77, 171, 247, 0.3);
                border-color: #a0e7ff;
            }

            /* STYLE DLA DASHBOARDU */
            QLabel#weather_icon {
                font-size: 72px;  /* Zwiększony rozmiar ikon */
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 15px;
            }

            QLabel#temperature_label {
                font-size: 48px;
                color: #4dabf7;
                text-shadow: 0 0 15px rgba(77, 171, 247, 0.6);
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 10px;
            }

            QLabel#condition_label {
                font-size: 28px;
                background-color: transparent;
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 8px;
            }

            QLabel#detail_label {
                font-size: 16px;
            }

            QWidget#details_widget {
                background-color: transparent;
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 15px;
            }

            QFrame#forecast_card {
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 10px;
            }

            QLabel#forecast_icon {
                font-size: 48px;  /* Zwiększony rozmiar ikon prognozy */
            }

            QLabel#forecast_temp {
                font-size: 18px;
                color: #a0e7ff;
            }

            QLabel#forecast_date {
                font-size: 16px;
                font-weight: bold;
                color: #4dabf7;
            }

            /* ZAKŁADKI */
            QTabWidget::pane {
                border: 2px solid #4dabf7;
                border-radius: 10px;
                background-color: transparent; 
                top: -1px;
            }

            QTabBar::tab {
                background-color: transparent; 
                border: 2px solid #4dabf7;
                border-bottom: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 8px 16px;
                color: #a0e7ff;
                font-size: 14px;
                margin-right: 4px;
            }

            QTabBar::tab:selected {
                background-color: transparent; 
                border-color: #a0e7ff;
            }

            QTabBar::tab:hover:!selected {
                background-color: rgba(77, 171, 247, 0.2);
            }

            /* SCROLLBAR */
            QScrollBar:vertical {
                border: none;
                background-color: transparent; 
                width: 12px;
                margin: 15px 0px 15px 0px;
                border-radius: 6px;
            }

            QScrollBar::handle:vertical {
                background-color: transparent; 
                min-height: 30px;
                border-radius: 6px;
            }

            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                border: none;
                background: rgba(77, 171, 247, 0.2);
                height: 15px;
                border-radius: 6px;
                subcontrol-position: top;
                subcontrol-origin: margin;
            }

            QScrollBar::add-line:vertical {
                subcontrol-position: bottom;
            }

            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }

            /* WIDGET POGODY */
            QWidget#weather_info {
                background-color: transparent;
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 15px;
            }

            /* STYL DLA PANELU "OSTATNIE WYSZUKIWANIA POGODY" */
            QWidget#weather_info QLabel {
                font-size: 16px;
                margin: 5px;
                padding: 5px;
            }

            QPushButton#send_button {
                min-height: 40px;
                min-width: 100px;
                background-color: rgba(77, 171, 247, 0.3);  /* Blue matching the theme */
                border: 2px solid #4dabf7;
                border-radius: 10px;
                color: #ffffff;
                font-weight: bold;
                font-size: 15px;
            }

            QPushButton#send_button:hover {
                background-color: rgba(77, 171, 247, 0.5);
                border-color: #a0e7ff;
            }

            QPushButton#send_button:pressed {
                background-color: rgba(77, 171, 247, 1.0);
            }

            /* Fix white backgrounds */
            QWidget {
                background-color: transparent;  /* Make all widgets transparent by default */
            }

            QScrollArea, QComboBox QAbstractItemView, QDialog {
                background-color: rgba(15, 32, 64, 0.6);  /* Dark blue matching theme */
            }

            /* Fixed dashboard panels */
            QTabWidget QWidget {
                background-color: transparent;
            }

            QFrame, QGroupBox {
                background-color: rgba(15, 32, 64, 0.5);  /* Semi-transparent dark blue */
            }

            QWidget#weather_info_panel {
                background-color: rgba(0, 4, 40, 0.5);
                border: 2px solid #4dabf7;
                border-radius: 15px;
                padding: 15px;
            }



            QDialog QWidget {
                background-color: transparent;
            }

            QDialog QGroupBox {
                background-color: rgba(0, 4, 40, 0.5);
                border: 2px solid #4dabf7;
                border-radius: 10px;
                padding: 10px;
                margin-top: 20px;
            }

            QDialog QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 10px;
                color: #4dabf7;
                font-weight: bold;
            }

            """)

    def connect_signals(self):
        # Połączenie sygnałów między modułami
        # Sygnały od chatbota
        self.chat_widget.city_selected.connect(self.on_city_selected_from_chat)

        # Sygnały od dashboard
        self.dashboard_widget.city_changed.connect(self.on_city_changed)

    def on_city_selected_from_chat(self, city):
        # Obsługa wybrania miasta z chatu
        self.city_combo.setCurrentText(city)
        # Wywołanie wyszukiwania pogody
        self.search_city()


    def closeEvent(self, event):
        """Obsługa zamykania okna aplikacji"""
        # Zapisz preferencje użytkownika
        self.save_user_preferences()

        # Zatrzymaj wszystkie dźwięki i zwolnij zasoby
        self.sound_manager.cleanup()

        # Zaakceptuj zdarzenie zamknięcia
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Załadowanie czcionek
    try:
        from PyQt5.QtGui import QFontDatabase
        QFontDatabase.addApplicationFont("fonts/Orbitron-Regular.ttf")
        QFontDatabase.addApplicationFont("fonts/Orbitron-Bold.ttf")
    except Exception as e:
        print(f"Nie można załadować czcionek: {str(e)}")

    window = WeatherChatbotPro()
    window.show()

    sys.exit(app.exec_())
